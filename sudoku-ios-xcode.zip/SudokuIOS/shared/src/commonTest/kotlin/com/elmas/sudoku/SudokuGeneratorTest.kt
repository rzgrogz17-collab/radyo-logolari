package com.elmas.sudoku

import com.elmas.sudoku.logic.CellKind
import com.elmas.sudoku.logic.Difficulty
import com.elmas.sudoku.logic.GameStorage
import com.elmas.sudoku.logic.SudokuGenerator
import com.elmas.sudoku.logic.SudokuRules
import com.elmas.sudoku.platform.KeyValueStore
import kotlin.random.Random
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class SudokuGeneratorTest {
    @Test
    fun easyPuzzleHasOneSolution() {
        val puzzle = SudokuGenerator.generate(Difficulty.EASY, Random(7))
        assertEquals(1, SudokuGenerator.countSolutions(puzzle.cells, 2))
        assertTrue(SudokuRules.isSolved(puzzle.solution.asList()))
        val removed = puzzle.cells.count { it == 0 }
        assertTrue(removed >= Difficulty.EASY.removedCount)
    }

    @Test
    fun conflictsMarkDuplicatesOnly() {
        val cells = MutableList(81) { 0 }
        cells[0] = 5
        cells[1] = 5
        val flags = SudokuRules.conflicts(cells)
        assertTrue(flags[0])
        assertTrue(flags[1])
        assertFalse(flags[2])
    }

    @Test
    fun storageRoundTrip() {
        val store = object : KeyValueStore {
            val s = HashMap<String, String>()
            val i = HashMap<String, Int>()
            val b = HashMap<String, Boolean>()
            override fun getString(key: String, default: String) = s[key] ?: default
            override fun putString(key: String, value: String) { s[key] = value }
            override fun getInt(key: String, default: Int) = i[key] ?: default
            override fun putInt(key: String, value: Int) { i[key] = value }
            override fun getBoolean(key: String, default: Boolean) = b[key] ?: default
            override fun putBoolean(key: String, value: Boolean) { b[key] = value }
            override fun remove(key: String) { s.remove(key); i.remove(key); b.remove(key) }
        }
        val storage = GameStorage(store)
        val puzzle = SudokuGenerator.generate(Difficulty.MEDIUM, Random(3))
        val kinds = IntArray(81) { if (puzzle.cells[it] != 0) CellKind.GIVEN else CellKind.FREE }
        storage.saveGame(
            com.elmas.sudoku.logic.SavedGame(puzzle.cells, puzzle.solution, kinds, IntArray(81), Difficulty.MEDIUM, 42)
        )
        val loaded = storage.loadGame()
        assertTrue(loaded != null)
        assertEquals(42, loaded!!.elapsedSeconds)
        assertEquals(Difficulty.MEDIUM, loaded.difficulty)
        assertTrue(storage.recordWin(Difficulty.MEDIUM, 90))
        assertFalse(storage.recordWin(Difficulty.MEDIUM, 120))
        assertEquals(90, storage.bestTime(Difficulty.MEDIUM))
    }
}
