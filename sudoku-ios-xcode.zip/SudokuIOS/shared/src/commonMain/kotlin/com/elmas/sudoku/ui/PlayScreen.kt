package com.elmas.sudoku.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.elmas.sudoku.ads.AdConfig
import com.elmas.sudoku.ads.Ads
import com.elmas.sudoku.ads.BannerAd
import com.elmas.sudoku.logic.CellKind
import com.elmas.sudoku.logic.SudokuRules
import com.elmas.sudoku.platform.AppVisibility
import com.elmas.sudoku.platform.SoundPlayer
import com.elmas.sudoku.theme.Black
import com.elmas.sudoku.theme.ErrorRed
import com.elmas.sudoku.theme.GoldStar
import com.elmas.sudoku.theme.SudokuPalette
import com.elmas.sudoku.theme.WinGreen
import com.elmas.sudoku.theme.levelColor
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun PlayScreen(
    controller: GameController,
    palette: SudokuPalette,
    muted: Boolean,
    sound: SoundPlayer,
    onToggleDark: () -> Unit,
    onToggleMute: () -> Unit,
    onHome: () -> Unit,
    onSolved: () -> Unit
) {
    val level = levelColor(controller.difficulty, palette.dark)
    val breath = rememberBreath()
    val wave = remember { Animatable(0f) }
    val resumed by AppVisibility.resumed
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(resumed) {
        if (!resumed) controller.save()
    }

    val solved = controller.solved
    LaunchedEffect(resumed, solved) {
        if (!resumed || solved) return@LaunchedEffect
        var ticks = 0
        while (true) {
            delay(1_000L)
            controller.elapsedSeconds++
            ticks++
            if (ticks % 10 == 0) controller.save()
        }
    }

    LaunchedEffect(solved) {
        if (solved) {
            sound.playWin()
            wave.snapTo(0f)
            wave.animateTo(1f, tween(1_100, easing = LinearEasing))
            onSolved()
        }
    }

    LaunchedEffect(message) {
        if (message != null) {
            delay(1_600L)
            message = null
        }
    }

    fun toast(key: String) {
        message = Lang.get(key)
    }

    fun rewarded(grant: () -> Unit) {
        val shown = Ads.showRewarded {
            grant()
            sound.playReward()
            toast("reward_earned")
        }
        if (!shown) toast("ad_not_ready")
    }

    val onDigit: (Int) -> Unit = { digit ->
        when (controller.input(digit)) {
            MoveResult.NOTE -> sound.playPencil()
            MoveResult.PLACED -> sound.playClick()
            MoveResult.CONFLICT, MoveResult.LOCKED -> sound.playError()
            MoveResult.NO_SELECTION -> toast("select_cell")
            MoveResult.SOLVED, MoveResult.IGNORED -> Unit
        }
    }
    val onErase: () -> Unit = {
        when (controller.erase()) {
            MoveResult.PLACED -> sound.playPencil()
            MoveResult.LOCKED -> sound.playError()
            MoveResult.NO_SELECTION -> toast("select_cell")
            else -> Unit
        }
    }
    val onUndo: () -> Unit = {
        when (controller.undo()) {
            ActionResult.DONE -> sound.playPencil()
            ActionResult.EMPTY -> toast("nothing_to_undo")
            ActionResult.NEED_AD -> rewarded {
                controller.addUndos(AdConfig.REWARD_AMOUNT)
                controller.undo()
            }
            else -> Unit
        }
    }
    val onHint: () -> Unit = {
        when (controller.hint()) {
            ActionResult.DONE -> sound.playSuccess()
            ActionResult.NO_SELECTION -> toast("select_cell")
            ActionResult.NEED_AD -> rewarded {
                controller.addHints(AdConfig.REWARD_AMOUNT)
                controller.hint()
            }
            else -> Unit
        }
    }
    val onPencil: () -> Unit = {
        controller.pencilMode = !controller.pencilMode
        sound.playClick()
    }

    Box(Modifier.fillMaxSize()) {
        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            val landscape = maxWidth > maxHeight
            if (!landscape) {
                val boardSize = minOf(maxWidth, (maxHeight - 330.dp).coerceAtLeast(220.dp))
                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                    GameHeader(controller, palette, level, breath, muted, onHome, onToggleDark, onToggleMute)
                    Spacer(Modifier.height(10.dp))
                    ProgressStrip(controller, palette, level)
                    Spacer(Modifier.height(8.dp))
                    Spacer(Modifier.weight(1f))
                    SudokuBoard(controller, palette, level, breath, { wave.value }, Modifier.size(boardSize))
                    Spacer(Modifier.height(10.dp))
                    Spacer(Modifier.weight(1f))
                    ActionRow(controller, palette, onUndo, onErase, onPencil, onHint)
                    Spacer(Modifier.height(8.dp))
                    NumberRow(controller, palette, onDigit)
                    Spacer(Modifier.height(8.dp))
                    Spacer(Modifier.weight(1f))
                    BannerAd()
                }
            } else {
                Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Box(
                        Modifier
                            .fillMaxHeight()
                            .aspectRatio(1f, matchHeightConstraintsFirst = true)
                    ) {
                        SudokuBoard(controller, palette, level, breath, { wave.value }, Modifier.fillMaxSize())
                    }
                    Column(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    ) {
                        GameHeader(controller, palette, level, breath, muted, onHome, onToggleDark, onToggleMute)
                        Spacer(Modifier.height(10.dp))
                        ProgressStrip(controller, palette, level)
                        Spacer(Modifier.weight(1f))
                        ActionRow(controller, palette, onUndo, onErase, onPencil, onHint)
                        Spacer(Modifier.height(8.dp))
                        NumberRow(controller, palette, onDigit)
                        Spacer(Modifier.height(8.dp))
                        BannerAd()
                    }
                }
            }
        }
        AnimatedVisibility(
            visible = message != null,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 72.dp),
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            MessageToast(message ?: "", palette)
        }
    }
}

@Composable
private fun GameHeader(
    controller: GameController,
    palette: SudokuPalette,
    level: Color,
    breath: State<Float>,
    muted: Boolean,
    onHome: () -> Unit,
    onToggleDark: () -> Unit,
    onToggleMute: () -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .height(60.dp)
            .panel(palette, shape, elevation = if (palette.dark) 12.dp else 5.dp)
            .neonBorder(
                breath,
                if (palette.dark) palette.glow else palette.text.copy(alpha = 0.18f),
                1.5.dp,
                18.dp
            )
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onHome) {
            Icon(Icons.Filled.Home, Lang.get("menu"), tint = palette.text)
        }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Psychology, null, tint = level, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    controller.difficulty?.let { Lang.get(it.labelKey) } ?: "SUDOKU",
                    color = level,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            TimerText(controller, palette)
        }
        IconButton(onClick = onToggleDark) {
            Icon(
                if (palette.dark) Icons.Filled.WbSunny else Icons.Filled.NightsStay,
                null,
                tint = palette.text
            )
        }
        IconButton(onClick = onToggleMute) {
            Icon(
                if (muted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                null,
                tint = if (muted) ErrorRed else WinGreen
            )
        }
    }
}

@Composable
private fun TimerText(controller: GameController, palette: SudokuPalette) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.Timer, null, tint = palette.textDim, modifier = Modifier.size(13.dp))
        Spacer(Modifier.width(4.dp))
        Text(
            formatTime(controller.elapsedSeconds),
            color = palette.textDim,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            style = TextStyle(fontFeatureSettings = "tnum")
        )
    }
}

@Composable
private fun ProgressStrip(controller: GameController, palette: SudokuPalette, level: Color) {
    val progress by remember(controller) { derivedStateOf { controller.progress() } }
    val animated by animateFloatAsState(progress, tween(450), label = "progress")
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .weight(1f)
                .height(6.dp)
                .clip(CircleShape)
                .background(palette.outline)
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(animated.coerceIn(0f, 1f))
                    .clip(CircleShape)
                    .background(Brush.horizontalGradient(listOf(level.copy(alpha = 0.55f), level)))
            )
        }
        Spacer(Modifier.width(10.dp))
        Text(
            Lang.percent((progress * 100).roundToInt()),
            color = level,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun SudokuBoard(
    controller: GameController,
    palette: SudokuPalette,
    level: Color,
    breath: State<Float>,
    wave: () -> Float,
    modifier: Modifier
) {
    val conflicts by remember(controller) { derivedStateOf { SudokuRules.conflicts(controller.cells) } }
    val selected = controller.selected
    val selectedValue = if (selected in 0..80) controller.cells[selected] else 0
    val shape = RoundedCornerShape(14.dp)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        BoxWithConstraints(
            modifier
                .shadow(
                    elevation = if (palette.dark) 12.dp else 6.dp,
                    shape = shape,
                    clip = false,
                    ambientColor = palette.accent,
                    spotColor = palette.accent
                )
                .clip(shape)
                .background(palette.boardBg)
                .neonBorder(breath, palette.accent, 2.dp, 14.dp)
        ) {
            val density = LocalDensity.current
            val cell = maxWidth / 9
            val digitSize = with(density) { (cell * 0.56f).toSp() }
            val noteSize = with(density) { (cell * 0.25f).toSp() }

            Column(Modifier.fillMaxSize()) {
                for (r in 0 until 9) {
                    Row(
                        Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        for (c in 0 until 9) {
                            val i = r * 9 + c
                            val value = controller.cells[i]
                            BoardCell(
                                value = value,
                                notes = controller.notes[i],
                                kind = controller.kinds[i],
                                conflict = conflicts[i],
                                selected = i == selected,
                                peer = selected in 0..80 && i != selected && SudokuRules.sameGroup(i, selected),
                                sameNumber = value != 0 && value == selectedValue && i != selected,
                                palette = palette,
                                digitSize = digitSize,
                                noteSize = noteSize,
                                waveDelay = (r + c) / 16f,
                                wave = wave,
                                glow = level,
                                onClick = { controller.select(i) },
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                            )
                        }
                    }
                }
            }

            Canvas(Modifier.matchParentSize()) {
                val step = size.width / 9f
                val thin = 0.8.dp.toPx()
                val thick = 2.dp.toPx()
                for (k in 1 until 9) {
                    val box = k % 3 == 0
                    val color = if (box) level.copy(alpha = 0.85f) else palette.gridThin
                    val width = if (box) thick else thin
                    val pos = step * k
                    drawLine(color, Offset(pos, 0f), Offset(pos, size.height), width)
                    drawLine(color, Offset(0f, pos), Offset(size.width, pos), width)
                }
            }
        }
    }
}

@Composable
private fun BoardCell(
    value: Int,
    notes: Int,
    kind: Int,
    conflict: Boolean,
    selected: Boolean,
    peer: Boolean,
    sameNumber: Boolean,
    palette: SudokuPalette,
    digitSize: TextUnit,
    noteSize: TextUnit,
    waveDelay: Float,
    wave: () -> Float,
    glow: Color,
    onClick: () -> Unit,
    modifier: Modifier
) {
    val target = when {
        selected -> palette.selection
        conflict -> palette.conflictBg
        sameNumber -> palette.sameNumber
        peer -> palette.peer
        else -> Color.Transparent
    }
    val background by animateColorAsState(target, tween(140), label = "cellBg")
    val interaction = remember { MutableInteractionSource() }

    Box(
        modifier
            .drawBehind {
                drawRect(background)
                val w = wave()
                if (w > 0f) {
                    val t = (w * 1.6f - waveDelay) / 0.35f
                    if (t in 0f..1f) drawRect(glow.copy(alpha = 0.6f * sin(PI.toFloat() * t)))
                }
            }
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (value != 0) {
            val color = when {
                conflict && kind == CellKind.FREE -> ErrorRed
                kind == CellKind.HINTED -> palette.hintDigit
                kind == CellKind.GIVEN -> palette.text
                else -> palette.userDigit
            }
            Text(
                value.toString(),
                color = color,
                fontSize = digitSize,
                lineHeight = digitSize,
                fontWeight = if (kind == CellKind.GIVEN) FontWeight.Bold else FontWeight.SemiBold
            )
        } else if (notes != 0) {
            NotesGrid(notes, palette.note, noteSize)
        }
    }
}

@Composable
private fun NotesGrid(mask: Int, color: Color, size: TextUnit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(1.dp)
    ) {
        for (r in 0 until 3) {
            Row(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                for (c in 0 until 3) {
                    val digit = r * 3 + c + 1
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.Center
                    ) {
                        if (mask and (1 shl digit) != 0) {
                            Text(
                                digit.toString(),
                                color = color,
                                fontSize = size,
                                lineHeight = size,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionRow(
    controller: GameController,
    palette: SudokuPalette,
    onUndo: () -> Unit,
    onErase: () -> Unit,
    onPencil: () -> Unit,
    onHint: () -> Unit
) {
    val pencil = controller.pencilMode
    Row(Modifier.fillMaxWidth()) {
        ActionButton(
            icon = Icons.AutoMirrored.Filled.Undo,
            label = Lang.get("undo"),
            palette = palette,
            count = controller.undos,
            modifier = Modifier.weight(1f),
            onClick = onUndo
        )
        ActionButton(
            icon = Icons.AutoMirrored.Filled.Backspace,
            label = Lang.get("erase"),
            palette = palette,
            modifier = Modifier.weight(1f),
            onClick = onErase
        )
        ActionButton(
            icon = Icons.Filled.Edit,
            label = Lang.get(if (pencil) "pencil_on" else "pencil_off"),
            palette = palette,
            active = pencil,
            modifier = Modifier.weight(1f),
            onClick = onPencil
        )
        ActionButton(
            icon = Icons.Filled.Lightbulb,
            label = Lang.get("hint"),
            palette = palette,
            count = controller.hints,
            modifier = Modifier.weight(1f),
            onClick = onHint
        )
    }
}

@Composable
private fun ActionButton(
    icon: ImageVector,
    label: String,
    palette: SudokuPalette,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    count: Int? = null,
    onClick: () -> Unit
) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(width = 62.dp, height = 50.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(if (active) palette.accent else palette.key)
                    .border(1.dp, if (active) palette.accent else palette.outline, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    icon,
                    null,
                    tint = if (active) Color.White else palette.text,
                    modifier = Modifier.size(22.dp)
                )
            }
            if (count != null) {
                val needsAd = count <= 0
                Row(
                    Modifier
                        .align(Alignment.TopEnd)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (needsAd) GoldStar else palette.accent)
                        .padding(horizontal = 5.dp, vertical = 1.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (needsAd) {
                        Icon(Icons.Filled.PlayArrow, null, tint = Black, modifier = Modifier.size(10.dp))
                        Text(
                            "+${AdConfig.REWARD_AMOUNT}",
                            color = Black,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Text(count.toString(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Spacer(Modifier.height(2.dp))
        Text(
            label,
            color = if (active) palette.accent else palette.textDim,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun NumberRow(controller: GameController, palette: SudokuPalette, onDigit: (Int) -> Unit) {
    val remaining by remember(controller) { derivedStateOf { controller.remaining() } }
    val pencil = controller.pencilMode
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            for (digit in 1..9) {
                NumberKey(
                    digit = digit,
                    left = remaining[digit],
                    pencil = pencil,
                    palette = palette,
                    modifier = Modifier.weight(1f),
                    onClick = { onDigit(digit) }
                )
            }
        }
    }
}

@Composable
private fun NumberKey(
    digit: Int,
    left: Int,
    pencil: Boolean,
    palette: SudokuPalette,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val done = left == 0
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier
            .height(60.dp)
            .alpha(if (done) 0.35f else 1f)
            .clip(shape)
            .background(if (pencil) palette.accentSoft else palette.key)
            .border(1.dp, if (pencil) palette.glow.copy(alpha = 0.7f) else palette.outline, shape)
            .clickable(enabled = !done, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            digit.toString(),
            color = if (pencil) palette.glow else palette.accent,
            fontSize = 24.sp,
            lineHeight = 26.sp,
            fontWeight = FontWeight.Bold
        )
        if (done) {
            Icon(Icons.Filled.Check, null, tint = WinGreen, modifier = Modifier.size(12.dp))
        } else {
            Text(
                left.coerceAtLeast(0).toString(),
                color = palette.textDim,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
