package com.elmas.sudoku.logic

import com.elmas.sudoku.platform.KeyValueStore

class SavedGame(
    val cells: IntArray,
    val solution: IntArray,
    val kinds: IntArray,
    val notes: IntArray,
    val difficulty: Difficulty?,
    val elapsedSeconds: Int
) {
    val progressPercent: Int
        get() {
            var total = 0
            var filled = 0
            for (i in 0 until 81) {
                if (kinds[i] == CellKind.GIVEN) continue
                total++
                if (cells[i] != 0) filled++
            }
            return if (total == 0) 100 else filled * 100 / total
        }
}

class GameStorage(private val prefs: KeyValueStore) {

    fun hasSavedGame(): Boolean =
        prefs.getBoolean("has_saved_game", false) && prefs.getString("saved_board").isNotEmpty()

    fun saveGame(game: SavedGame) {
        prefs.putString("saved_board", game.cells.joinToString(","))
        prefs.putString("saved_solution", game.solution.joinToString(","))
        prefs.putString("saved_kinds", game.kinds.joinToString(""))
        prefs.putString("saved_notes", game.notes.joinToString(","))
        prefs.putString("saved_difficulty", game.difficulty?.name ?: "")
        prefs.putInt("saved_elapsed", game.elapsedSeconds)
        prefs.putBoolean("has_saved_game", true)
    }

    fun loadGame(): SavedGame? {
        if (!hasSavedGame()) return null
        val cells = parseGrid(prefs.getString("saved_board")) ?: return null
        val solution = parseGrid(prefs.getString("saved_solution")) ?: return null
        if (solution.any { it !in 1..9 } || !SudokuRules.isSolved(solution.asList())) return null
        if (cells.any { it !in 0..9 }) return null

        val kindsText = prefs.getString("saved_kinds")
        val kinds = if (kindsText.length == 81) {
            IntArray(81) { (kindsText[it] - '0').coerceIn(CellKind.FREE, CellKind.HINTED) }
        } else {
            IntArray(81) { if (cells[it] != 0 && cells[it] == solution[it]) CellKind.GIVEN else CellKind.FREE }
        }
        val notes = parseNotes(prefs.getString("saved_notes"))
        val difficulty = prefs.getString("saved_difficulty")
            .takeIf { it.isNotEmpty() }
            ?.let { name -> Difficulty.entries.firstOrNull { it.name == name } }
        val elapsed = prefs.getInt("saved_elapsed", 0).coerceAtLeast(0)
        return SavedGame(cells, solution, kinds, notes, difficulty, elapsed)
    }

    fun clearSave() {
        prefs.remove("saved_board")
        prefs.remove("saved_solution")
        prefs.remove("saved_kinds")
        prefs.remove("saved_notes")
        prefs.remove("saved_difficulty")
        prefs.remove("saved_elapsed")
        prefs.remove("has_saved_game")
    }

    fun saveRights(hints: Int, undos: Int) {
        prefs.putInt("hints_left", hints)
        prefs.putInt("undos_left", undos)
    }

    fun getHints() = prefs.getInt("hints_left", 3)
    fun getUndos() = prefs.getInt("undos_left", 3)

    fun isDarkMode() = prefs.getBoolean("dark_mode", true)
    fun setDarkMode(dark: Boolean) = prefs.putBoolean("dark_mode", dark)

    fun isMuted() = prefs.getBoolean("muted", false)
    fun setMuted(muted: Boolean) = prefs.putBoolean("muted", muted)

    fun bestTime(difficulty: Difficulty) = prefs.getInt("best_${difficulty.name}", 0)

    fun wins(difficulty: Difficulty) = prefs.getInt("wins_${difficulty.name}", 0)

    fun recordWin(difficulty: Difficulty, seconds: Int): Boolean {
        val best = bestTime(difficulty)
        val record = best == 0 || seconds < best
        prefs.putInt("wins_${difficulty.name}", wins(difficulty) + 1)
        if (record) prefs.putInt("best_${difficulty.name}", seconds.coerceAtLeast(1))
        return record
    }

    private fun parseGrid(text: String): IntArray? {
        if (text.isEmpty()) return null
        val parts = text.split(",")
        if (parts.size != 81) return null
        return try {
            IntArray(81) { parts[it].trim().toInt() }
        } catch (e: NumberFormatException) {
            null
        }
    }

    private fun parseNotes(text: String): IntArray {
        if (text.isEmpty()) return IntArray(81)
        val parts = text.split(",")
        if (parts.size != 81) return IntArray(81)
        return IntArray(81) { parts[it].trim().toIntOrNull()?.and(0x3FE) ?: 0 }
    }
}
