package com.elmas.sudoku.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.elmas.sudoku.theme.SudokuPalette

fun formatTime(totalSeconds: Int): String {
    val s = totalSeconds.coerceAtLeast(0)
    val hours = s / 3600
    val minutes = s % 3600 / 60
    val seconds = s % 60
    fun two(n: Int) = n.toString().padStart(2, '0')
    return if (hours > 0) "$hours:${two(minutes)}:${two(seconds)}" else "${two(minutes)}:${two(seconds)}"
}

@Composable
fun rememberBreath(): State<Float> {
    val transition = rememberInfiniteTransition(label = "breath")
    return transition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathAlpha"
    )
}

fun Modifier.panel(palette: SudokuPalette, shape: Shape, elevation: Dp = 0.dp): Modifier {
    val base = if (elevation > 0.dp) {
        shadow(
            elevation = elevation,
            shape = shape,
            clip = false,
            ambientColor = if (palette.dark) palette.glow else Color.Black,
            spotColor = if (palette.dark) palette.glow else Color.Black
        )
    } else {
        this
    }
    return base
        .clip(shape)
        .background(if (palette.dark) palette.surface else palette.surfaceStrong)
        .border(1.dp, palette.outline, shape)
}

fun Modifier.neonBorder(breath: State<Float>, color: Color, width: Dp, radius: Dp): Modifier =
    drawWithContent {
        drawContent()
        val stroke = width.toPx()
        val inset = stroke / 2f
        val corner = (radius.toPx() - inset).coerceAtLeast(0f)
        drawRoundRect(
            color = color.copy(alpha = (0.35f + breath.value * 0.65f).coerceIn(0f, 1f)),
            topLeft = Offset(inset, inset),
            size = Size(size.width - stroke, size.height - stroke),
            cornerRadius = CornerRadius(corner, corner),
            style = Stroke(stroke)
        )
    }

@Composable
fun MessageToast(text: String, palette: SudokuPalette, modifier: Modifier = Modifier) {
    Box(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(palette.surfaceStrong.copy(alpha = 0.96f))
            .border(1.dp, palette.outline, RoundedCornerShape(14.dp))
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text(text, color = palette.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}
