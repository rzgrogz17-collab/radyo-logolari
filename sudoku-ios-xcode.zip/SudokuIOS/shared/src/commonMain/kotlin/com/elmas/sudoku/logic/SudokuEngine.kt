package com.elmas.sudoku.logic

import kotlin.random.Random
import kotlin.time.TimeSource

enum class Difficulty(val removedCount: Int, val labelKey: String, val level: Int) {
    EASY(30, "diff_easy", 1),
    MEDIUM(40, "diff_medium", 2),
    HARD(50, "diff_hard", 3),
    ULTRA(58, "diff_ultra", 4)
}

/** Hücre türü: oyuncunun yazabildiği, bulmacanın verdiği veya ipucuyla açılan. */
object CellKind {
    const val FREE = 0
    const val GIVEN = 1
    const val HINTED = 2
}

/** 81 hücre satır satır tutulur, 0 boş demektir. */
class Puzzle(val cells: IntArray, val solution: IntArray)

object SudokuRules {

    /** Her hücrenin aynı satır, sütun ve kutudaki 20 komşusu. */
    val PEERS: Array<IntArray> = Array(81) { index ->
        val row = index / 9
        val col = index % 9
        val boxRow = row / 3 * 3
        val boxCol = col / 3 * 3
        val peers = LinkedHashSet<Int>()
        for (k in 0 until 9) {
            peers += row * 9 + k
            peers += k * 9 + col
        }
        for (r in boxRow until boxRow + 3) for (c in boxCol until boxCol + 3) peers += r * 9 + c
        peers -= index
        peers.toIntArray()
    }

    fun sameGroup(a: Int, b: Int): Boolean {
        if (a == b) return true
        val ra = a / 9
        val ca = a % 9
        val rb = b / 9
        val cb = b % 9
        return ra == rb || ca == cb || (ra / 3 == rb / 3 && ca / 3 == cb / 3)
    }

    fun conflicts(cells: List<Int>): BooleanArray {
        val result = BooleanArray(81)
        for (i in 0 until 81) {
            val v = cells[i]
            if (v == 0) continue
            for (p in PEERS[i]) {
                if (cells[p] == v) {
                    result[i] = true
                    break
                }
            }
        }
        return result
    }

    fun isSolved(cells: List<Int>): Boolean {
        for (i in 0 until 81) if (cells[i] !in 1..9) return false
        return conflicts(cells).none { it }
    }
}

/**
 * Tek çözümlü bulmaca üretir. Zorluk, boşaltılan hücre sayısıdır.
 * Tek çözüm korunarak hedef sayıya ulaşılamazsa en çok boşaltılan sonuç kullanılır.
 */
object SudokuGenerator {

    private const val ALL = 0x3FE
    private val origin = TimeSource.Monotonic.markNow()
    private fun nowMs(): Long = origin.elapsedNow().inWholeMilliseconds

    fun generate(difficulty: Difficulty, random: Random = Random.Default, budgetMs: Long = 1_500L): Puzzle {
        val deadline = nowMs() + budgetMs
        var best: Puzzle? = null
        var bestRemoved = -1
        for (pass in 0 until 8) {
            val solution = fullGrid(random)
            val cells = solution.copyOf()
            val removed = carve(cells, difficulty.removedCount, random, if (pass == 0) Long.MAX_VALUE else deadline)
            if (removed > bestRemoved) {
                best = Puzzle(cells, solution)
                bestRemoved = removed
            }
            if (bestRemoved >= difficulty.removedCount || nowMs() > deadline) break
        }
        return best!!
    }

    /** Çözüm sayısını en fazla [limit] olana kadar sayar. */
    fun countSolutions(cells: IntArray, limit: Int = 2): Int {
        val rows = IntArray(9)
        val cols = IntArray(9)
        val boxes = IntArray(9)
        for (i in 0 until 81) {
            val v = cells[i]
            if (v == 0) continue
            val bit = 1 shl v
            val r = i / 9
            val c = i % 9
            val b = r / 3 * 3 + c / 3
            if (rows[r] and bit != 0 || cols[c] and bit != 0 || boxes[b] and bit != 0) return 0
            rows[r] = rows[r] or bit
            cols[c] = cols[c] or bit
            boxes[b] = boxes[b] or bit
        }
        return search(cells.copyOf(), rows, cols, boxes, limit)
    }

    private fun search(g: IntArray, rows: IntArray, cols: IntArray, boxes: IntArray, limit: Int): Int {
        var best = -1
        var bestMask = 0
        var bestCount = 10
        for (i in 0 until 81) {
            if (g[i] != 0) continue
            val r = i / 9
            val c = i % 9
            val mask = ALL and (rows[r] or cols[c] or boxes[r / 3 * 3 + c / 3]).inv()
            val count = mask.countOneBits()
            if (count < bestCount) {
                best = i
                bestMask = mask
                bestCount = count
                if (count <= 1) break
            }
        }
        if (best == -1) return 1
        if (bestCount == 0) return 0

        val r = best / 9
        val c = best % 9
        val b = r / 3 * 3 + c / 3
        var total = 0
        var mask = bestMask
        while (mask != 0) {
            val bit = mask and -mask
            mask = mask xor bit
            g[best] = bit.countTrailingZeroBits()
            rows[r] = rows[r] or bit
            cols[c] = cols[c] or bit
            boxes[b] = boxes[b] or bit
            total += search(g, rows, cols, boxes, limit - total)
            g[best] = 0
            rows[r] = rows[r] and bit.inv()
            cols[c] = cols[c] and bit.inv()
            boxes[b] = boxes[b] and bit.inv()
            if (total >= limit) return total
        }
        return total
    }

    private fun fullGrid(random: Random): IntArray {
        val g = IntArray(81)
        fill(g, IntArray(9), IntArray(9), IntArray(9), random)
        return g
    }

    private fun fill(g: IntArray, rows: IntArray, cols: IntArray, boxes: IntArray, random: Random): Boolean {
        var best = -1
        var bestMask = 0
        var bestCount = 10
        for (i in 0 until 81) {
            if (g[i] != 0) continue
            val r = i / 9
            val c = i % 9
            val mask = ALL and (rows[r] or cols[c] or boxes[r / 3 * 3 + c / 3]).inv()
            val count = mask.countOneBits()
            if (count < bestCount) {
                best = i
                bestMask = mask
                bestCount = count
                if (count <= 1) break
            }
        }
        if (best == -1) return true
        if (bestCount == 0) return false

        val r = best / 9
        val c = best % 9
        val b = r / 3 * 3 + c / 3
        val digits = (1..9).filter { bestMask and (1 shl it) != 0 }.shuffled(random)
        for (v in digits) {
            val bit = 1 shl v
            g[best] = v
            rows[r] = rows[r] or bit
            cols[c] = cols[c] or bit
            boxes[b] = boxes[b] or bit
            if (fill(g, rows, cols, boxes, random)) return true
            g[best] = 0
            rows[r] = rows[r] and bit.inv()
            cols[c] = cols[c] and bit.inv()
            boxes[b] = boxes[b] and bit.inv()
        }
        return false
    }

    private fun carve(cells: IntArray, target: Int, random: Random, deadline: Long): Int {
        var removed = 0
        for (i in (0 until 81).shuffled(random)) {
            if (removed >= target) break
            if (nowMs() > deadline) break
            val keep = cells[i]
            cells[i] = 0
            if (countSolutions(cells, 2) == 1) removed++ else cells[i] = keep
        }
        return removed
    }
}
