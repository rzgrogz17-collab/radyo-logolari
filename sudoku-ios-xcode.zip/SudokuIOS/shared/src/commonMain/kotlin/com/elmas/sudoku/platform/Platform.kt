package com.elmas.sudoku.platform

import androidx.compose.runtime.mutableStateOf

interface KeyValueStore {
    fun getString(key: String, default: String = ""): String
    fun putString(key: String, value: String)
    fun getInt(key: String, default: Int): Int
    fun putInt(key: String, value: Int)
    fun getBoolean(key: String, default: Boolean): Boolean
    fun putBoolean(key: String, value: Boolean)
    fun remove(key: String)
}

expect fun createStore(): KeyValueStore

expect fun currentLanguage(): String

expect class SoundPlayer() {
    var isMuted: Boolean
    fun toggleSound(): Boolean
    fun playClick()
    fun playError()
    fun playSuccess()
    fun playPencil()
    fun playWin()
    fun playReward()
    fun release()
}

/** Uygulama öndeyken true. iOS sahne değişince Swift bunu günceller. */
object AppVisibility {
    val resumed = mutableStateOf(true)

    fun setResumed(value: Boolean) {
        resumed.value = value
    }
}
