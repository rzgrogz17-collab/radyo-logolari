package com.elmas.sudoku.ads

import androidx.compose.runtime.mutableStateOf

/**
 * Tam ekran reklamlar (geçiş ve ödüllü) ile gizlilik formu.
 * iOS tarafı uygulamayı açarken [player] alanını doldurur.
 */
interface RewardedPlayer {
    fun initialize(onReady: () -> Unit)
    fun showInterstitial()
    fun showRewarded(onReward: () -> Unit): Boolean
    fun privacyRequired(): Boolean
    fun showPrivacyOptions()
}

object Ads {
    var player: RewardedPlayer? = null

    val ready = mutableStateOf(false)
    val privacyOptionsRequired = mutableStateOf(false)

    private var started = false

    fun initialize() {
        if (started || !AdConfig.ADS_ENABLED) return
        val current = player ?: return
        started = true
        current.initialize {
            ready.value = true
            privacyOptionsRequired.value = current.privacyRequired()
        }
    }

    fun showInterstitial() {
        if (!AdConfig.ADS_ENABLED || !ready.value) return
        player?.showInterstitial()
    }

    /**
     * Ödüllü reklam hazırsa gösterir ve true döner. Ödül, reklam bitince bir kez verilir.
     * Hazır değilse false döner; çağıran taraf işlemi yapmaz.
     * Geçiş reklamına düşülmez.
     */
    fun showRewarded(onReward: () -> Unit): Boolean {
        if (!AdConfig.ADS_ENABLED) {
            onReward()
            return true
        }
        val current = player ?: return false
        if (!ready.value) return false
        return current.showRewarded(onReward)
    }

    fun showPrivacyOptions() {
        player?.showPrivacyOptions()
    }
}
