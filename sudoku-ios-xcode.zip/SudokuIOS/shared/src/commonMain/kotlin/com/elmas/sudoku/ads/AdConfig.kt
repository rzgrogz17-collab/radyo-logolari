package com.elmas.sudoku.ads

/**
 * Tek anahtar. Ülke listesi yok.
 *
 * USE_ADMOB = true  -> her yerde yalnızca AdMob
 * USE_ADMOB = false -> her yerde yalnızca AppLovin
 *
 * Bu projede yalnızca AdMob ve AppLovin vardır.
 *
 * AdMob uygulama kimliği ayrıca iosApp/iosApp/Info.plist içindeki
 * GADApplicationIdentifier ile aynı olmalıdır.
 * AppLovin SDK anahtarı da Info.plist içindeki AppLovinSdkKey ile aynı olmalıdır.
 * Birim kimlikleri yalnızca buradan okunur.
 *
 * Aşağıdaki AdMob kimlikleri Google'ın resmi test kimlikleridir.
 * Yayından önce kendi kimliklerinizle değiştirin.
 * AppLovin birim kimlikleri MAX panelinden alınır; hazır test kimliği yoktur.
 */
object AdConfig {
    const val ADS_ENABLED = true

    const val USE_ADMOB = true

    const val REWARD_AMOUNT = 3

    const val ADMOB_APP_ID = "ca-app-pub-3940256099942544~1458002511"
    const val ADMOB_BANNER_ID = "ca-app-pub-3940256099942544/2934735716"
    const val ADMOB_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/4411468910"
    const val ADMOB_REWARDED_ID = "ca-app-pub-3940256099942544/1712485313"
    const val ADMOB_NATIVE_ID = "ca-app-pub-3940256099942544/3986624511"

    const val APPLOVIN_SDK_KEY = "REPLACE_WITH_YOUR_APPLOVIN_SDK_KEY"
    const val APPLOVIN_BANNER_ID = "REPLACE_APPLOVIN_BANNER"
    const val APPLOVIN_INTERSTITIAL_ID = "REPLACE_APPLOVIN_INTERSTITIAL"
    const val APPLOVIN_REWARDED_ID = "REPLACE_APPLOVIN_REWARDED"
    const val APPLOVIN_NATIVE_ID = "REPLACE_APPLOVIN_NATIVE"

    fun useAdMob(): Boolean = USE_ADMOB
    fun admobBannerId(): String = ADMOB_BANNER_ID
    fun admobInterstitialId(): String = ADMOB_INTERSTITIAL_ID
    fun admobRewardedId(): String = ADMOB_REWARDED_ID
    fun admobNativeId(): String = ADMOB_NATIVE_ID
    fun appLovinSdkKey(): String = APPLOVIN_SDK_KEY
    fun appLovinBannerId(): String = APPLOVIN_BANNER_ID
    fun appLovinInterstitialId(): String = APPLOVIN_INTERSTITIAL_ID
    fun appLovinRewardedId(): String = APPLOVIN_REWARDED_ID
    fun appLovinNativeId(): String = APPLOVIN_NATIVE_ID
}
