package com.elmas.sudoku.ads

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.elmas.sudoku.theme.SudokuPalette

/** Oyun ekranının altındaki banner. Reklam ağı USE_ADMOB anahtarına göre seçilir. */
@Composable
expect fun BannerAd(modifier: Modifier = Modifier)

/** Menüdeki tam genişlik native kart. Logo şeridinin yerini alır. */
@Composable
expect fun NativeAdCard(palette: SudokuPalette, modifier: Modifier = Modifier)
