package com.elmas.sudoku.ads

import platform.UIKit.UIView

/**
 * Swift tarafının uyguladığı reklam köprüsü.
 * true ise AdMob, false ise AppLovin. Seçim [AdConfig.USE_ADMOB] içindedir.
 */
interface IosAdHost {
    fun start(onReady: () -> Unit)
    fun attachBanner(container: UIView, onLoaded: () -> Unit, onFailed: () -> Unit)
    fun detachBanner(container: UIView)
    fun attachNative(container: UIView, dark: Boolean, onLoaded: () -> Unit, onFailed: () -> Unit)
    fun updateNativeTheme(container: UIView, dark: Boolean)
    fun detachNative(container: UIView)
    fun showInterstitial()
    fun showRewarded(onReward: () -> Unit): Boolean
    fun isPrivacyRequired(): Boolean
    fun showPrivacyOptions()
}

object IosAds {
    var host: IosAdHost? = null
}

fun installIosAds(host: IosAdHost) {
    IosAds.host = host
    Ads.player = object : RewardedPlayer {
        override fun initialize(onReady: () -> Unit) = host.start(onReady)
        override fun showInterstitial() = host.showInterstitial()
        override fun showRewarded(onReward: () -> Unit): Boolean = host.showRewarded(onReward)
        override fun privacyRequired(): Boolean = host.isPrivacyRequired()
        override fun showPrivacyOptions() = host.showPrivacyOptions()
    }
}
