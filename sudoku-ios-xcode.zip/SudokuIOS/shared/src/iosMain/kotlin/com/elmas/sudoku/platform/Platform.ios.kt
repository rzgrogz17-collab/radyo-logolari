@file:OptIn(kotlinx.cinterop.ExperimentalForeignApi::class)

package com.elmas.sudoku.platform

import platform.AudioToolbox.AudioServicesPlaySystemSound
import platform.Foundation.NSLocale
import platform.Foundation.NSUserDefaults

actual fun createStore(): KeyValueStore = IosStore()

actual fun currentLanguage(): String {
    val first = NSLocale.preferredLanguages.firstOrNull()?.toString() ?: "en"
    return first.substringBefore("-").substringBefore("_").lowercase()
}

private class IosStore : KeyValueStore {
    private val defaults = NSUserDefaults.standardUserDefaults

    override fun getString(key: String, default: String): String =
        defaults.stringForKey(key) ?: default

    override fun putString(key: String, value: String) {
        defaults.setObject(value, forKey = key)
    }

    override fun getInt(key: String, default: Int): Int {
        if (defaults.objectForKey(key) == null) return default
        return defaults.integerForKey(key).toInt()
    }

    override fun putInt(key: String, value: Int) {
        defaults.setInteger(value.toLong(), forKey = key)
    }

    override fun getBoolean(key: String, default: Boolean): Boolean {
        if (defaults.objectForKey(key) == null) return default
        return defaults.boolForKey(key)
    }

    override fun putBoolean(key: String, value: Boolean) {
        defaults.setBool(value, forKey = key)
    }

    override fun remove(key: String) {
        defaults.removeObjectForKey(key)
    }
}

actual class SoundPlayer actual constructor() {
    actual var isMuted: Boolean = false

    actual fun toggleSound(): Boolean {
        isMuted = !isMuted
        return isMuted
    }

    actual fun playClick() = tone(1104u)
    actual fun playError() = tone(1053u)
    actual fun playSuccess() = tone(1025u)
    actual fun playPencil() = tone(1103u)
    actual fun playWin() = tone(1025u)
    actual fun playReward() = tone(1057u)
    actual fun release() = Unit

    private fun tone(id: UInt) {
        if (!isMuted) AudioServicesPlaySystemSound(id)
    }
}
