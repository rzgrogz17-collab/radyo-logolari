package com.elmas.sudoku.ads

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.UIKitView
import androidx.compose.ui.unit.dp
import com.elmas.sudoku.theme.SudokuPalette
import kotlinx.coroutines.delay
import platform.UIKit.UIColor
import platform.UIKit.UIView

@Composable
actual fun BannerAd(modifier: Modifier) {
    if (!AdConfig.ADS_ENABLED) return
    val ready by Ads.ready
    if (!ready) return
    val host = IosAds.host ?: return
    var attempt by remember { mutableIntStateOf(0) }
    var failed by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }

    LaunchedEffect(failed, attempt) {
        if (failed && !loaded && attempt < 4) {
            delay(20_000L * (attempt + 1))
            failed = false
            attempt++
        }
    }

    key(attempt) {
        UIKitView(
            factory = {
                val view = UIView()
                view.backgroundColor = UIColor.clearColor
                view.clipsToBounds = true
                host.attachBanner(
                    view,
                    onLoaded = { loaded = true },
                    onFailed = { if (!loaded) failed = true }
                )
                view
            },
            modifier = modifier.fillMaxWidth().height(50.dp),
            onRelease = { host.detachBanner(it) }
        )
    }
}

@Composable
actual fun NativeAdCard(palette: SudokuPalette, modifier: Modifier) {
    if (!AdConfig.ADS_ENABLED) return
    val ready by Ads.ready
    if (!ready) return
    val host = IosAds.host ?: return
    val dark = palette.dark
    var attempt by remember { mutableIntStateOf(0) }
    var failed by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }

    LaunchedEffect(failed, attempt) {
        if (failed && !loaded && attempt < 3) {
            delay(15_000L * (attempt + 1))
            failed = false
            attempt++
        }
    }
    if (failed && !loaded) return

    key(attempt) {
        UIKitView(
            factory = {
                val view = UIView()
                view.backgroundColor = UIColor.clearColor
                view.clipsToBounds = true
                host.attachNative(
                    view,
                    dark,
                    onLoaded = { loaded = true },
                    onFailed = { if (!loaded) failed = true }
                )
                view
            },
            modifier = modifier.fillMaxWidth().height(if (loaded) 132.dp else 0.dp),
            update = { host.updateNativeTheme(it, dark) },
            onRelease = { host.detachNative(it) }
        )
    }
}
