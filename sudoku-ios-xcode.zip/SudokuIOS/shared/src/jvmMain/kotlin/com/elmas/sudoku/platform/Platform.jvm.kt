package com.elmas.sudoku.platform

import java.util.Locale

actual fun createStore(): KeyValueStore = MemoryStore()

actual fun currentLanguage(): String = Locale.getDefault().language.lowercase()

private class MemoryStore : KeyValueStore {
    private val strings = HashMap<String, String>()
    private val ints = HashMap<String, Int>()
    private val bools = HashMap<String, Boolean>()

    override fun getString(key: String, default: String) = strings[key] ?: default
    override fun putString(key: String, value: String) { strings[key] = value }
    override fun getInt(key: String, default: Int) = ints[key] ?: default
    override fun putInt(key: String, value: Int) { ints[key] = value }
    override fun getBoolean(key: String, default: Boolean) = bools[key] ?: default
    override fun putBoolean(key: String, value: Boolean) { bools[key] = value }
    override fun remove(key: String) {
        strings.remove(key)
        ints.remove(key)
        bools.remove(key)
    }
}

actual class SoundPlayer actual constructor() {
    actual var isMuted: Boolean = false
    actual fun toggleSound(): Boolean {
        isMuted = !isMuted
        return isMuted
    }
    actual fun playClick() = Unit
    actual fun playError() = Unit
    actual fun playSuccess() = Unit
    actual fun playPencil() = Unit
    actual fun playWin() = Unit
    actual fun playReward() = Unit
    actual fun release() = Unit
}
