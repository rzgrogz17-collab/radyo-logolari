package com.elmas.sudoku.ads

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.elmas.sudoku.theme.SudokuPalette

@Composable
actual fun BannerAd(modifier: Modifier) = Unit

@Composable
actual fun NativeAdCard(palette: SudokuPalette, modifier: Modifier) = Unit
