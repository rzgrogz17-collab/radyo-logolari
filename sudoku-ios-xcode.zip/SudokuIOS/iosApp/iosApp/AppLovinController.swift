import UIKit
import AppTrackingTransparency
import AppLovinSDK

/// Banner, native, geçiş ve ödüllü AppLovin MAX. Ödül yalnızca izlenince verilir.
final class AppLovinController: NSObject, MAAdViewAdDelegate, MARewardedAdDelegate, MANativeAdDelegate {
    private var interstitial: MAInterstitialAd?
    private var rewarded: MARewardedAd?
    private var interstitialAttempt = 0.0
    private var rewardedAttempt = 0.0
    private var rewardCallback: (() -> Void)?
    private var rewardGranted = false
    private var started = false

    private var banners: [ObjectIdentifier: MAAdView] = [:]
    private var bannerLoaded: [ObjectIdentifier: () -> Void] = [:]
    private var bannerFailed: [ObjectIdentifier: () -> Void] = [:]

    private final class NativeSlot {
        let loader: MANativeAdLoader
        let card: MANativeAdView
        var ad: MAAd?
        let onLoaded: () -> Void
        let onFailed: () -> Void
        let headline: UILabel
        let body: UILabel
        let badge: UILabel
        let button: UIButton
        init(loader: MANativeAdLoader, card: MANativeAdView, onLoaded: @escaping () -> Void, onFailed: @escaping () -> Void,
             headline: UILabel, body: UILabel, badge: UILabel, button: UIButton) {
            self.loader = loader
            self.card = card
            self.onLoaded = onLoaded
            self.onFailed = onFailed
            self.headline = headline
            self.body = body
            self.badge = badge
            self.button = button
        }
    }
    private var natives: [ObjectIdentifier: NativeSlot] = [:]

    func start(onReady: @escaping () -> Void) {
        let key = AdConfig.shared.appLovinSdkKey()
        guard !key.hasPrefix("REPLACE") else {
            print("AppLovin SDK anahtarı AdConfig.kt ve Info.plist içinde değiştirilmeli.")
            DispatchQueue.main.async { onReady() }
            return
        }
        requestTracking {
            let settings = ALSdk.shared().settings
            settings.isVerboseLoggingEnabled = true
            let config = ALSdkInitializationConfiguration(sdkKey: key) { builder in
                builder.mediationProvider = ALMediationProviderMAX
            }
            ALSdk.shared().initialize(with: config) { _ in
                DispatchQueue.main.async {
                    self.started = true
                    self.loadInterstitial()
                    self.loadRewarded()
                    onReady()
                }
            }
        }
    }

    func attachBanner(container: UIView, onLoaded: @escaping () -> Void, onFailed: @escaping () -> Void) {
        let banner = MAAdView(adUnitIdentifier: AdConfig.shared.appLovinBannerId())
        banner.delegate = self
        banner.translatesAutoresizingMaskIntoConstraints = false
        banner.backgroundColor = .clear
        container.addSubview(banner)
        NSLayoutConstraint.activate([
            banner.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            banner.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            banner.topAnchor.constraint(equalTo: container.topAnchor),
            banner.bottomAnchor.constraint(equalTo: container.bottomAnchor)
        ])
        let id = ObjectIdentifier(container)
        banners[id] = banner
        bannerLoaded[id] = onLoaded
        bannerFailed[id] = onFailed
        if started { banner.loadAd() }
    }

    func detachBanner(container: UIView) {
        let id = ObjectIdentifier(container)
        banners[id]?.stopAutoRefresh()
        banners[id]?.removeFromSuperview()
        banners[id] = nil
        bannerLoaded[id] = nil
        bannerFailed[id] = nil
    }

    func attachNative(container: UIView, dark: Bool, onLoaded: @escaping () -> Void, onFailed: @escaping () -> Void) {
        let built = AppLovinNativeCard.build(dark: dark)
        built.card.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(built.card)
        NSLayoutConstraint.activate([
            built.card.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            built.card.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            built.card.topAnchor.constraint(equalTo: container.topAnchor),
            built.card.bottomAnchor.constraint(equalTo: container.bottomAnchor)
        ])
        let loader = MANativeAdLoader(adUnitIdentifier: AdConfig.shared.appLovinNativeId())
        loader.nativeAdDelegate = self
        let slot = NativeSlot(
            loader: loader, card: built.card, onLoaded: onLoaded, onFailed: onFailed,
            headline: built.headline, body: built.body, badge: built.badge, button: built.button
        )
        natives[ObjectIdentifier(container)] = slot
        if started { loader.loadAd(into: built.card) }
    }

    func updateNativeTheme(container: UIView, dark: Bool) {
        guard let slot = natives[ObjectIdentifier(container)] else { return }
        AppLovinNativeCard.apply(dark: dark, card: slot.card, headline: slot.headline, body: slot.body, badge: slot.badge, button: slot.button)
    }

    func detachNative(container: UIView) {
        let id = ObjectIdentifier(container)
        if let slot = natives[id] {
            if let ad = slot.ad { slot.loader.destroy(ad) }
            slot.card.removeFromSuperview()
        }
        natives[id] = nil
    }

    func showInterstitial() {
        guard let interstitial, interstitial.isReady else {
            loadInterstitial()
            return
        }
        interstitial.show()
    }

    func showRewarded(onReward: @escaping () -> Void) -> Bool {
        guard let rewarded, rewarded.isReady else {
            loadRewarded()
            return false
        }
        rewardGranted = false
        rewardCallback = onReward
        rewarded.show()
        return true
    }

    func didLoad(_ ad: MAAd) {
        if ad.adUnitIdentifier == AdConfig.shared.appLovinBannerId() {
            bannerLoaded.values.forEach { $0() }
        } else if ad.adUnitIdentifier == AdConfig.shared.appLovinInterstitialId() {
            interstitialAttempt = 0
        } else if ad.adUnitIdentifier == AdConfig.shared.appLovinRewardedId() {
            rewardedAttempt = 0
        }
    }

    func didFailToLoadAd(forAdUnitIdentifier adUnitIdentifier: String, withError error: MAError) {
        if adUnitIdentifier == AdConfig.shared.appLovinBannerId() {
            bannerFailed.values.forEach { $0() }
        } else if adUnitIdentifier == AdConfig.shared.appLovinInterstitialId() {
            schedule(attempt: &interstitialAttempt) { self.loadInterstitial() }
        } else if adUnitIdentifier == AdConfig.shared.appLovinRewardedId() {
            schedule(attempt: &rewardedAttempt) { self.loadRewarded() }
        }
    }

    func didDisplay(_ ad: MAAd) {}
    func didHide(_ ad: MAAd) {
        rewardCallback = nil
        if ad.adUnitIdentifier == AdConfig.shared.appLovinInterstitialId() { loadInterstitial() }
        if ad.adUnitIdentifier == AdConfig.shared.appLovinRewardedId() { loadRewarded() }
    }
    func didClick(_ ad: MAAd) {}
    func didFail(toDisplay ad: MAAd, withError error: MAError) {
        rewardCallback = nil
        if ad.adUnitIdentifier == AdConfig.shared.appLovinInterstitialId() { loadInterstitial() }
        if ad.adUnitIdentifier == AdConfig.shared.appLovinRewardedId() { loadRewarded() }
    }
    func didExpand(_ ad: MAAd) {}
    func didCollapse(_ ad: MAAd) {}

    func didRewardUser(for ad: MAAd, with reward: MAReward) {
        guard !rewardGranted else { return }
        rewardGranted = true
        let callback = rewardCallback
        rewardCallback = nil
        DispatchQueue.main.async { callback?() }
    }

    func didLoadNativeAd(_ nativeAdView: MANativeAdView?, for ad: MAAd) {
        guard let slot = natives.values.first(where: { $0.loader.adUnitIdentifier == ad.adUnitIdentifier }) else { return }
        slot.ad = ad
        guard nativeAdView != nil else {
            slot.onFailed()
            return
        }
        slot.onLoaded()
    }

    func didFailToLoadNativeAd(forAdUnitIdentifier adUnitIdentifier: String, withError error: MAError) {
        natives.values.first { $0.loader.adUnitIdentifier == adUnitIdentifier }?.onFailed()
    }

    func didClickNativeAd(_ ad: MAAd) {}

    private func loadInterstitial() {
        guard started else { return }
        if interstitial == nil {
            let ad = MAInterstitialAd(adUnitIdentifier: AdConfig.shared.appLovinInterstitialId())
            ad.delegate = self
            interstitial = ad
        }
        interstitial?.loadAd()
    }

    private func loadRewarded() {
        guard started else { return }
        if rewarded == nil {
            let ad = MARewardedAd.shared(withAdUnitIdentifier: AdConfig.shared.appLovinRewardedId())
            ad.delegate = self
            rewarded = ad
        }
        rewarded?.loadAd()
    }

    private func schedule(attempt: inout Double, action: @escaping () -> Void) {
        guard attempt < 6 else { return }
        attempt += 1
        let delay = min(60.0, pow(2.0, attempt))
        DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: action)
    }

    private func requestTracking(_ done: @escaping () -> Void) {
        if #available(iOS 14, *) {
            ATTrackingManager.requestTrackingAuthorization { _ in
                DispatchQueue.main.async { done() }
            }
        } else {
            done()
        }
    }
}

private enum AppLovinNativeCard {
    static let titleTag = 100
    static let advertiserTag = 101
    static let bodyTag = 102
    static let iconTag = 103
    static let optionsTag = 104
    static let mediaTag = 105
    static let ctaTag = 106

    static func build(dark: Bool) -> (card: MANativeAdView, headline: UILabel, body: UILabel, badge: UILabel, button: UIButton) {
        let card = MANativeAdView()
        let icon = UIImageView()
        icon.tag = iconTag
        icon.contentMode = .scaleAspectFill
        icon.clipsToBounds = true
        icon.layer.cornerRadius = 8
        let media = UIView()
        media.tag = mediaTag
        media.clipsToBounds = true
        media.layer.cornerRadius = 8
        let options = UIView()
        options.tag = optionsTag
        let headline = UILabel()
        headline.tag = titleTag
        headline.font = .boldSystemFont(ofSize: 15)
        headline.numberOfLines = 1
        let body = UILabel()
        body.tag = bodyTag
        body.font = .systemFont(ofSize: 12)
        body.numberOfLines = 2
        let advertiser = UILabel()
        advertiser.tag = advertiserTag
        advertiser.font = .systemFont(ofSize: 11)
        let badge = UILabel()
        badge.text = "Ad"
        badge.font = .boldSystemFont(ofSize: 10)
        badge.textAlignment = .center
        badge.layer.cornerRadius = 4
        badge.clipsToBounds = true
        let button = UIButton(type: .system)
        button.tag = ctaTag
        button.titleLabel?.font = .boldSystemFont(ofSize: 13)
        button.layer.cornerRadius = 10
        let views = [icon, media, options, headline, body, advertiser, badge, button]
        views.forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
            card.addSubview($0)
        }
        NSLayoutConstraint.activate([
            icon.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 12),
            icon.topAnchor.constraint(equalTo: card.topAnchor, constant: 12),
            icon.widthAnchor.constraint(equalToConstant: 44),
            icon.heightAnchor.constraint(equalToConstant: 44),
            media.leadingAnchor.constraint(equalTo: icon.leadingAnchor),
            media.topAnchor.constraint(equalTo: icon.bottomAnchor, constant: 8),
            media.widthAnchor.constraint(equalToConstant: 44),
            media.heightAnchor.constraint(equalToConstant: 44),
            options.topAnchor.constraint(equalTo: card.topAnchor, constant: 8),
            options.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -8),
            options.widthAnchor.constraint(equalToConstant: 20),
            options.heightAnchor.constraint(equalToConstant: 20),
            badge.leadingAnchor.constraint(equalTo: icon.trailingAnchor, constant: 10),
            badge.topAnchor.constraint(equalTo: card.topAnchor, constant: 12),
            badge.widthAnchor.constraint(equalToConstant: 28),
            badge.heightAnchor.constraint(equalToConstant: 16),
            headline.leadingAnchor.constraint(equalTo: badge.trailingAnchor, constant: 6),
            headline.trailingAnchor.constraint(equalTo: options.leadingAnchor, constant: -6),
            headline.centerYAnchor.constraint(equalTo: badge.centerYAnchor),
            body.leadingAnchor.constraint(equalTo: badge.leadingAnchor),
            body.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -12),
            body.topAnchor.constraint(equalTo: badge.bottomAnchor, constant: 4),
            advertiser.leadingAnchor.constraint(equalTo: body.leadingAnchor),
            advertiser.trailingAnchor.constraint(equalTo: body.trailingAnchor),
            advertiser.topAnchor.constraint(equalTo: body.bottomAnchor, constant: 2),
            button.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -12),
            button.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -10),
            button.heightAnchor.constraint(equalToConstant: 32),
            button.widthAnchor.constraint(greaterThanOrEqualToConstant: 88)
        ])
        let binder = MANativeAdViewBinder { builder in
            builder.titleLabelTag = titleTag
            builder.advertiserLabelTag = advertiserTag
            builder.bodyLabelTag = bodyTag
            builder.iconImageViewTag = iconTag
            builder.optionsContentViewTag = optionsTag
            builder.mediaContentViewTag = mediaTag
            builder.callToActionButtonTag = ctaTag
        }
        card.bindViews(with: binder)
        apply(dark: dark, card: card, headline: headline, body: body, badge: badge, button: button)
        return (card, headline, body, badge, button)
    }

    static func apply(dark: Bool, card: MANativeAdView, headline: UILabel, body: UILabel, badge: UILabel, button: UIButton) {
        card.backgroundColor = dark ? UIColor(white: 0.09, alpha: 0.92) : UIColor(white: 1, alpha: 0.97)
        headline.textColor = dark ? .white : UIColor(white: 0.12, alpha: 1)
        body.textColor = dark ? UIColor(white: 1, alpha: 0.72) : UIColor(white: 0.15, alpha: 0.7)
        badge.backgroundColor = dark ? UIColor(red: 0.16, green: 0.47, blue: 1, alpha: 1) : UIColor(red: 0, green: 0.48, blue: 1, alpha: 1)
        badge.textColor = .white
        button.backgroundColor = badge.backgroundColor
        button.setTitleColor(.white, for: .normal)
    }
}
