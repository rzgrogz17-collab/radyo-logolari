import UIKit
import AppTrackingTransparency
import GoogleMobileAds
import UserMessagingPlatform

/// Banner, native, geçiş ve ödüllü AdMob. Ödül yalnızca izlenince verilir.
final class AdMobController: NSObject, BannerViewDelegate, FullScreenContentDelegate, NativeAdLoaderDelegate {
    private var interstitial: InterstitialAd?
    private var rewarded: RewardedAd?
    private var interstitialAttempt = 0
    private var rewardedAttempt = 0
    private var rewardCallback: (() -> Void)?
    private var rewardGranted = false

    private var banners: [ObjectIdentifier: BannerView] = [:]
    private var bannerLoaded: [ObjectIdentifier: () -> Void] = [:]
    private var bannerFailed: [ObjectIdentifier: () -> Void] = [:]

    private final class NativeSlot {
        let loader: AdLoader
        let card: NativeAdView
        var ad: NativeAd?
        let onLoaded: () -> Void
        let onFailed: () -> Void
        var headline: UILabel
        var body: UILabel
        var badge: UILabel
        var button: UIButton
        init(loader: AdLoader, card: NativeAdView, onLoaded: @escaping () -> Void, onFailed: @escaping () -> Void,
             headline: UILabel, body: UILabel, badge: UILabel, button: UIButton) {
            self.loader = loader
            self.card = card
            self.onLoaded = onLoaded
            self.onFailed = onFailed
            self.headline = headline
            self.body = body
            self.badge = badge
            self.button = button
        }
    }
    private var natives: [ObjectIdentifier: NativeSlot] = [:]
    private(set) var privacyRequired = false
    private var adsStarted = false

    func start(onReady: @escaping () -> Void) {
        requestTracking {
            self.gatherConsent {
                let canRequest = ConsentInformation.shared.canRequestAds
                self.privacyRequired = ConsentInformation.shared.privacyOptionsRequirementStatus == .required
                guard canRequest else {
                    DispatchQueue.main.async { onReady() }
                    return
                }
                MobileAds.shared.start { _ in
                    DispatchQueue.main.async {
                        self.adsStarted = true
                        self.loadInterstitial()
                        self.loadRewarded()
                        onReady()
                    }
                }
            }
        }
    }

    func showPrivacyOptions() {
        ConsentForm.presentPrivacyOptionsForm(from: RootController.top()) { _ in
            self.privacyRequired = ConsentInformation.shared.privacyOptionsRequirementStatus == .required
        }
    }

    func attachBanner(container: UIView, onLoaded: @escaping () -> Void, onFailed: @escaping () -> Void) {
        let banner = BannerView(adSize: AdSizeBanner)
        banner.adUnitID = AdConfig.shared.admobBannerId()
        banner.rootViewController = RootController.top()
        banner.delegate = self
        banner.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(banner)
        NSLayoutConstraint.activate([
            banner.centerXAnchor.constraint(equalTo: container.centerXAnchor),
            banner.centerYAnchor.constraint(equalTo: container.centerYAnchor)
        ])
        let key = ObjectIdentifier(container)
        banners[key] = banner
        bannerLoaded[key] = onLoaded
        bannerFailed[key] = onFailed
        if adsStarted { banner.load(Request()) }
    }

    func detachBanner(container: UIView) {
        let key = ObjectIdentifier(container)
        banners[key]?.removeFromSuperview()
        banners[key] = nil
        bannerLoaded[key] = nil
        bannerFailed[key] = nil
    }

    func attachNative(container: UIView, dark: Bool, onLoaded: @escaping () -> Void, onFailed: @escaping () -> Void) {
        let built = NativeCard.build(dark: dark)
        built.card.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(built.card)
        NSLayoutConstraint.activate([
            built.card.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            built.card.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            built.card.topAnchor.constraint(equalTo: container.topAnchor),
            built.card.bottomAnchor.constraint(equalTo: container.bottomAnchor)
        ])
        let loader = AdLoader(
            adUnitID: AdConfig.shared.admobNativeId(),
            rootViewController: RootController.top(),
            adTypes: [.native],
            options: nil
        )
        loader.delegate = self
        let slot = NativeSlot(
            loader: loader, card: built.card, onLoaded: onLoaded, onFailed: onFailed,
            headline: built.headline, body: built.body, badge: built.badge, button: built.button
        )
        natives[ObjectIdentifier(container)] = slot
        if adsStarted { loader.load(Request()) }
    }

    func updateNativeTheme(container: UIView, dark: Bool) {
        guard let slot = natives[ObjectIdentifier(container)] else { return }
        NativeCard.apply(dark: dark, card: slot.card, headline: slot.headline, body: slot.body, badge: slot.badge, button: slot.button)
    }

    func detachNative(container: UIView) {
        let key = ObjectIdentifier(container)
        if let slot = natives[key] {
            slot.ad = nil
            slot.card.nativeAd = nil
            slot.card.removeFromSuperview()
        }
        natives[key] = nil
    }

    func showInterstitial() {
        guard let ad = interstitial, let root = RootController.top() else {
            loadInterstitial()
            return
        }
        interstitial = nil
        ad.present(from: root)
    }

    func showRewarded(onReward: @escaping () -> Void) -> Bool {
        guard let ad = rewarded, let root = RootController.top() else {
            loadRewarded()
            return false
        }
        rewardGranted = false
        rewardCallback = onReward
        rewarded = nil
        ad.present(from: root) { [weak self] in
            self?.grantReward()
        }
        return true
    }

    func bannerViewDidReceiveAd(_ bannerView: BannerView) {
        let key = banners.first { $0.value === bannerView }?.key
        if let key { bannerLoaded[key]?() }
    }

    func bannerView(_ bannerView: BannerView, didFailToReceiveAdWithError error: Error) {
        let key = banners.first { $0.value === bannerView }?.key
        if let key { bannerFailed[key]?() }
    }

    func adLoader(_ adLoader: AdLoader, didReceive nativeAd: NativeAd) {
        guard let slot = natives.values.first(where: { $0.loader === adLoader }) else { return }
        nativeAd.delegate = nil
        slot.ad = nativeAd
        let card = slot.card
        (card.headlineView as? UILabel)?.text = nativeAd.headline
        card.mediaView?.mediaContent = nativeAd.mediaContent
        (card.bodyView as? UILabel)?.text = nativeAd.body
        card.bodyView?.isHidden = nativeAd.body == nil
        (card.callToActionView as? UIButton)?.setTitle(nativeAd.callToAction, for: .normal)
        card.callToActionView?.isHidden = nativeAd.callToAction == nil
        card.callToActionView?.isUserInteractionEnabled = false
        (card.iconView as? UIImageView)?.image = nativeAd.icon?.image
        card.iconView?.isHidden = nativeAd.icon == nil
        (card.advertiserView as? UILabel)?.text = nativeAd.advertiser
        card.advertiserView?.isHidden = nativeAd.advertiser == nil
        card.nativeAd = nativeAd
        slot.onLoaded()
    }

    func adLoader(_ adLoader: AdLoader, didFailToReceiveAdWithError error: Error) {
        natives.values.first { $0.loader === adLoader }?.onFailed()
    }

    func adDidDismissFullScreenContent(_ ad: FullScreenPresentingAd) {
        rewardCallback = nil
        loadInterstitial()
        loadRewarded()
    }

    func ad(_ ad: FullScreenPresentingAd, didFailToPresentFullScreenContentWithError error: Error) {
        rewardCallback = nil
        loadInterstitial()
        loadRewarded()
    }

    private func grantReward() {
        guard !rewardGranted else { return }
        rewardGranted = true
        let callback = rewardCallback
        rewardCallback = nil
        DispatchQueue.main.async { callback?() }
    }

    private func loadInterstitial() {
        guard adsStarted, interstitial == nil else { return }
        InterstitialAd.load(with: AdConfig.shared.admobInterstitialId(), request: Request()) { [weak self] ad, error in
            DispatchQueue.main.async {
                guard let self else { return }
                if let ad {
                    ad.fullScreenContentDelegate = self
                    self.interstitial = ad
                    self.interstitialAttempt = 0
                } else {
                    self.scheduleInterstitial()
                }
            }
        }
    }

    private func loadRewarded() {
        guard adsStarted, rewarded == nil else { return }
        RewardedAd.load(with: AdConfig.shared.admobRewardedId(), request: Request()) { [weak self] ad, error in
            DispatchQueue.main.async {
                guard let self else { return }
                if let ad {
                    ad.fullScreenContentDelegate = self
                    self.rewarded = ad
                    self.rewardedAttempt = 0
                } else {
                    self.scheduleRewarded()
                }
            }
        }
    }

    private func scheduleInterstitial() {
        guard interstitialAttempt < 6 else { return }
        interstitialAttempt += 1
        let delay = min(60.0, pow(2.0, Double(interstitialAttempt)) * 2.5)
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) { self.loadInterstitial() }
    }

    private func scheduleRewarded() {
        guard rewardedAttempt < 6 else { return }
        rewardedAttempt += 1
        let delay = min(60.0, pow(2.0, Double(rewardedAttempt)) * 2.5)
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) { self.loadRewarded() }
    }

    private func requestTracking(_ done: @escaping () -> Void) {
        if #available(iOS 14, *) {
            ATTrackingManager.requestTrackingAuthorization { _ in
                DispatchQueue.main.async { done() }
            }
        } else {
            done()
        }
    }

    private func gatherConsent(_ done: @escaping () -> Void) {
        let parameters = RequestParameters()
        ConsentInformation.shared.requestConsentInfoUpdate(with: parameters) { _ in
            ConsentForm.loadAndPresentIfRequired(from: RootController.top()) { _ in
                DispatchQueue.main.async { done() }
            }
        }
    }
}

private enum NativeCard {
    static func build(dark: Bool) -> (card: NativeAdView, headline: UILabel, body: UILabel, badge: UILabel, button: UIButton) {
        let card = NativeAdView()
        let icon = UIImageView()
        icon.contentMode = .scaleAspectFill
        icon.clipsToBounds = true
        icon.layer.cornerRadius = 8
        icon.tag = 1
        let media = MediaView()
        media.contentMode = .scaleAspectFill
        media.clipsToBounds = true
        media.layer.cornerRadius = 8
        let headline = UILabel()
        headline.font = .boldSystemFont(ofSize: 15)
        headline.numberOfLines = 1
        let body = UILabel()
        body.font = .systemFont(ofSize: 12)
        body.numberOfLines = 2
        let badge = UILabel()
        badge.text = "Ad"
        badge.font = .boldSystemFont(ofSize: 10)
        badge.textAlignment = .center
        badge.layer.cornerRadius = 4
        badge.clipsToBounds = true
        let advertiser = UILabel()
        advertiser.font = .systemFont(ofSize: 11)
        let button = UIButton(type: .system)
        button.titleLabel?.font = .boldSystemFont(ofSize: 13)
        button.layer.cornerRadius = 10
        button.isUserInteractionEnabled = false

        let views = [card, icon, media, headline, body, badge, advertiser, button]
        views.forEach { $0.translatesAutoresizingMaskIntoConstraints = false }
        card.addSubview(icon)
        card.addSubview(media)
        card.addSubview(badge)
        card.addSubview(headline)
        card.addSubview(body)
        card.addSubview(advertiser)
        card.addSubview(button)
        NSLayoutConstraint.activate([
            icon.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 12),
            icon.topAnchor.constraint(equalTo: card.topAnchor, constant: 12),
            icon.widthAnchor.constraint(equalToConstant: 44),
            icon.heightAnchor.constraint(equalToConstant: 44),
            media.leadingAnchor.constraint(equalTo: icon.leadingAnchor),
            media.topAnchor.constraint(equalTo: icon.bottomAnchor, constant: 8),
            media.widthAnchor.constraint(equalToConstant: 44),
            media.heightAnchor.constraint(equalToConstant: 44),
            badge.leadingAnchor.constraint(equalTo: icon.trailingAnchor, constant: 10),
            badge.topAnchor.constraint(equalTo: card.topAnchor, constant: 12),
            badge.widthAnchor.constraint(equalToConstant: 28),
            badge.heightAnchor.constraint(equalToConstant: 16),
            headline.leadingAnchor.constraint(equalTo: badge.trailingAnchor, constant: 6),
            headline.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -12),
            headline.centerYAnchor.constraint(equalTo: badge.centerYAnchor),
            body.leadingAnchor.constraint(equalTo: badge.leadingAnchor),
            body.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -12),
            body.topAnchor.constraint(equalTo: badge.bottomAnchor, constant: 4),
            advertiser.leadingAnchor.constraint(equalTo: body.leadingAnchor),
            advertiser.topAnchor.constraint(equalTo: body.bottomAnchor, constant: 2),
            advertiser.trailingAnchor.constraint(equalTo: body.trailingAnchor),
            button.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -12),
            button.bottomAnchor.constraint(equalTo: card.bottomAnchor, constant: -10),
            button.heightAnchor.constraint(equalToConstant: 32),
            button.widthAnchor.constraint(greaterThanOrEqualToConstant: 88)
        ])
        card.headlineView = headline
        card.bodyView = body
        card.iconView = icon
        card.mediaView = media
        card.callToActionView = button
        card.advertiserView = advertiser
        apply(dark: dark, card: card, headline: headline, body: body, badge: badge, button: button)
        return (card, headline, body, badge, button)
    }

    static func apply(dark: Bool, card: NativeAdView, headline: UILabel, body: UILabel, badge: UILabel, button: UIButton) {
        card.backgroundColor = dark ? UIColor(white: 0.09, alpha: 0.92) : UIColor(white: 1, alpha: 0.97)
        headline.textColor = dark ? .white : UIColor(white: 0.12, alpha: 1)
        body.textColor = dark ? UIColor(white: 1, alpha: 0.72) : UIColor(white: 0.15, alpha: 0.7)
        (card.advertiserView as? UILabel)?.textColor = body.textColor
        badge.backgroundColor = dark ? UIColor(red: 0.16, green: 0.47, blue: 1, alpha: 1) : UIColor(red: 0, green: 0.48, blue: 1, alpha: 1)
        badge.textColor = .white
        button.backgroundColor = badge.backgroundColor
        button.setTitleColor(.white, for: .normal)
    }
}
