import UIKit
import Shared

/// USE_ADMOB true ise AdMob, false ise AppLovin. İkisi birden başlatılmaz.
final class SudokuAdHost: NSObject, IosAdHost {
    private let admob = AdMobController()
    private let appLovin = AppLovinController()
    private var started = false

    private var useAdMob: Bool { AdConfig.shared.useAdMob() }

    func start(onReady: @escaping () -> Void) {
        guard !started else {
            DispatchQueue.main.async { onReady() }
            return
        }
        started = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in
            guard let self else { return }
            if self.useAdMob {
                self.admob.start(onReady: onReady)
            } else {
                self.appLovin.start(onReady: onReady)
            }
        }
    }

    func attachBanner(container: UIView, onLoaded: @escaping () -> Void, onFailed: @escaping () -> Void) {
        if useAdMob {
            admob.attachBanner(container: container, onLoaded: onLoaded, onFailed: onFailed)
        } else {
            appLovin.attachBanner(container: container, onLoaded: onLoaded, onFailed: onFailed)
        }
    }

    func detachBanner(container: UIView) {
        if useAdMob { admob.detachBanner(container: container) }
        else { appLovin.detachBanner(container: container) }
    }

    func attachNative(container: UIView, dark: Bool, onLoaded: @escaping () -> Void, onFailed: @escaping () -> Void) {
        if useAdMob {
            admob.attachNative(container: container, dark: dark, onLoaded: onLoaded, onFailed: onFailed)
        } else {
            appLovin.attachNative(container: container, dark: dark, onLoaded: onLoaded, onFailed: onFailed)
        }
    }

    func updateNativeTheme(container: UIView, dark: Bool) {
        if useAdMob { admob.updateNativeTheme(container: container, dark: dark) }
        else { appLovin.updateNativeTheme(container: container, dark: dark) }
    }

    func detachNative(container: UIView) {
        if useAdMob { admob.detachNative(container: container) }
        else { appLovin.detachNative(container: container) }
    }

    func showInterstitial() {
        if useAdMob { admob.showInterstitial() }
        else { appLovin.showInterstitial() }
    }

    func showRewarded(onReward: @escaping () -> Void) -> Bool {
        if useAdMob { return admob.showRewarded(onReward: onReward) }
        return appLovin.showRewarded(onReward: onReward)
    }

    func isPrivacyRequired() -> Bool {
        useAdMob && admob.privacyRequired
    }

    func showPrivacyOptions() {
        if useAdMob { admob.showPrivacyOptions() }
    }
}
