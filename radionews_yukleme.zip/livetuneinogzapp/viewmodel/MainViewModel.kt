package com.globalradio.livetuneinogzapp.viewmodel

import android.app.Application
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.globalradio.livetuneinogzapp.R
import com.globalradio.livetuneinogzapp.model.CountrySummary
import com.globalradio.livetuneinogzapp.model.PlayerState
import com.globalradio.livetuneinogzapp.model.RadioStation
import com.globalradio.livetuneinogzapp.repository.StationRepository
import com.globalradio.livetuneinogzapp.utils.CountryFlags
import com.globalradio.livetuneinogzapp.utils.ListenHistoryManager
import com.globalradio.livetuneinogzapp.utils.LocaleCountryMapper
import com.globalradio.livetuneinogzapp.utils.StationListOrganizer
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.yield
import java.net.UnknownHostException
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    application: Application,
    private val repository: StationRepository
) : AndroidViewModel(application) {

    private val historyManager = ListenHistoryManager(application)

    private val _allStations = MutableLiveData<List<RadioStation>>(emptyList())

    // Arama sırasında sadece isim başlangıcı değil, isim/etiket/ülke içindeki
    // her "kelime"nin başlangıcı da eşleşsin diye kelime bazlı önbellek tutulur.
    private data class StationSearchCache(
        val id: String,
        val nameLower: String,
        val nameTokens: List<String>,
        val tagTokens: List<String>,
        val countryTokens: List<String>
    )

    private var searchCache: List<StationSearchCache> = emptyList()

    private val _allSectionStations = MutableLiveData<List<RadioStation>>(emptyList())
    val allSectionStations: LiveData<List<RadioStation>> = _allSectionStations

    // "Türler" (Genres) sekmesi ARTIK "Tümü" sekmesiyle aynı LiveData/kategori
    // durumunu PAYLAŞMIYOR. Önceden ikisi de aynı currentCategory + aynı
    // _allSectionStations akışını kullandığı için, Genres sekmesi bir tür
    // seçtiğinde (ör. "Pop") bu durum "Tümü" sekmesini de kirletiyor ve
    // "Tümü" listesi tüm istasyonlar yerine sadece o türle sınırlı kalıyordu.
    // Bu da cihaz diline göre öncelik sıralamasının tüm listede değil,
    // yanlışlıkla küçük bir alt kümede uygulanmış gibi görünmesine yol açıyordu.
    private var currentGenre: String = ""
    private val _genreSectionStations = MutableLiveData<List<RadioStation>>(emptyList())
    val genreSectionStations: LiveData<List<RadioStation>> = _genreSectionStations

    private val _favoriteStations = MutableLiveData<List<RadioStation>>(emptyList())
    val favoriteStations: LiveData<List<RadioStation>> = _favoriteStations

    private val _mostListenedStations = MutableLiveData<List<RadioStation>>(emptyList())
    val mostListenedStations: LiveData<List<RadioStation>> = _mostListenedStations

    private val _playCounts = MutableLiveData<Map<String, Int>>(emptyMap())
    val playCounts: LiveData<Map<String, Int>> = _playCounts

    private val _countrySummaries = MutableLiveData<List<CountrySummary>>(emptyList())
    val countrySummaries: LiveData<List<CountrySummary>> = _countrySummaries

    private val _filteredStations = MutableLiveData<List<RadioStation>>(emptyList())
    val filteredStations: LiveData<List<RadioStation>> = _filteredStations

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private val _error = MutableLiveData<String?>(null)

    private val _favoritePayload = MutableLiveData<Pair<String, Boolean>?>(null)
    val favoritePayload: LiveData<Pair<String, Boolean>?> = _favoritePayload
    val error: LiveData<String?> = _error

    private val _playerState = MutableLiveData<PlayerState>(PlayerState.Idle)
    val playerState: LiveData<PlayerState> = _playerState

    private var currentQuery = ""
    private var currentCategory = CATEGORY_ALL

    private var dataLoaded = false

    // Cihaz dilinde karşılığı olan ülke(ler); veri setinde bulunmuyorsa
    // İngilizce (fallback) ülkeler kullanılır. "Tümü" sıralamasında ve
    // "Ülkeler" listesinde en üste alınacak ülkeleri belirler.
    private var priorityCountries: List<String> = emptyList()
    private var showedFullList = false
    private var offlineNoticeJob: Job? = null

    init {
        loadStations()
    }

    fun loadStations() {
        if (_isLoading.value == true) return
        viewModelScope.launch {
            _isLoading.postValue(true)
            offlineNoticeJob?.cancel()
            var fetched = false
            val started = SystemClock.elapsedRealtime()
            val cached = repository.getCachedStations()

            if (!cached.isNullOrEmpty()) {
                publishHomeThenRest(cached)
                _isLoading.postValue(false)
            }
            if (isCurrentlyOffline()) {
                scheduleOfflineNotice(started, !cached.isNullOrEmpty()) { fetched }
            }

            repository.getStations()
                .onSuccess { stations ->
                    fetched = true
                    offlineNoticeJob?.cancel()
                    _error.postValue(null)
                    publishHomeThenRest(stations)
                }
                .onFailure { error ->
                    if (isOfflineFailure(error)) {
                        scheduleOfflineNotice(started, !cached.isNullOrEmpty()) { fetched }
                    } else {
                        offlineNoticeJob?.cancel()
                    }
                }
            _isLoading.postValue(false)
        }
    }

    /**
     * Tümü önce cihaz dilindeki ülkenin istasyonlarını gösterir.
     * Kalan ülkeler bir sonraki karede, eldeki hızda eklenir.
     */
    private suspend fun publishHomeThenRest(stations: List<RadioStation>) {
        ensurePriority(stations)
        val home = homeCountryStations(stations)
        if (!showedFullList && home.isNotEmpty() && home.size < stations.size) {
            applyLoadedStations(home)
            yield()
        }
        applyLoadedStations(stations)
        showedFullList = true
    }

    private fun ensurePriority(stations: List<RadioStation>) {
        priorityCountries = StationListOrganizer.resolveEffectiveCountries(
            stations = stations,
            deviceCountries = LocaleCountryMapper.getDeviceCountries(),
            fallbackCountries = LocaleCountryMapper.getFallbackCountries()
        )
    }

    private fun homeCountryStations(stations: List<RadioStation>): List<RadioStation> {
        val device = LocaleCountryMapper.getDeviceCountries()
        val target = device.firstOrNull { name ->
            val key = CountryFlags.groupKey(name)
            stations.any {
                it.country.equals(name, ignoreCase = true) ||
                    CountryFlags.groupKey(it.country, it.countryCode) == key
            }
        } ?: priorityCountries.firstOrNull() ?: return emptyList()
        val key = CountryFlags.groupKey(target)
        return stations.filter {
            it.country.equals(target, ignoreCase = true) ||
                CountryFlags.groupKey(it.country, it.countryCode) == key
        }
    }

    private fun isCurrentlyOffline(): Boolean {
        val cm = getApplication<Application>().getSystemService(ConnectivityManager::class.java)
            ?: return true
        val network = cm.activeNetwork ?: return true
        val caps = cm.getNetworkCapabilities(network) ?: return true
        return !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun isOfflineFailure(error: Throwable): Boolean {
        if (isCurrentlyOffline()) return true
        if (error is UnknownHostException) return true
        val msg = error.message ?: return false
        return msg.contains("Unable to resolve host", ignoreCase = true) ||
            msg.contains("No address", ignoreCase = true) ||
            msg.contains("UnknownHost", ignoreCase = true)
    }

    private fun scheduleOfflineNotice(
        startedAt: Long,
        hasCache: Boolean,
        alreadyFetched: () -> Boolean
    ) {
        if (offlineNoticeJob?.isActive == true) return
        offlineNoticeJob = viewModelScope.launch {
            val wait = OFFLINE_NOTICE_DELAY_MS - (SystemClock.elapsedRealtime() - startedAt)
            if (wait > 0) delay(wait)
            if (alreadyFetched()) return@launch
            if (!isCurrentlyOffline()) return@launch
            val ctx = getApplication<Application>()
            _error.postValue(
                ctx.getString(
                    if (hasCache) R.string.error_offline_cache else R.string.error_no_internet
                )
            )
        }
    }

    private fun applyLoadedStations(stations: List<RadioStation>) {
        dataLoaded = true
        _allStations.postValue(stations)
        searchCache = stations.map { s ->
            StationSearchCache(
                id = s.id,
                nameLower = s.name.lowercase(),
                nameTokens = tokenize(s.name),
                tagTokens = tokenize(s.tags),
                countryTokens = tokenize(s.country)
            )
        }
        buildCountries(stations)
        updateAllSection(stations)
        updateGenreSection(stations)
        updateFavorites(stations)
        refreshMostListened()
    }

    /**
     * Bir metni harf/rakam olmayan karakterlerden (boşluk, virgül, parantez vb.)
     * ayırarak küçük harfli "kelime" parçalarına böler. Arama kutusunda
     * büyük/küçük harf farkı gözetmeksizin ve "başlangıç eşleşmesi" (prefix)
     * mantığıyla anında sonuç üretmek için kullanılır.
     */
    private fun tokenize(text: String): List<String> =
        text.lowercase().split(TOKEN_SPLIT_REGEX).filter { it.isNotEmpty() }

    fun reloadIfEmpty() {
        if (!dataLoaded || _allStations.value.isNullOrEmpty()) {
            loadStations()
        }
    }

    private fun updateAllSection(stations: List<RadioStation>) {
        // NOT: "Tümü" sekmesi artık türe göre filtrelenmiyor (bkz. filterGenre /
        // updateGenreSection) — bu sayede her zaman TÜM istasyonları temsil eder
        // ve cihaz diline göre öncelik sıralaması bütün listeye uygulanır.
        var result: List<RadioStation> =
            if (currentCategory == CATEGORY_FAVORITES) stations.filter { it.isFavorite }
            else stations

        if (currentQuery.isNotEmpty()) {
            val qLower = currentQuery.lowercase()
            val queryTokens = tokenize(currentQuery)
            val matchIds = if (searchCache.isNotEmpty()) {
                searchCache.filter { cache -> tokensMatch(queryTokens, cache.nameTokens, cache.tagTokens, cache.countryTokens) }
                    .sortedWith(
                        compareBy(
                            { !it.nameLower.startsWith(qLower) },
                            { it.nameLower }
                        )).map { it.id }.toHashSet()
            } else {
                result.filter { st ->
                    tokensMatch(queryTokens, tokenize(st.name), tokenize(st.tags), tokenize(st.country))
                }.map { it.id }.toHashSet()
            }
            result = result.filter { it.id in matchIds }
                .sortedWith(
                    compareBy(
                        { !it.name.lowercase().startsWith(qLower) },
                        { it.name.lowercase() }
                    ))
        } else {
            result = StationListOrganizer.sortByPriorityCountry(result, priorityCountries)
        }

        try {
            _allSectionStations.value = result
            _filteredStations.value = result
        } catch (_: Exception) {
            _allSectionStations.postValue(result)
            _filteredStations.postValue(result)
        }
    }

    /**
     * Yazılan her kelime (queryTokens) için, isim/etiket/ülke kelimelerinden
     * (nameTokens/tagTokens/countryTokens) EN AZ BİRİNİN o kelimeyle
     * BAŞLAMASI gerekir. Böylece "a" → a ile başlayanlar, "al" → al ile
     * başlayanlar, "alt" → alt ile başlayanlar şeklinde anında ve büyük/küçük
     * harf duyarsız bir "başlangıç eşleşmesi" arama davranışı elde edilir.
     */
    private fun tokensMatch(
        queryTokens: List<String>,
        nameTokens: List<String>,
        tagTokens: List<String>,
        countryTokens: List<String>
    ): Boolean {
        if (queryTokens.isEmpty()) return false
        return queryTokens.all { qt ->
            nameTokens.any { it.startsWith(qt) } ||
                    tagTokens.any { it.startsWith(qt) } ||
                    countryTokens.any { it.startsWith(qt) }
        }
    }

    private fun updateFavorites(stations: List<RadioStation>) {
        val favs = stations.filter { it.isFavorite }
        try {
            _favoriteStations.value = favs
        } catch (_: Exception) {
            _favoriteStations.postValue(favs)
        }
    }

    fun filterByCategory(category: String) {
        currentCategory = category
        currentQuery = ""
        val stations = _allStations.value ?: return
        updateAllSection(stations)
    }

    /**
     * "Türler" (Genres) sekmesine özel filtre. "Tümü" sekmesinin durumuna
     * (currentCategory/currentQuery) ve LiveData'sına (_allSectionStations)
     * DOKUNMAZ — iki sekme artık tamamen bağımsızdır.
     */
    fun filterGenre(genre: String) {
        currentGenre = genre
        val stations = _allStations.value ?: return
        updateGenreSection(stations)
    }

    private fun updateGenreSection(stations: List<RadioStation>) {
        if (currentGenre.isEmpty()) return
        var result = stations.filter { st ->
            st.getTagList().any { tag -> tag.equals(currentGenre, ignoreCase = true) }
        }
        result = StationListOrganizer.sortByPriorityCountry(result, priorityCountries)
        try {
            _genreSectionStations.value = result
        } catch (_: Exception) {
            _genreSectionStations.postValue(result)
        }
    }

    fun search(query: String) {
        currentQuery = query.trim()
        currentCategory = CATEGORY_ALL
        val stations = _allStations.value
        if (stations.isNullOrEmpty()) {
            if (!dataLoaded) loadStations()
            return
        }
        updateAllSection(stations)
    }

    fun refreshMostListened() {
        val all = _allStations.value ?: return
        val counts = historyManager.getAllCounts()
        _playCounts.postValue(counts)
        val top = counts.entries
            .sortedByDescending { it.value }
            .take(50)
            .mapNotNull { (id, _) -> all.find { it.id == id } }
        _mostListenedStations.postValue(top)
    }

    fun recordPlay(station: RadioStation) {
        historyManager.increment(station.id)
        refreshMostListened()
    }

    fun toggleFavorite(station: RadioStation): Boolean {
        val isNowFav = repository.toggleFavorite(station)
        station.isFavorite = isNowFav
        val updated = _allStations.value?.map { s ->
            if (s.id == station.id) {
                s.isFavorite = isNowFav
                s.copy(isFavorite = isNowFav)
            } else s
        } ?: emptyList()
        try {
            _allStations.value = updated
        } catch (_: Exception) {
            _allStations.postValue(updated)
        }
        val payload = Pair(station.id, isNowFav)
        try {
            _favoritePayload.value = payload
        } catch (_: Exception) {
            _favoritePayload.postValue(payload)
        }
        updateFavorites(updated)
        viewModelScope.launch {
            updateAllSection(updated)
            updateGenreSection(updated)
        }
        return isNowFav
    }

    fun isFavorite(stationId: String): Boolean {
        _allStations.value?.find { it.id == stationId }?.let { mem ->
            if (mem.isFavorite) return true
        }
        return repository.isFavorite(stationId)
    }

    private fun buildCountries(stations: List<RadioStation>) {
        val userCountries = LocaleCountryMapper.getDeviceCountries()
        val effectiveCountries = StationListOrganizer.resolveEffectiveCountries(
            stations = stations,
            deviceCountries = userCountries,
            fallbackCountries = LocaleCountryMapper.getFallbackCountries()
        )
        priorityCountries = effectiveCountries

        val summaries = StationListOrganizer.buildCountrySummaries(stations, effectiveCountries)
        _countrySummaries.postValue(summaries)
    }

    fun updatePlayerState(state: PlayerState) {
        _playerState.postValue(state)
    }

    fun playlistFor(station: RadioStation): List<RadioStation> {
        fun has(list: List<RadioStation>?) = list?.any { it.id == station.id } == true
        val active = _allSectionStations.value
        if (has(active)) return active!!
        val genre = _genreSectionStations.value
        if (has(genre)) return genre!!
        val fav = _favoriteStations.value
        if (has(fav)) return fav!!
        val top = _mostListenedStations.value
        if (has(top)) return top!!
        val all = _allStations.value
        return when {
            has(all) -> all!!
            !all.isNullOrEmpty() -> listOf(station) + all
            else -> listOf(station)
        }
    }

    fun getNextStation(current: RadioStation): RadioStation? {
        val list = playlistFor(current)
        if (list.isEmpty()) return null
        val idx = list.indexOfFirst { it.id == current.id }
        return if (idx >= 0 && idx < list.size - 1) list[idx + 1] else list.firstOrNull()
    }

    fun getPreviousStation(current: RadioStation): RadioStation? {
        val list = playlistFor(current)
        if (list.isEmpty()) return null
        val idx = list.indexOfFirst { it.id == current.id }
        return if (idx > 0) list[idx - 1] else list.lastOrNull()
    }

    fun getCurrentStationIndex(station: RadioStation): Int =
        playlistFor(station).indexOfFirst { it.id == station.id }

    fun getTotalCount(): Int = getActiveSectionList().size

    fun allStationsList(): List<RadioStation> = _allStations.value ?: emptyList()

    fun getActiveSectionList(): List<RadioStation> =
        _allSectionStations.value ?: emptyList()

    companion object {
        const val CATEGORY_ALL = "__ALL__"
        const val CATEGORY_FAVORITES = "__FAVORITES__"

        // Harf/rakam olmayan her şeyden böler (boşluk, virgül, parantez, tire vb.)
        // \p{L} ve \p{N} Unicode uyumludur; Türkçe (ı, ş, ğ, ö, ü, ç) ve diğer
        // dillerin harfleriyle de doğru çalışır.
        private val TOKEN_SPLIT_REGEX = Regex("[^\\p{L}\\p{N}]+")
        private const val OFFLINE_NOTICE_DELAY_MS = 5_000L
    }
}