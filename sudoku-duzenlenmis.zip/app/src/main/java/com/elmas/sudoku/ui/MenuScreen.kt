package com.elmas.sudoku.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.elmas.sudoku.ads.NativeAdCard
import com.elmas.sudoku.logic.Difficulty
import com.elmas.sudoku.logic.SavedGame
import com.elmas.sudoku.theme.Black
import com.elmas.sudoku.theme.ErrorRed
import com.elmas.sudoku.theme.GoldStar
import com.elmas.sudoku.theme.LevelTextColor
import com.elmas.sudoku.theme.SudokuPalette
import com.elmas.sudoku.theme.WinGreen
import com.elmas.sudoku.theme.levelColor
import com.elmas.sudoku.theme.levelPastel
import kotlin.math.abs
import kotlin.math.min

@Composable
fun MenuScreen(
    palette: SudokuPalette,
    bestTime: (Difficulty) -> Int,
    saved: SavedGame?,
    muted: Boolean,
    generating: Difficulty?,
    privacyRequired: Boolean,
    onResume: () -> Unit,
    onNewGame: (Difficulty) -> Unit,
    onToggleDark: () -> Unit,
    onToggleMute: () -> Unit,
    onPrivacy: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(10.dp))
        MenuHeader(palette, muted, privacyRequired, onToggleDark, onToggleMute, onPrivacy)

        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            val viewport = maxHeight
            Column(
                Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .heightIn(min = viewport)
                    .padding(top = 18.dp, bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (saved != null) {
                        ResumeOrb(saved, palette, onResume)
                    } else {
                        SudokuEmblem(palette)
                    }
                    Spacer(Modifier.height(22.dp))
                    Text(
                        Lang.get("new_game"),
                        color = palette.text,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Spacer(Modifier.height(12.dp))
                    DifficultyGrid(palette, bestTime, generating, onNewGame)
                }
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 20.dp)
                ) {
                    NativeAdCard(palette)
                }
            }
        }
    }
}

@Composable
private fun MenuHeader(
    palette: SudokuPalette,
    muted: Boolean,
    privacyRequired: Boolean,
    onToggleDark: () -> Unit,
    onToggleMute: () -> Unit,
    onPrivacy: () -> Unit
) {
    val breath = rememberBreath()
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .height(64.dp)
            .panel(palette, shape, elevation = if (palette.dark) 14.dp else 6.dp)
            .neonBorder(
                breath,
                if (palette.dark) palette.glow else palette.text.copy(alpha = 0.18f),
                1.5.dp,
                18.dp
            )
            .padding(start = 18.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                "SUDOKU",
                style = TextStyle(
                    brush = Brush.linearGradient(listOf(palette.accent, palette.glow))
                ),
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 3.sp
            )
            Text(
                "Brain Pulse",
                color = palette.textDim,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 1.sp
            )
        }
        if (privacyRequired) {
            IconButton(onClick = onPrivacy) {
                Icon(Icons.Filled.PrivacyTip, Lang.get("privacy"), tint = palette.text)
            }
        }
        IconButton(onClick = onToggleDark) {
            Icon(
                if (palette.dark) Icons.Filled.WbSunny else Icons.Filled.NightsStay,
                null,
                tint = palette.text
            )
        }
        IconButton(onClick = onToggleMute) {
            Icon(
                if (muted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                null,
                tint = if (muted) ErrorRed else WinGreen
            )
        }
    }
}

@Composable
private fun ResumeOrb(saved: SavedGame, palette: SudokuPalette, onClick: () -> Unit) {
    val level = levelColor(saved.difficulty, palette.dark)
    val progress = saved.progressPercent / 100f
    val pulse = rememberInfiniteTransition(label = "orb").animateFloat(
        initialValue = 1f,
        targetValue = 1.035f,
        animationSpec = infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "orbScale"
    )
    val label = saved.difficulty?.let { Lang.get(it.labelKey) } ?: "SUDOKU"

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(172.dp)
                .graphicsLayer {
                    scaleX = pulse.value
                    scaleY = pulse.value
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val stroke = 7.dp.toPx()
                val inset = stroke / 2f + 2.dp.toPx()
                val arcSize = Size(size.width - inset * 2f, size.height - inset * 2f)
                drawArc(
                    color = palette.outline,
                    startAngle = 0f,
                    sweepAngle = 360f,
                    useCenter = false,
                    topLeft = Offset(inset, inset),
                    size = arcSize,
                    style = Stroke(stroke)
                )
                if (progress > 0f) {
                    drawArc(
                        color = level,
                        startAngle = -90f,
                        sweepAngle = 360f * progress,
                        useCenter = false,
                        topLeft = Offset(inset, inset),
                        size = arcSize,
                        style = Stroke(stroke, cap = StrokeCap.Round)
                    )
                }
            }
            Box(
                Modifier
                    .size(140.dp)
                    .shadow(elevation = 12.dp, shape = CircleShape, clip = false)
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Color(0xFFFFE066), GoldStar)))
                    .border(
                        width = 2.dp,
                        color = if (palette.dark) Color.White.copy(alpha = 0.4f) else Color.Black.copy(alpha = 0.2f),
                        shape = CircleShape
                    )
                    .clickable(onClick = onClick),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.PlayArrow, null, tint = Black, modifier = Modifier.size(30.dp))
                    Text(Lang.get("resume"), color = Black, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "$label · ${Lang.percent(saved.progressPercent)}",
                        color = Black.copy(alpha = 0.65f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Timer, null, tint = palette.textDim, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(4.dp))
            Text(formatTime(saved.elapsedSeconds), color = palette.textDim, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
    }
}

/** Kayıtlı oyun yokken gösterilen, rakamları sırayla parlayan küçük tahta. */
@Composable
private fun SudokuEmblem(palette: SudokuPalette) {
    val phase = rememberInfiniteTransition(label = "emblem").animateFloat(
        initialValue = 0f,
        targetValue = 9f,
        animationSpec = infiniteRepeatable(tween(6300, easing = LinearEasing)),
        label = "emblemPhase"
    )
    val digits = remember { listOf(5, 3, 9, 1, 7, 4, 8, 2, 6) }
    val colors = remember(palette.dark) {
        Difficulty.entries.map { levelColor(it, palette.dark) }
    }
    val shape = RoundedCornerShape(26.dp)

    Box(
        Modifier
            .size(156.dp)
            .panel(palette, shape, elevation = if (palette.dark) 14.dp else 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            for (r in 0 until 3) {
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    for (c in 0 until 3) {
                        val index = r * 3 + c
                        val tint = colors[index % colors.size]
                        Box(
                            Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(11.dp))
                                .drawBehind {
                                    val d = abs(phase.value - index)
                                    val distance = min(d, 9f - d)
                                    val glow = (1f - distance).coerceIn(0f, 1f)
                                    drawRect(palette.accentSoft)
                                    drawRect(tint.copy(alpha = 0.65f * glow))
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                digits[index].toString(),
                                color = palette.text,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DifficultyGrid(
    palette: SudokuPalette,
    bestTime: (Difficulty) -> Int,
    generating: Difficulty?,
    onNewGame: (Difficulty) -> Unit
) {
    val rows = listOf(
        listOf(Difficulty.EASY, Difficulty.MEDIUM),
        listOf(Difficulty.HARD, Difficulty.ULTRA)
    )
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        for (row in rows) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                for (level in row) {
                    DifficultyCard(
                        level = level,
                        palette = palette,
                        best = bestTime(level),
                        loading = generating == level,
                        enabled = generating == null,
                        modifier = Modifier.weight(1f),
                        onClick = { onNewGame(level) }
                    )
                }
            }
        }
    }
}

@Composable
private fun DifficultyCard(
    level: Difficulty,
    palette: SudokuPalette,
    best: Int,
    loading: Boolean,
    enabled: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    val accent = levelColor(level, palette.dark)
    val textColor = if (palette.dark) accent else LevelTextColor
    val surface = if (palette.dark) {
        Modifier
            .shadow(8.dp, shape, clip = false)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.16f), Color.White.copy(alpha = 0.05f))))
            .border(
                1.dp,
                Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.42f), accent.copy(alpha = 0.45f))),
                shape
            )
    } else {
        Modifier
            .shadow(6.dp, shape, clip = false)
            .clip(shape)
            .background(levelPastel(level))
    }

    Box(
        modifier
            .height(80.dp)
            .then(surface)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                Lang.get(level.labelKey),
                color = textColor,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                repeat(4) { i ->
                    val on = i < level.level
                    Box(
                        Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(
                                if (palette.dark) {
                                    if (on) accent else Color.White.copy(alpha = 0.18f)
                                } else {
                                    LevelTextColor.copy(alpha = if (on) 0.8f else 0.2f)
                                }
                            )
                    )
                }
            }
            if (best > 0) {
                Spacer(Modifier.height(5.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Filled.EmojiEvents,
                        null,
                        tint = textColor.copy(alpha = 0.85f),
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(Modifier.width(3.dp))
                    Text(
                        formatTime(best),
                        color = textColor.copy(alpha = 0.85f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .size(16.dp),
                color = textColor,
                strokeWidth = 2.dp
            )
        }
    }
}
