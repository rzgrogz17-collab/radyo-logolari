package com.elmas.sudoku.ui

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.elmas.sudoku.logic.CellKind
import com.elmas.sudoku.logic.Difficulty
import com.elmas.sudoku.logic.GameStorage
import com.elmas.sudoku.logic.Puzzle
import com.elmas.sudoku.logic.SavedGame
import com.elmas.sudoku.logic.SudokuRules

enum class MoveResult { IGNORED, LOCKED, NO_SELECTION, NOTE, PLACED, CONFLICT, SOLVED }

enum class ActionResult { DONE, SOLVED, EMPTY, NO_SELECTION, ALREADY_CORRECT, NEED_AD }

class WinInfo(val difficulty: Difficulty?, val seconds: Int, val newRecord: Boolean, val bestSeconds: Int)

@Stable
class GameController(private val storage: GameStorage) {

    val cells = mutableStateListOf<Int>().apply { repeat(81) { add(0) } }
    val notes = mutableStateListOf<Int>().apply { repeat(81) { add(0) } }
    val kinds = mutableStateListOf<Int>().apply { repeat(81) { add(CellKind.FREE) } }

    private var solution = IntArray(81)
    private val undoStack = ArrayDeque<Move>()

    var difficulty by mutableStateOf<Difficulty?>(null)
        private set
    var selected by mutableIntStateOf(-1)
        private set
    var pencilMode by mutableStateOf(false)
    var elapsedSeconds by mutableIntStateOf(0)
    var hints by mutableIntStateOf(storage.getHints())
        private set
    var undos by mutableIntStateOf(storage.getUndos())
        private set
    var solved by mutableStateOf(false)
        private set
    var active by mutableStateOf(false)
        private set
    var lastWin by mutableStateOf<WinInfo?>(null)
        private set

    private class Move(
        val index: Int,
        val value: Int,
        val notes: Int,
        val peers: IntArray,
        val peerNotes: IntArray
    )

    fun startNew(puzzle: Puzzle, level: Difficulty) {
        load(
            puzzle.cells,
            puzzle.solution,
            IntArray(81) { if (puzzle.cells[it] != 0) CellKind.GIVEN else CellKind.FREE },
            IntArray(81),
            level,
            0
        )
        save()
    }

    fun resume(saved: SavedGame) {
        load(saved.cells, saved.solution, saved.kinds, saved.notes, saved.difficulty, saved.elapsedSeconds)
    }

    private fun load(c: IntArray, s: IntArray, k: IntArray, n: IntArray, level: Difficulty?, elapsed: Int) {
        for (i in 0 until 81) {
            cells[i] = c[i]
            notes[i] = if (c[i] == 0) n[i] else 0
            kinds[i] = k[i]
        }
        solution = s.copyOf()
        difficulty = level
        elapsedSeconds = elapsed
        selected = -1
        pencilMode = false
        undoStack.clear()
        solved = false
        lastWin = null
        active = true
    }

    fun close() {
        if (!solved) save()
        active = false
    }

    fun select(index: Int) {
        selected = if (index in 0..80) index else -1
    }

    fun input(digit: Int): MoveResult {
        val i = selected
        if (i !in 0..80) return MoveResult.NO_SELECTION
        if (solved || digit !in 1..9) return MoveResult.IGNORED
        if (kinds[i] != CellKind.FREE) return MoveResult.LOCKED

        val bit = 1 shl digit
        if (pencilMode) {
            if (cells[i] != 0) return MoveResult.IGNORED
            push(i, IntArray(0))
            notes[i] = notes[i] xor bit
            save()
            return MoveResult.NOTE
        }
        if (cells[i] == digit) return MoveResult.IGNORED

        val peers = SudokuRules.PEERS[i].filter { notes[it] and bit != 0 }.toIntArray()
        push(i, peers)
        cells[i] = digit
        notes[i] = 0
        for (p in peers) notes[p] = notes[p] and bit.inv()
        return afterPlacement(i)
    }

    fun erase(): MoveResult {
        val i = selected
        if (i !in 0..80) return MoveResult.NO_SELECTION
        if (solved) return MoveResult.IGNORED
        if (kinds[i] != CellKind.FREE) return MoveResult.LOCKED
        if (cells[i] == 0 && notes[i] == 0) return MoveResult.IGNORED
        push(i, IntArray(0))
        cells[i] = 0
        notes[i] = 0
        save()
        return MoveResult.PLACED
    }

    fun canUndo() = undoStack.isNotEmpty() && !solved

    fun undo(): ActionResult {
        if (!canUndo()) return ActionResult.EMPTY
        if (undos <= 0) return ActionResult.NEED_AD
        val move = undoStack.removeLast()
        cells[move.index] = move.value
        notes[move.index] = move.notes
        for (k in move.peers.indices) notes[move.peers[k]] = move.peerNotes[k]
        selected = move.index
        undos--
        storage.saveRights(hints, undos)
        save()
        return ActionResult.DONE
    }

    fun hint(): ActionResult {
        val i = selected
        if (i !in 0..80) return ActionResult.NO_SELECTION
        if (solved) return ActionResult.EMPTY
        val correct = solution[i]
        if (cells[i] == correct) return ActionResult.ALREADY_CORRECT
        if (hints <= 0) return ActionResult.NEED_AD

        val bit = 1 shl correct
        val peers = SudokuRules.PEERS[i].filter { notes[it] and bit != 0 }
        cells[i] = correct
        notes[i] = 0
        for (p in peers) notes[p] = notes[p] and bit.inv()
        kinds[i] = CellKind.HINTED
        undoStack.removeAll { it.index == i }
        hints--
        storage.saveRights(hints, undos)
        return if (afterPlacement(i) == MoveResult.SOLVED) ActionResult.SOLVED else ActionResult.DONE
    }

    fun addHints(amount: Int) {
        hints += amount
        storage.saveRights(hints, undos)
    }

    fun addUndos(amount: Int) {
        undos += amount
        storage.saveRights(hints, undos)
    }

    /** Oyuncunun doldurması gereken hücrelerde ilerleme, 0..1 */
    fun progress(): Float {
        var total = 0
        var filled = 0
        for (i in 0 until 81) {
            if (kinds[i] == CellKind.GIVEN) continue
            total++
            if (cells[i] != 0) filled++
        }
        return if (total == 0) 1f else filled.toFloat() / total
    }

    /** Her rakamdan tahtaya daha kaç tane konabilir. İndeks 1..9 kullanılır. */
    fun remaining(): IntArray {
        val left = IntArray(10) { 9 }
        for (i in 0 until 81) {
            val v = cells[i]
            if (v in 1..9) left[v]--
        }
        return left
    }

    fun save() {
        if (!active || solved) return
        storage.saveGame(
            SavedGame(
                cells = IntArray(81) { cells[it] },
                solution = solution.copyOf(),
                kinds = IntArray(81) { kinds[it] },
                notes = IntArray(81) { notes[it] },
                difficulty = difficulty,
                elapsedSeconds = elapsedSeconds
            )
        )
    }

    private fun push(index: Int, peers: IntArray) {
        undoStack.addLast(Move(index, cells[index], notes[index], peers, IntArray(peers.size) { notes[peers[it]] }))
        if (undoStack.size > 50) undoStack.removeFirst()
    }

    private fun afterPlacement(index: Int): MoveResult {
        if (SudokuRules.isSolved(cells)) {
            finish()
            return MoveResult.SOLVED
        }
        save()
        val value = cells[index]
        val conflict = SudokuRules.PEERS[index].any { cells[it] == value }
        return if (conflict) MoveResult.CONFLICT else MoveResult.PLACED
    }

    private fun finish() {
        solved = true
        selected = -1
        storage.clearSave()
        val level = difficulty
        val record = level != null && storage.recordWin(level, elapsedSeconds)
        lastWin = WinInfo(level, elapsedSeconds, record, if (level != null) storage.bestTime(level) else 0)
    }
}
