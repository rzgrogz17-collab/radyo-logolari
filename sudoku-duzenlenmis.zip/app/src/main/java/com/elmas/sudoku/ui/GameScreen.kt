package com.elmas.sudoku.ui

import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.elmas.sudoku.ads.AdManager
import com.elmas.sudoku.logic.Difficulty
import com.elmas.sudoku.logic.GameStorage
import com.elmas.sudoku.logic.SoundManager
import com.elmas.sudoku.logic.SudokuGenerator
import com.elmas.sudoku.theme.DarkPalette
import com.elmas.sudoku.theme.LightPalette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class Screen { SPLASH, MENU, GAME }

@Composable
fun GameScreen() {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val scope = rememberCoroutineScope()
    val storage = remember { GameStorage(context) }
    val sound = remember { SoundManager().apply { isMuted = storage.isMuted() } }
    val controller = remember { GameController(storage) }
    DisposableEffect(Unit) {
        onDispose {
            controller.close()
            sound.release()
        }
    }

    var dark by remember { mutableStateOf(storage.isDarkMode()) }
    var muted by remember { mutableStateOf(sound.isMuted) }
    var screen by remember { mutableStateOf(Screen.SPLASH) }
    var saved by remember { mutableStateOf(storage.loadGame()) }
    var generating by remember { mutableStateOf<Difficulty?>(null) }
    var showWin by remember { mutableStateOf(false) }
    val privacyRequired by AdManager.privacyOptionsRequired
    val palette = if (dark) DarkPalette else LightPalette

    LaunchedEffect(Unit) {
        delay(2_200L)
        screen = Screen.MENU
    }

    val darkBars = dark || screen == Screen.SPLASH
    LaunchedEffect(darkBars) {
        (activity as? ComponentActivity)?.let { applySystemBars(it, darkBars) }
    }

    fun goMenu() {
        controller.save()
        saved = storage.loadGame()
        showWin = false
        screen = Screen.MENU
    }

    fun resume() {
        if (controller.active && !controller.solved) {
            screen = Screen.GAME
            return
        }
        val game = storage.loadGame()
        if (game == null) {
            saved = null
            return
        }
        controller.resume(game)
        sound.playSuccess()
        screen = Screen.GAME
    }

    fun startNew(level: Difficulty) {
        if (generating != null) return
        generating = level
        scope.launch {
            val puzzle = withContext(Dispatchers.Default) { SudokuGenerator.generate(level) }
            controller.startNew(puzzle, level)
            generating = null
            showWin = false
            sound.playClick()
            screen = Screen.GAME
        }
    }

    /** Kazandın penceresi kapanınca geçiş reklamı açılır, oyun arkada sürer. */
    fun afterWin(next: Difficulty?) {
        showWin = false
        activity?.let { AdManager.showInterstitial(it) }
        if (next != null) {
            controller.close()
            saved = null
            startNew(next)
        } else {
            goMenu()
        }
    }

    BackHandler(enabled = screen == Screen.GAME && !showWin) { goMenu() }

    Box(
        Modifier
            .fillMaxSize()
            .background(palette.background)
    ) {
        if (darkBars) {
            StarFieldBackground(Modifier.fillMaxSize())
        } else {
            MorningSkyBackground(Modifier.fillMaxSize())
        }

        Crossfade(targetState = screen, animationSpec = tween(350), label = "screen") { target ->
            when (target) {
                Screen.SPLASH -> SplashContent()
                Screen.MENU -> MenuScreen(
                    palette = palette,
                    bestTime = { storage.bestTime(it) },
                    saved = saved,
                    muted = muted,
                    generating = generating,
                    privacyRequired = privacyRequired,
                    onResume = { resume() },
                    onNewGame = { startNew(it) },
                    onToggleDark = {
                        dark = !dark
                        storage.setDarkMode(dark)
                    },
                    onToggleMute = {
                        muted = sound.toggleSound()
                        storage.setMuted(muted)
                    },
                    onPrivacy = { activity?.let { AdManager.showPrivacyOptions(it) } }
                )
                Screen.GAME -> PlayScreen(
                    controller = controller,
                    palette = palette,
                    muted = muted,
                    sound = sound,
                    onToggleDark = {
                        dark = !dark
                        storage.setDarkMode(dark)
                    },
                    onToggleMute = {
                        muted = sound.toggleSound()
                        storage.setMuted(muted)
                    },
                    onHome = { goMenu() },
                    onSolved = { showWin = true }
                )
            }
        }

        val win = controller.lastWin
        if (showWin && win != null) {
            val next = win.difficulty
            WinDialog(
                info = win,
                palette = palette,
                onNewGame = if (next != null) ({ afterWin(next) }) else null,
                onMenu = { afterWin(null) }
            )
        }
    }
}

private fun applySystemBars(activity: ComponentActivity, dark: Boolean) {
    val transparent = android.graphics.Color.TRANSPARENT
    if (dark) {
        activity.enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(transparent),
            navigationBarStyle = SystemBarStyle.dark(transparent)
        )
    } else {
        activity.enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(transparent, transparent),
            navigationBarStyle = SystemBarStyle.light(transparent, 0x801B1B1B.toInt())
        )
    }
}

@Composable
private fun SplashContent() {
    val neon = Color(0xFF2979FF)
    val sweep by rememberInfiniteTransition(label = "loading").animateFloat(
        initialValue = -0.4f,
        targetValue = 1.4f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweep"
    )
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "SUDOKU",
            style = TextStyle(brush = Brush.linearGradient(listOf(neon, Color(0xFFB388FF)))),
            fontSize = 44.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 6.sp
        )
        Spacer(Modifier.height(8.dp))
        Text("Brain Pulse", color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(28.dp))
        Box(
            Modifier
                .width(220.dp)
                .height(6.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.08f))
                .border(0.5.dp, Color.White.copy(alpha = 0.15f), CircleShape)
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val center = sweep * size.width
                val glow = size.width * 0.4f
                drawRect(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.Transparent,
                            neon.copy(alpha = 0.4f),
                            neon,
                            Color(0xFFB388FF),
                            neon,
                            neon.copy(alpha = 0.4f),
                            Color.Transparent
                        ),
                        startX = center - glow / 2f,
                        endX = center + glow / 2f
                    )
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(Lang.get("loading"), color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp, letterSpacing = 1.sp)
    }
}
