package com.elmas.sudoku.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import com.elmas.sudoku.logic.Difficulty

val GoldStar = Color(0xFFFFD700)
val ErrorRed = Color(0xFFFF1744)
val WinGreen = Color(0xFF00C853)
val White = Color(0xFFFFFFFF)
val Black = Color(0xFF000000)

// --- ZORLUK SEVİYESİ RENKLERİ (PASTEL) ---
val LevelEasyColor = Color(0xFF81C995)
val LevelMediumColor = Color(0xFFFDD663)
val LevelHardColor = Color(0xFF8AB4F8)
val LevelUltraColor = Color(0xFFF28B82)

// Pastel buton üstündeki yazı
val LevelTextColor = Color(0xFF202124)

@Immutable
data class SudokuPalette(
    val dark: Boolean,
    val background: Color,
    val surface: Color,
    val surfaceStrong: Color,
    val outline: Color,
    val text: Color,
    val textDim: Color,
    val accent: Color,
    val accentSoft: Color,
    val glow: Color,
    val boardBg: Color,
    val gridThin: Color,
    val selection: Color,
    val peer: Color,
    val sameNumber: Color,
    val conflictBg: Color,
    val userDigit: Color,
    val hintDigit: Color,
    val note: Color,
    val key: Color
)

val DarkPalette = SudokuPalette(
    dark = true,
    background = Color(0xFF05070F),
    surface = Color(0xFF141A2E).copy(alpha = 0.80f),
    surfaceStrong = Color(0xFF161C33),
    outline = Color.White.copy(alpha = 0.12f),
    text = Color(0xFFEEF1FF),
    textDim = Color(0xFFEEF1FF).copy(alpha = 0.62f),
    accent = Color(0xFF2979FF),
    accentSoft = Color(0xFF2979FF).copy(alpha = 0.18f),
    glow = Color(0xFFB388FF),
    boardBg = Color(0xFF070B18),
    gridThin = Color.White.copy(alpha = 0.13f),
    selection = Color(0xFF2979FF).copy(alpha = 0.48f),
    peer = Color(0xFF2979FF).copy(alpha = 0.11f),
    sameNumber = Color(0xFFB388FF).copy(alpha = 0.30f),
    conflictBg = ErrorRed.copy(alpha = 0.24f),
    userDigit = Color(0xFF82B1FF),
    hintDigit = GoldStar,
    note = Color(0xFF00E5FF),
    key = Color(0xFF141A2E).copy(alpha = 0.88f)
)

val LightPalette = SudokuPalette(
    dark = false,
    background = Color(0xFFF0F2F5),
    surface = Color.White.copy(alpha = 0.86f),
    surfaceStrong = Color.White,
    outline = Color.Black.copy(alpha = 0.09f),
    text = Color(0xFF1C1E2A),
    textDim = Color(0xFF1C1E2A).copy(alpha = 0.60f),
    accent = Color(0xFF007AFF),
    accentSoft = Color(0xFF007AFF).copy(alpha = 0.12f),
    glow = Color(0xFF7C4DFF),
    boardBg = Color.White,
    gridThin = Color(0xFFD5D8E0),
    selection = Color(0xFF007AFF).copy(alpha = 0.26f),
    peer = Color(0xFF007AFF).copy(alpha = 0.07f),
    sameNumber = Color(0xFF7C4DFF).copy(alpha = 0.18f),
    conflictBg = ErrorRed.copy(alpha = 0.14f),
    userDigit = Color(0xFF1565C0),
    hintDigit = Color(0xFFB8860B),
    note = Color(0xFF5C6070),
    key = Color.White.copy(alpha = 0.94f)
)

/** Koyu temada pastel, açık temada okunaklı koyu tonlar. */
fun levelColor(difficulty: Difficulty?, dark: Boolean): Color = when (difficulty) {
    Difficulty.EASY -> if (dark) LevelEasyColor else Color(0xFF2E7D32)
    Difficulty.MEDIUM -> if (dark) LevelMediumColor else Color(0xFFB26A00)
    Difficulty.HARD -> if (dark) LevelHardColor else Color(0xFF1A5FD0)
    Difficulty.ULTRA -> if (dark) LevelUltraColor else Color(0xFFC62828)
    null -> if (dark) Color(0xFF2979FF) else Color(0xFF007AFF)
}

fun levelPastel(difficulty: Difficulty): Color = when (difficulty) {
    Difficulty.EASY -> LevelEasyColor
    Difficulty.MEDIUM -> LevelMediumColor
    Difficulty.HARD -> LevelHardColor
    Difficulty.ULTRA -> LevelUltraColor
}
