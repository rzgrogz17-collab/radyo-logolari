package com.elmas.sudoku.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlin.math.sin
import kotlin.random.Random

// ══════════════════════════════════════════════════════════════════
// 🌌 ARKA PLAN: KAYAN YILDIZLI GECE (Dark Mode)
// ══════════════════════════════════════════════════════════════════
@Composable
fun StarFieldBackground(modifier: Modifier = Modifier) {
    val staticStars = remember {
        List(120) {
            Triple(Random.nextFloat(), Random.nextFloat(), Random.nextFloat() * 1.8f + 0.3f)
        }
    }
    val shootingStars = remember {
        List(4) {
            ShootingStar(
                startX = Random.nextFloat(),
                startY = Random.nextFloat() * 0.5f,
                speed = Random.nextFloat() * 0.3f + 0.2f,
                offset = Random.nextFloat()
            )
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "stars")
    val time by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(8000, easing = LinearEasing)),
        label = "starTime"
    )
    val shootTime by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(6000, easing = LinearEasing)),
        label = "shootTime"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF0B1026), Color(0xFF080818), Color(0xFF000000))
            )
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF3D2A8C).copy(alpha = 0.28f), Color.Transparent),
                center = Offset(size.width * 0.15f, size.height * 0.18f),
                radius = size.width * 0.7f
            ),
            radius = size.width * 0.7f,
            center = Offset(size.width * 0.15f, size.height * 0.18f)
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF0D47A1).copy(alpha = 0.22f), Color.Transparent),
                center = Offset(size.width * 0.9f, size.height * 0.85f),
                radius = size.width * 0.8f
            ),
            radius = size.width * 0.8f,
            center = Offset(size.width * 0.9f, size.height * 0.85f)
        )

        staticStars.forEachIndexed { i, (x, y, sz) ->
            val twinkle = (sin((time * 6.28f) + (i * 0.5f)) + 1f) / 2f
            drawCircle(
                color = Color.White.copy(alpha = 0.3f + twinkle * 0.6f),
                radius = sz * 1.5f,
                center = Offset(x * size.width, y * size.height)
            )
        }

        shootingStars.forEach { star ->
            val t = (shootTime + star.offset) % 1f
            val progress = t * star.speed * 4f
            if (progress in 0f..1.5f) {
                val x = (star.startX + progress * 0.6f) * size.width
                val y = (star.startY + progress * 0.4f) * size.height
                for (k in 0..8) {
                    val tailProgress = progress - k * 0.02f
                    if (tailProgress > 0) {
                        val tx = (star.startX + tailProgress * 0.6f) * size.width
                        val ty = (star.startY + tailProgress * 0.4f) * size.height
                        drawCircle(
                            color = Color.White.copy(alpha = (0.8f - k * 0.1f).coerceAtLeast(0f)),
                            radius = (3f - k * 0.3f).coerceAtLeast(0.5f),
                            center = Offset(tx, ty)
                        )
                    }
                }
                drawCircle(color = Color.White, radius = 3.5f, center = Offset(x, y))
            }
        }
    }
}

data class ShootingStar(
    val startX: Float,
    val startY: Float,
    val speed: Float,
    val offset: Float
)

// ══════════════════════════════════════════════════════════════════
// 🌅 ARKA PLAN: SABAH/ŞAFAK (Light Mode)
// ══════════════════════════════════════════════════════════════════
@Composable
fun MorningSkyBackground(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "morning")
    val cloudShift by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(40000, easing = LinearEasing)),
        label = "cloud"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFFFE0C7), Color(0xFFFFD1DC), Color(0xFFE8F4FD))
            )
        )

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFFFF3D1).copy(alpha = 0.8f), Color(0xFFFFE0B2).copy(alpha = 0.0f)),
                center = Offset(size.width * 0.85f, size.height * 0.15f),
                radius = size.width * 0.4f
            ),
            radius = size.width * 0.4f,
            center = Offset(size.width * 0.85f, size.height * 0.15f)
        )

        for (k in 0..2) {
            val cy = size.height * (0.2f + k * 0.15f)
            val cx = ((cloudShift + k * 0.33f) % 1f) * size.width * 1.4f - size.width * 0.2f
            drawCircle(
                color = Color.White.copy(alpha = 0.35f),
                radius = size.width * 0.18f,
                center = Offset(cx, cy)
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.25f),
                radius = size.width * 0.12f,
                center = Offset(cx + size.width * 0.1f, cy + size.height * 0.02f)
            )
        }
    }
}
