package com.elmas.sudoku.ads

/**
 * Bütün reklam ayarları burada.
 *
 * USE_YANDEX_AND_HUAWEI = true
 *   Ülke YANDEX_COUNTRIES listesindeyse Yandex, değilse Huawei Petal reklamı gösterilir.
 * USE_YANDEX_AND_HUAWEI = false
 *   Ülke ayrımı yapılmaz, her ülkede AdMob reklamı gösterilir.
 *
 * Banner, geçiş, ödüllü ve native reklam aynı kuralı izler.
 */
object AdConfig {

    const val ADS_ENABLED = true

    const val USE_YANDEX_AND_HUAWEI = true

    /** Boş bırakılırsa ülke cihazdan bulunur. Denemek için "TR" veya "DE" yazılabilir. */
    const val TEST_COUNTRY = ""

    val YANDEX_COUNTRIES = setOf(
        "RU", "TR", "KZ", "BY", "UZ", "AM", "KG", "AZ", "TJ", "GE", "MD", "RS"
    )

    /** Ödüllü reklam sonunda eklenen geri al veya ipucu hakkı. */
    const val REWARD_AMOUNT = 3

    // Yandex
    const val YANDEX_BANNER_ID = "R-M-19542867-1"
    const val YANDEX_INTERSTITIAL_ID = "R-M-19542867-2"
    const val YANDEX_REWARDED_ID = "R-M-19542867-3"
    /** Yandex panelinde native reklam birimi açıp kimliğini buraya yaz. */
    const val YANDEX_NATIVE_ID = "demo-native-app-yandex"

    // Huawei Petal test kimlikleri. Yayından önce Petal Publisher Center kimlikleriyle değiştir.
    const val HUAWEI_BANNER_ID = "testw6vs28auh3"
    const val HUAWEI_INTERSTITIAL_ID = "testb4znbuh3n2"
    const val HUAWEI_REWARDED_ID = "testx9dtjwj8hp"
    const val HUAWEI_NATIVE_ID = "testu7m3hc4gvm"

    // AdMob test kimlikleri. Uygulama kimliği: res/values/strings.xml → admob_app_id
    const val ADMOB_BANNER_ID = "ca-app-pub-3940256099942544/9214589741"
    const val ADMOB_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    const val ADMOB_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"
    const val ADMOB_NATIVE_ID = "ca-app-pub-3940256099942544/2247696110"
}
