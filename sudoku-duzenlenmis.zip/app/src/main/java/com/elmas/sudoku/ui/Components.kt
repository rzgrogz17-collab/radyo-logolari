package com.elmas.sudoku.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.elmas.sudoku.theme.SudokuPalette
import java.util.Locale

fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

fun formatTime(totalSeconds: Int): String {
    val s = totalSeconds.coerceAtLeast(0)
    val hours = s / 3600
    val minutes = s % 3600 / 60
    val seconds = s % 60
    return if (hours > 0) {
        String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format(Locale.US, "%02d:%02d", minutes, seconds)
    }
}

@Composable
fun rememberBreath(): State<Float> {
    val transition = rememberInfiniteTransition(label = "breath")
    return transition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathAlpha"
    )
}

/** Koyu temada yarı saydam cam, açık temada beyaz kart. */
fun Modifier.panel(palette: SudokuPalette, shape: Shape, elevation: Dp = 0.dp): Modifier {
    val base = if (elevation > 0.dp) {
        shadow(
            elevation = elevation,
            shape = shape,
            clip = false,
            ambientColor = if (palette.dark) palette.glow else Color.Black,
            spotColor = if (palette.dark) palette.glow else Color.Black
        )
    } else {
        this
    }
    return base
        .clip(shape)
        .background(if (palette.dark) palette.surface else palette.surfaceStrong)
        .border(1.dp, palette.outline, shape)
}

/** Nefes alan neon çerçeve. Animasyon değeri yalnızca çizimde okunur. */
fun Modifier.neonBorder(breath: State<Float>, color: Color, width: Dp, radius: Dp): Modifier =
    drawWithContent {
        drawContent()
        val stroke = width.toPx()
        val inset = stroke / 2f
        val corner = (radius.toPx() - inset).coerceAtLeast(0f)
        drawRoundRect(
            color = color.copy(alpha = (0.35f + breath.value * 0.65f).coerceIn(0f, 1f)),
            topLeft = Offset(inset, inset),
            size = Size(size.width - stroke, size.height - stroke),
            cornerRadius = CornerRadius(corner, corner),
            style = Stroke(stroke)
        )
    }
