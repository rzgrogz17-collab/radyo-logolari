package com.elmas.sudoku.ads

import android.app.Activity
import android.content.Context
import android.content.pm.ApplicationInfo
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.elmas.sudoku.R
import com.yandex.mobile.ads.banner.BannerAdEventListener
import com.yandex.mobile.ads.banner.BannerAdSize
import com.yandex.mobile.ads.banner.BannerAdView
import com.yandex.mobile.ads.common.AdBindingResult
import com.yandex.mobile.ads.common.AdError
import com.yandex.mobile.ads.common.AdRequest
import com.yandex.mobile.ads.common.AdRequestError
import com.yandex.mobile.ads.common.AdTheme
import com.yandex.mobile.ads.common.ImpressionData
import com.yandex.mobile.ads.common.YandexAds as YandexSdk
import com.yandex.mobile.ads.interstitial.InterstitialAd
import com.yandex.mobile.ads.interstitial.InterstitialAdEventListener
import com.yandex.mobile.ads.interstitial.InterstitialAdLoadListener
import com.yandex.mobile.ads.interstitial.InterstitialAdLoader
import com.yandex.mobile.ads.nativeads.MediaView
import com.yandex.mobile.ads.nativeads.NativeAd
import com.yandex.mobile.ads.nativeads.NativeAdLoadListener
import com.yandex.mobile.ads.nativeads.NativeAdLoader
import com.yandex.mobile.ads.nativeads.NativeAdView
import com.yandex.mobile.ads.nativeads.NativeAdViewBinder
import com.yandex.mobile.ads.rewarded.Reward
import com.yandex.mobile.ads.rewarded.RewardedAd
import com.yandex.mobile.ads.rewarded.RewardedAdEventListener
import com.yandex.mobile.ads.rewarded.RewardedAdLoadListener
import com.yandex.mobile.ads.rewarded.RewardedAdLoader

internal class YandexAds : AdProvider {

    private var interstitialLoader: InterstitialAdLoader? = null
    private var interstitial: InterstitialAd? = null
    private var rewardedLoader: RewardedAdLoader? = null
    private var rewarded: RewardedAd? = null
    private var nativeLoader: NativeAdLoader? = null
    private var nativeAd: NativeAd? = null

    override fun initialize(activity: Activity, onReady: () -> Unit) {
        val debuggable = activity.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0
        // Debug derlemede reklamın çevresindeki yeşil çerçeve entegrasyonun doğru olduğunu gösterir.
        YandexSdk.enableDebugErrorIndicator(debuggable)
        YandexSdk.initialize(activity.applicationContext) { onReady() }
    }

    override fun loadInterstitial(context: Context, done: (Boolean) -> Unit) {
        val loader = interstitialLoader ?: InterstitialAdLoader(context).also { interstitialLoader = it }
        loader.loadAd(
            AdRequest.Builder(AdConfig.YANDEX_INTERSTITIAL_ID).build(),
            object : InterstitialAdLoadListener {
                override fun onAdLoaded(interstitialAd: InterstitialAd) {
                    interstitial = interstitialAd
                    done(true)
                }

                override fun onAdFailedToLoad(error: AdRequestError) {
                    Log.w(TAG, "Gecis reklami yuklenemedi: ${error.code} ${error.description}")
                    done(false)
                }
            }
        )
    }

    override fun hasInterstitial() = interstitial != null

    override fun showInterstitial(activity: Activity, onClosed: () -> Unit): Boolean {
        val ad = interstitial ?: return false
        interstitial = null
        ad.setAdEventListener(object : InterstitialAdEventListener {
            override fun onAdShown() {}
            override fun onAdFailedToShow(adError: AdError) = onClosed()
            override fun onAdDismissed() = onClosed()
            override fun onAdClicked() {}
            override fun onAdImpression(impressionData: ImpressionData?) {}
        })
        ad.show(activity)
        return true
    }

    override fun loadRewarded(context: Context, done: (Boolean) -> Unit) {
        val loader = rewardedLoader ?: RewardedAdLoader(context).also { rewardedLoader = it }
        loader.loadAd(
            AdRequest.Builder(AdConfig.YANDEX_REWARDED_ID).build(),
            object : RewardedAdLoadListener {
                override fun onAdLoaded(rewardedAd: RewardedAd) {
                    rewarded = rewardedAd
                    done(true)
                }

                override fun onAdFailedToLoad(error: AdRequestError) {
                    Log.w(TAG, "Odullu reklam yuklenemedi: ${error.code} ${error.description}")
                    done(false)
                }
            }
        )
    }

    override fun hasRewarded() = rewarded != null

    override fun showRewarded(activity: Activity, onReward: () -> Unit, onClosed: () -> Unit): Boolean {
        val ad = rewarded ?: return false
        rewarded = null
        ad.setAdEventListener(object : RewardedAdEventListener {
            override fun onAdShown() {}
            override fun onAdFailedToShow(adError: AdError) = onClosed()
            override fun onAdDismissed() = onClosed()
            override fun onAdClicked() {}
            override fun onAdImpression(impressionData: ImpressionData?) {}
            override fun onRewarded(reward: Reward) = onReward()
        })
        ad.show(activity)
        return true
    }

    override fun createBanner(
        activity: Activity,
        widthDp: Int,
        onLoaded: () -> Unit,
        onFailed: () -> Unit
    ): View {
        val banner = BannerAdView(activity)
        banner.setAdSize(BannerAdSize.sticky(activity, widthDp))
        banner.setBannerAdEventListener(object : BannerAdEventListener {
            override fun onAdLoaded() = onLoaded()
            override fun onAdFailedToLoad(error: AdRequestError) {
                Log.w(TAG, "Banner yuklenemedi: ${error.code} ${error.description}")
                onFailed()
            }

            override fun onAdClicked() {}
            override fun onImpression(impressionData: ImpressionData?) {}
        })
        banner.loadAd(AdRequest.Builder(AdConfig.YANDEX_BANNER_ID).build())
        return banner
    }

    override fun destroyBanner(view: View) {
        (view as? BannerAdView)?.destroy()
    }

    override fun loadNative(activity: Activity, dark: Boolean, done: (NativeAdHandle?) -> Unit): () -> Unit {
        var cancelled = false
        val loader = NativeAdLoader(activity)
        nativeLoader = loader
        loader.loadAd(
            AdRequest.Builder(AdConfig.YANDEX_NATIVE_ID)
                .setPreferredTheme(if (dark) AdTheme.DARK else AdTheme.LIGHT)
                .build(),
            object : NativeAdLoadListener {
                override fun onAdLoaded(ad: NativeAd) {
                    if (cancelled || activity.isFinishing || activity.isDestroyed) return
                    val handle = try {
                        bindNative(activity, ad, dark)
                    } catch (t: Throwable) {
                        Log.e(TAG, "Native reklam baglanamadi", t)
                        null
                    }
                    if (handle != null) nativeAd = ad
                    done(handle)
                }

                override fun onAdFailedToLoad(error: AdRequestError) {
                    Log.w(TAG, "Native reklam yuklenemedi: ${error.code} ${error.description}")
                    if (!cancelled) done(null)
                }
            }
        )
        return {
            cancelled = true
            runCatching { loader.cancelLoading() }
            if (nativeLoader === loader) {
                nativeLoader = null
                nativeAd = null
            }
        }
    }

    private fun bindNative(activity: Activity, ad: NativeAd, dark: Boolean): NativeAdHandle? {
        val adView = LayoutInflater.from(activity)
            .inflate(R.layout.ad_native_yandex, null, false) as NativeAdView
        val binder = NativeAdViewBinder.Builder(adView)
            .setAgeView(adView.child<TextView>(R.id.ad_age))
            .setBodyView(adView.child<TextView>(R.id.ad_body))
            .setCallToActionView(adView.child<TextView>(R.id.ad_call_to_action))
            .setDomainView(adView.child<TextView>(R.id.ad_domain))
            .setFaviconView(adView.child<ImageView>(R.id.ad_favicon))
            .setFeedbackView(adView.child<ImageView>(R.id.ad_feedback))
            .setIconView(adView.child<ImageView>(R.id.ad_app_icon))
            .setMediaView(adView.child<MediaView>(R.id.ad_media))
            .setPriceView(adView.child<TextView>(R.id.ad_price))
            .setRatingView(adView.child<YandexRatingView>(R.id.ad_rating))
            .setReviewCountView(adView.child<TextView>(R.id.ad_review_count))
            .setSponsoredView(adView.child<TextView>(R.id.ad_sponsored))
            .setTitleView(adView.child<TextView>(R.id.ad_headline))
            .setWarningView(adView.child<TextView>(R.id.ad_warning))
            .build()

        val result = ad.bindNativeAd(binder)
        if (result is AdBindingResult.Failure) {
            Log.w(TAG, "Native reklam baglanamadi: ${result.missingAssetName} ${result.exception.message}")
            return null
        }
        hideMissingAssets(adView, ad)
        NativeViewStyle.apply(adView, dark)

        return object : NativeAdHandle {
            override val view: View = adView
            override fun applyTheme(dark: Boolean) = NativeViewStyle.apply(adView, dark)
            override fun destroy() = Unit
        }
    }

    private fun hideMissingAssets(adView: View, ad: NativeAd) {
        val assets = ad.adAssets
        fun hideIf(id: Int, missing: Boolean) {
            if (missing) adView.findViewById<View>(id)?.visibility = View.GONE
        }
        hideIf(R.id.ad_age, assets.age.isNullOrBlank())
        hideIf(R.id.ad_body, assets.body.isNullOrBlank())
        hideIf(R.id.ad_domain, assets.domain.isNullOrBlank())
        hideIf(R.id.ad_favicon, assets.favicon == null)
        hideIf(R.id.ad_app_icon, assets.icon == null)
        hideIf(R.id.ad_media, assets.media == null)
        hideIf(R.id.ad_price, assets.price.isNullOrBlank())
        hideIf(R.id.ad_rating, assets.rating == null)
        hideIf(R.id.ad_review_count, assets.reviewCount.isNullOrBlank())
        hideIf(R.id.ad_sponsored, assets.sponsored.isNullOrBlank())
        hideIf(R.id.ad_warning, assets.warning == null)
        hideIf(R.id.ad_feedback, !assets.isFeedbackAvailable)
    }

    private fun <T : View> View.child(id: Int): T =
        findViewById(id) ?: error("Native reklam şablonunda görünüm eksik: $id")

    private companion object {
        const val TAG = "YandexAds"
    }
}
