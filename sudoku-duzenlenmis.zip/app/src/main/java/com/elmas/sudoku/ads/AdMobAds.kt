package com.elmas.sudoku.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.elmas.sudoku.R
import com.elmas.sudoku.ui.Lang
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import java.util.concurrent.atomic.AtomicBoolean

internal class AdMobAds : AdProvider {

    private var interstitial: InterstitialAd? = null
    private var rewarded: RewardedAd? = null
    private var nativeLoader: AdLoader? = null

    override fun initialize(activity: Activity, onReady: () -> Unit) {
        val appContext = activity.applicationContext
        val consent = UserMessagingPlatform.getConsentInformation(activity)
        val started = AtomicBoolean(false)
        val start = {
            if (started.compareAndSet(false, true)) {
                Thread {
                    try {
                        MobileAds.initialize(appContext) { onReady() }
                    } catch (t: Throwable) {
                        Log.e(TAG, "AdMob baslatilamadi", t)
                    }
                }.start()
            }
        }
        val params = ConsentRequestParameters.Builder()
            .setTagForUnderAgeOfConsent(false)
            .build()
        consent.requestConsentInfoUpdate(
            activity,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { formError ->
                    if (formError != null) Log.w(TAG, "Onay formu: ${formError.message}")
                    AdManager.setPrivacyOptionsRequired(
                        consent.privacyOptionsRequirementStatus ==
                            ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
                    )
                    if (consent.canRequestAds()) start()
                }
            },
            { requestError ->
                Log.w(TAG, "Onay bilgisi alinamadi: ${requestError.message}")
                if (consent.canRequestAds()) start()
            }
        )
        if (consent.canRequestAds()) start()
    }

    fun showPrivacyOptions(activity: Activity) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { error ->
            if (error != null) Log.w(TAG, "Gizlilik formu: ${error.message}")
        }
    }

    override fun loadInterstitial(context: Context, done: (Boolean) -> Unit) {
        InterstitialAd.load(
            context,
            AdConfig.ADMOB_INTERSTITIAL_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitial = ad
                    done(true)
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitial = null
                    Log.w(TAG, "Gecis reklami yuklenemedi: ${error.code} ${error.message}")
                    done(false)
                }
            }
        )
    }

    override fun hasInterstitial() = interstitial != null

    override fun showInterstitial(activity: Activity, onClosed: () -> Unit): Boolean {
        val ad = interstitial ?: return false
        interstitial = null
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() = onClosed()
            override fun onAdFailedToShowFullScreenContent(error: AdError) = onClosed()
        }
        ad.show(activity)
        return true
    }

    override fun loadRewarded(context: Context, done: (Boolean) -> Unit) {
        RewardedAd.load(
            context,
            AdConfig.ADMOB_REWARDED_ID,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewarded = ad
                    done(true)
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewarded = null
                    Log.w(TAG, "Odullu reklam yuklenemedi: ${error.code} ${error.message}")
                    done(false)
                }
            }
        )
    }

    override fun hasRewarded() = rewarded != null

    override fun showRewarded(activity: Activity, onReward: () -> Unit, onClosed: () -> Unit): Boolean {
        val ad = rewarded ?: return false
        rewarded = null
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() = onClosed()
            override fun onAdFailedToShowFullScreenContent(error: AdError) = onClosed()
        }
        ad.show(activity) { onReward() }
        return true
    }

    override fun createBanner(
        activity: Activity,
        widthDp: Int,
        onLoaded: () -> Unit,
        onFailed: () -> Unit
    ): View {
        val banner = AdView(activity)
        banner.adUnitId = AdConfig.ADMOB_BANNER_ID
        banner.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, widthDp))
        banner.adListener = object : AdListener() {
            override fun onAdLoaded() = onLoaded()
            override fun onAdFailedToLoad(error: LoadAdError) {
                Log.w(TAG, "Banner yuklenemedi: ${error.code} ${error.message}")
                onFailed()
            }
        }
        banner.loadAd(AdRequest.Builder().build())
        return banner
    }

    override fun pauseBanner(view: View) {
        (view as? AdView)?.pause()
    }

    override fun resumeBanner(view: View) {
        (view as? AdView)?.resume()
    }

    override fun destroyBanner(view: View) {
        (view as? AdView)?.destroy()
    }

    override fun loadNative(activity: Activity, dark: Boolean, done: (NativeAdHandle?) -> Unit): () -> Unit {
        var cancelled = false
        val loader = AdLoader.Builder(activity, AdConfig.ADMOB_NATIVE_ID)
            .forNativeAd { ad ->
                if (cancelled || activity.isFinishing || activity.isDestroyed) {
                    ad.destroy()
                    return@forNativeAd
                }
                val handle = try {
                    bindNative(activity, ad, dark)
                } catch (t: Throwable) {
                    Log.e(TAG, "Native reklam baglanamadi", t)
                    ad.destroy()
                    null
                }
                done(handle)
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "Native reklam yuklenemedi: ${error.code} ${error.message}")
                    if (!cancelled) done(null)
                }
            })
            .withNativeAdOptions(
                NativeAdOptions.Builder()
                    .setAdChoicesPlacement(NativeAdOptions.ADCHOICES_TOP_RIGHT)
                    .build()
            )
            .build()
        nativeLoader = loader
        loader.loadAd(AdRequest.Builder().build())
        return {
            cancelled = true
            if (nativeLoader === loader) nativeLoader = null
        }
    }

    private fun bindNative(activity: Activity, ad: NativeAd, dark: Boolean): NativeAdHandle {
        val adView = LayoutInflater.from(activity)
            .inflate(R.layout.ad_native_admob, null, false) as NativeAdView
        val headline = adView.findViewById<TextView>(R.id.ad_headline)
        val body = adView.findViewById<TextView>(R.id.ad_body)
        val advertiser = adView.findViewById<TextView>(R.id.ad_advertiser)
        val icon = adView.findViewById<ImageView>(R.id.ad_app_icon)
        val cta = adView.findViewById<Button>(R.id.ad_call_to_action)
        val media = adView.findViewById<MediaView>(R.id.ad_media)
        adView.findViewById<TextView>(R.id.ad_badge)?.text = Lang.get("ad_label")

        headline.text = ad.headline
        adView.headlineView = headline

        body.text = ad.body.orEmpty()
        body.visibility = if (ad.body.isNullOrBlank()) View.GONE else View.VISIBLE
        adView.bodyView = body

        advertiser.text = (ad.advertiser ?: ad.store).orEmpty()
        adView.advertiserView = advertiser

        val iconDrawable = ad.icon?.drawable
        icon.setImageDrawable(iconDrawable)
        icon.visibility = if (iconDrawable == null) View.GONE else View.VISIBLE
        adView.iconView = icon

        cta.text = ad.callToAction.orEmpty()
        cta.visibility = if (ad.callToAction.isNullOrBlank()) View.INVISIBLE else View.VISIBLE
        adView.callToActionView = cta

        adView.mediaView = media
        ad.mediaContent?.let { media.setMediaContent(it) }

        adView.setNativeAd(ad)
        NativeViewStyle.apply(adView, dark)

        return object : NativeAdHandle {
            override val view: View = adView
            override fun applyTheme(dark: Boolean) = NativeViewStyle.apply(adView, dark)
            override fun destroy() {
                runCatching { adView.destroy() }
                runCatching { ad.destroy() }
            }
        }
    }

    private companion object {
        const val TAG = "AdMobAds"
    }
}
