package com.elmas.sudoku.ads

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.elmas.sudoku.theme.SudokuPalette
import com.elmas.sudoku.ui.findActivity
import kotlinx.coroutines.delay

/** Seçili ağın banner reklamı. Reklam gelmezse yer kaplamaz. */
@Composable
fun BannerAd(modifier: Modifier = Modifier) {
    if (!AdConfig.ADS_ENABLED) return
    val activity = LocalContext.current.findActivity() ?: return
    val ready by AdManager.ready
    if (!ready) return

    var attempt by remember { mutableIntStateOf(0) }
    var failed by remember { mutableStateOf(false) }

    LaunchedEffect(failed, attempt) {
        if (failed && attempt < 4) {
            delay(20_000L * (attempt + 1))
            failed = false
            attempt++
        }
    }

    BoxWithConstraints(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        val widthDp = maxWidth.value.toInt()
        if (!failed && widthDp > 0) {
            key(attempt, widthDp) {
                BannerSlot(activity, widthDp, onFailed = { failed = true })
            }
        }
    }
}

@Composable
private fun BannerSlot(activity: Activity, widthDp: Int, onFailed: () -> Unit) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val holder = remember { arrayOfNulls<View>(1) }
    val loadedOnce = remember { booleanArrayOf(false) }

    AndroidView(
        factory = { context ->
            val view = AdManager.createBanner(
                activity,
                widthDp,
                onLoaded = { loadedOnce[0] = true },
                onFailed = { if (!loadedOnce[0]) onFailed() }
            ) ?: View(context)
            holder[0] = view
            view
        },
        onRelease = { view ->
            holder[0] = null
            AdManager.destroyBanner(view)
        },
        modifier = Modifier.fillMaxWidth().wrapContentHeight()
    )

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            val view = holder[0] ?: return@LifecycleEventObserver
            when (event) {
                Lifecycle.Event.ON_RESUME -> AdManager.resumeBanner(view)
                Lifecycle.Event.ON_PAUSE -> AdManager.pauseBanner(view)
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
}

/** Menüdeki tam genişlikte native reklam kartı. Reklam gelmezse hiç görünmez. */
@Composable
fun NativeAdCard(palette: SudokuPalette, modifier: Modifier = Modifier) {
    if (!AdConfig.ADS_ENABLED) return
    val activity = LocalContext.current.findActivity() ?: return
    val ready by AdManager.ready
    if (!ready) return

    val dark = palette.dark
    var handle by remember { mutableStateOf<NativeAdHandle?>(null) }
    var attempt by remember { mutableIntStateOf(0) }
    var failedAttempt by remember { mutableIntStateOf(-1) }

    DisposableEffect(attempt) {
        var disposed = false
        val cancel = AdManager.loadNative(activity, dark) { loaded ->
            when {
                disposed -> loaded?.destroy()
                loaded == null -> failedAttempt = attempt
                else -> handle = loaded
            }
        }
        onDispose {
            disposed = true
            cancel()
        }
    }

    LaunchedEffect(failedAttempt) {
        if (failedAttempt >= 0 && failedAttempt == attempt && attempt < 3) {
            delay(15_000L * (attempt + 1))
            attempt++
        }
    }

    val current = handle ?: return
    DisposableEffect(current) {
        onDispose { current.destroy() }
    }

    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(palette.surfaceStrong.copy(alpha = if (dark) 0.92f else 0.97f))
            .border(1.dp, palette.outline, shape)
    ) {
        key(current) {
            AndroidView(
                factory = {
                    current.view.also { view -> (view.parent as? ViewGroup)?.removeView(view) }
                },
                update = { current.applyTheme(dark) },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
