package com.elmas.sudoku.logic

import android.content.Context
import android.content.SharedPreferences

class SavedGame(
    val cells: IntArray,
    val solution: IntArray,
    val kinds: IntArray,
    val notes: IntArray,
    val difficulty: Difficulty?,
    val elapsedSeconds: Int
) {
    /** Oyuncunun doldurması gereken hücrelerin yüzde kaçı dolu. */
    val progressPercent: Int
        get() {
            var total = 0
            var filled = 0
            for (i in 0 until 81) {
                if (kinds[i] == CellKind.GIVEN) continue
                total++
                if (cells[i] != 0) filled++
            }
            return if (total == 0) 100 else filled * 100 / total
        }
}

class GameStorage(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("SudokuSave", Context.MODE_PRIVATE)

    fun hasSavedGame(): Boolean =
        prefs.getBoolean("has_saved_game", false) && !prefs.getString("saved_board", "").isNullOrEmpty()

    fun saveGame(game: SavedGame) {
        prefs.edit()
            .putString("saved_board", game.cells.joinToString(","))
            .putString("saved_solution", game.solution.joinToString(","))
            .putString("saved_kinds", game.kinds.joinToString(""))
            .putString("saved_notes", game.notes.joinToString(","))
            .putString("saved_difficulty", game.difficulty?.name ?: "")
            .putInt("saved_elapsed", game.elapsedSeconds)
            .putBoolean("has_saved_game", true)
            .apply()
    }

    fun loadGame(): SavedGame? {
        if (!hasSavedGame()) return null
        val cells = parseGrid(prefs.getString("saved_board", null)) ?: return null
        val solution = parseGrid(prefs.getString("saved_solution", null)) ?: return null
        if (solution.any { it !in 1..9 } || !SudokuRules.isSolved(solution.asList())) return null
        if (cells.any { it !in 0..9 }) return null

        val kindsText = prefs.getString("saved_kinds", null)
        val kinds = if (kindsText != null && kindsText.length == 81) {
            IntArray(81) { (kindsText[it] - '0').coerceIn(CellKind.FREE, CellKind.HINTED) }
        } else {
            // Eski kayıtlarda verilen sayılar tutulmuyordu. Çözümle aynı olanlar kilitlenir.
            IntArray(81) { if (cells[it] != 0 && cells[it] == solution[it]) CellKind.GIVEN else CellKind.FREE }
        }
        val notes = parseNotes(prefs.getString("saved_notes", null))
        val difficulty = prefs.getString("saved_difficulty", null)
            ?.takeIf { it.isNotEmpty() }
            ?.let { name -> Difficulty.entries.firstOrNull { it.name == name } }
        val elapsed = prefs.getInt("saved_elapsed", 0).coerceAtLeast(0)
        return SavedGame(cells, solution, kinds, notes, difficulty, elapsed)
    }

    fun clearSave() {
        prefs.edit()
            .remove("saved_board")
            .remove("saved_solution")
            .remove("saved_kinds")
            .remove("saved_notes")
            .remove("saved_difficulty")
            .remove("saved_elapsed")
            .remove("has_saved_game")
            .apply()
    }

    fun saveRights(hints: Int, undos: Int) {
        prefs.edit().putInt("hints_left", hints).putInt("undos_left", undos).apply()
    }

    fun getHints() = prefs.getInt("hints_left", 3)
    fun getUndos() = prefs.getInt("undos_left", 3)

    fun isDarkMode() = prefs.getBoolean("dark_mode", true)
    fun setDarkMode(dark: Boolean) = prefs.edit().putBoolean("dark_mode", dark).apply()

    fun isMuted() = prefs.getBoolean("muted", false)
    fun setMuted(muted: Boolean) = prefs.edit().putBoolean("muted", muted).apply()

    /** Saniye cinsinden en iyi süre, hiç kazanılmadıysa 0. */
    fun bestTime(difficulty: Difficulty) = prefs.getInt("best_${difficulty.name}", 0)

    fun wins(difficulty: Difficulty) = prefs.getInt("wins_${difficulty.name}", 0)

    /** Galibiyeti kaydeder. Süre yeni rekorsa true döner. */
    fun recordWin(difficulty: Difficulty, seconds: Int): Boolean {
        val best = bestTime(difficulty)
        val record = best == 0 || seconds < best
        val editor = prefs.edit().putInt("wins_${difficulty.name}", wins(difficulty) + 1)
        if (record) editor.putInt("best_${difficulty.name}", seconds.coerceAtLeast(1))
        editor.apply()
        return record
    }

    private fun parseGrid(text: String?): IntArray? {
        if (text.isNullOrEmpty()) return null
        val parts = text.split(",")
        if (parts.size != 81) return null
        return try {
            IntArray(81) { parts[it].trim().toInt() }
        } catch (e: NumberFormatException) {
            null
        }
    }

    private fun parseNotes(text: String?): IntArray {
        val parts = text?.split(",") ?: return IntArray(81)
        if (parts.size != 81) return IntArray(81)
        return IntArray(81) { parts[it].trim().toIntOrNull()?.and(0x3FE) ?: 0 }
    }
}
