package com.elmas.sudoku.ads

import android.view.View
import android.widget.TextView
import com.elmas.sudoku.R

/** Native reklam şablonlarını açık/koyu temaya göre boyar. */
internal object NativeViewStyle {

    private val dimTexts = intArrayOf(
        R.id.ad_body,
        R.id.ad_advertiser,
        R.id.ad_sponsored,
        R.id.ad_age,
        R.id.ad_domain,
        R.id.ad_review_count,
        R.id.ad_price,
        R.id.ad_warning
    )

    fun apply(root: View, dark: Boolean) {
        val title = if (dark) 0xFFEEF1FF.toInt() else 0xFF1C1E2A.toInt()
        val dim = if (dark) 0xB3EEF1FF.toInt() else 0x991C1E2A.toInt()
        val accent = if (dark) 0xFF2979FF.toInt() else 0xFF007AFF.toInt()
        val badge = if (dark) 0xFFB388FF.toInt() else 0xFF7C4DFF.toInt()

        root.findViewById<TextView>(R.id.ad_headline)?.setTextColor(title)
        for (id in dimTexts) root.findViewById<TextView>(id)?.setTextColor(dim)
        root.findViewById<View>(R.id.ad_call_to_action)?.background?.mutate()?.setTint(accent)
        root.findViewById<View>(R.id.ad_badge)?.background?.mutate()?.setTint(badge)
    }
}
