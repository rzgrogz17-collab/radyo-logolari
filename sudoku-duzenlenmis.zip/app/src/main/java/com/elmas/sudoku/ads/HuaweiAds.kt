package com.elmas.sudoku.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.elmas.sudoku.R
import com.elmas.sudoku.ui.Lang
import com.huawei.hms.ads.AdListener
import com.huawei.hms.ads.AdParam
import com.huawei.hms.ads.BannerAdSize
import com.huawei.hms.ads.HwAds
import com.huawei.hms.ads.InterstitialAd
import com.huawei.hms.ads.banner.BannerView
import com.huawei.hms.ads.nativead.MediaView
import com.huawei.hms.ads.nativead.NativeAd
import com.huawei.hms.ads.nativead.NativeAdConfiguration
import com.huawei.hms.ads.nativead.NativeAdLoader
import com.huawei.hms.ads.nativead.NativeView
import com.huawei.hms.ads.reward.Reward
import com.huawei.hms.ads.reward.RewardAd
import com.huawei.hms.ads.reward.RewardAdLoadListener
import com.huawei.hms.ads.reward.RewardAdStatusListener

internal class HuaweiAds : AdProvider {

    private var interstitial: InterstitialAd? = null
    private var onInterstitialClosed: (() -> Unit)? = null
    private var rewarded: RewardAd? = null
    private var nativeLoader: NativeAdLoader? = null

    override fun initialize(activity: Activity, onReady: () -> Unit) {
        HwAds.init(activity.applicationContext)
        onReady()
    }

    override fun loadInterstitial(context: Context, done: (Boolean) -> Unit) {
        val ad = InterstitialAd(context)
        ad.setAdId(AdConfig.HUAWEI_INTERSTITIAL_ID)
        var loaded = false
        ad.setAdListener(object : AdListener() {
            override fun onAdLoaded() {
                loaded = true
                interstitial = ad
                done(true)
            }

            override fun onAdFailed(errorCode: Int) {
                if (loaded) {
                    finishInterstitial()
                } else {
                    Log.w(TAG, "Gecis reklami yuklenemedi: $errorCode")
                    done(false)
                }
            }

            override fun onAdClosed() = finishInterstitial()
        })
        ad.loadAd(AdParam.Builder().build())
    }

    private fun finishInterstitial() {
        val callback = onInterstitialClosed
        onInterstitialClosed = null
        callback?.invoke()
    }

    override fun hasInterstitial() = interstitial?.isLoaded == true

    override fun showInterstitial(activity: Activity, onClosed: () -> Unit): Boolean {
        val ad = interstitial ?: return false
        interstitial = null
        if (!ad.isLoaded) return false
        onInterstitialClosed = onClosed
        ad.show(activity)
        return true
    }

    override fun loadRewarded(context: Context, done: (Boolean) -> Unit) {
        val ad = RewardAd(context, AdConfig.HUAWEI_REWARDED_ID)
        ad.loadAd(AdParam.Builder().build(), object : RewardAdLoadListener() {
            override fun onRewardedLoaded() {
                rewarded = ad
                done(true)
            }

            override fun onRewardAdFailedToLoad(errorCode: Int) {
                Log.w(TAG, "Odullu reklam yuklenemedi: $errorCode")
                done(false)
            }
        })
    }

    override fun hasRewarded() = rewarded?.isLoaded == true

    override fun showRewarded(activity: Activity, onReward: () -> Unit, onClosed: () -> Unit): Boolean {
        val ad = rewarded ?: return false
        rewarded = null
        if (!ad.isLoaded) return false
        ad.show(activity, object : RewardAdStatusListener() {
            override fun onRewarded(reward: Reward) = onReward()
            override fun onRewardAdClosed() = onClosed()
            override fun onRewardAdFailedToShow(errorCode: Int) = onClosed()
        })
        return true
    }

    override fun createBanner(
        activity: Activity,
        widthDp: Int,
        onLoaded: () -> Unit,
        onFailed: () -> Unit
    ): View {
        val banner = BannerView(activity)
        banner.setAdId(AdConfig.HUAWEI_BANNER_ID)
        banner.setBannerAdSize(BannerAdSize.getCurrentDirectionBannerSize(activity, widthDp))
        banner.setBannerRefresh(60L)
        banner.setAdListener(object : AdListener() {
            override fun onAdLoaded() = onLoaded()
            override fun onAdFailed(errorCode: Int) {
                Log.w(TAG, "Banner yuklenemedi: $errorCode")
                onFailed()
            }
        })
        banner.loadAd(AdParam.Builder().build())
        return banner
    }

    override fun pauseBanner(view: View) {
        (view as? BannerView)?.pause()
    }

    override fun resumeBanner(view: View) {
        (view as? BannerView)?.resume()
    }

    override fun destroyBanner(view: View) {
        (view as? BannerView)?.destroy()
    }

    override fun loadNative(activity: Activity, dark: Boolean, done: (NativeAdHandle?) -> Unit): () -> Unit {
        var cancelled = false
        val loader = NativeAdLoader.Builder(activity, AdConfig.HUAWEI_NATIVE_ID)
            .setNativeAdLoadedListener { ad ->
                if (cancelled || activity.isFinishing || activity.isDestroyed) {
                    ad.destroy()
                    return@setNativeAdLoadedListener
                }
                val handle = try {
                    bindNative(activity, ad, dark)
                } catch (t: Throwable) {
                    Log.e(TAG, "Native reklam baglanamadi", t)
                    ad.destroy()
                    null
                }
                done(handle)
            }
            .setAdListener(object : AdListener() {
                override fun onAdFailed(errorCode: Int) {
                    Log.w(TAG, "Native reklam yuklenemedi: $errorCode")
                    if (!cancelled) done(null)
                }
            })
            .setNativeAdOptions(
                NativeAdConfiguration.Builder()
                    .setChoicesPosition(NativeAdConfiguration.ChoicesPosition.TOP_RIGHT)
                    .build()
            )
            .build()
        nativeLoader = loader
        loader.loadAd(AdParam.Builder().build())
        return {
            cancelled = true
            if (nativeLoader === loader) nativeLoader = null
        }
    }

    private fun bindNative(activity: Activity, ad: NativeAd, dark: Boolean): NativeAdHandle {
        val nativeView = LayoutInflater.from(activity)
            .inflate(R.layout.ad_native_huawei, null, false) as NativeView
        val headline = nativeView.findViewById<TextView>(R.id.ad_headline)
        val body = nativeView.findViewById<TextView>(R.id.ad_body)
        val advertiser = nativeView.findViewById<TextView>(R.id.ad_advertiser)
        val icon = nativeView.findViewById<ImageView>(R.id.ad_app_icon)
        val cta = nativeView.findViewById<Button>(R.id.ad_call_to_action)
        val media = nativeView.findViewById<MediaView>(R.id.ad_media)
        nativeView.findViewById<TextView>(R.id.ad_badge)?.text = Lang.get("ad_label")

        headline.text = ad.title
        nativeView.setTitleView(headline)

        nativeView.setMediaView(media)
        media.setImageScaleType(ImageView.ScaleType.CENTER_CROP)
        ad.mediaContent?.let { media.setMediaContent(it) }

        body.text = ad.description.orEmpty()
        body.visibility = if (ad.description.isNullOrBlank()) View.GONE else View.VISIBLE
        nativeView.setDescriptionView(body)

        advertiser.text = ad.adSource.orEmpty()
        nativeView.setAdSourceView(advertiser)

        cta.text = ad.callToAction.orEmpty()
        cta.visibility = if (ad.callToAction.isNullOrBlank()) View.INVISIBLE else View.VISIBLE
        nativeView.setCallToActionView(cta)

        val iconDrawable = ad.icon?.drawable
        icon.setImageDrawable(iconDrawable)
        icon.visibility = if (iconDrawable == null) View.GONE else View.VISIBLE
        if (iconDrawable != null) nativeView.setIconView(icon)

        nativeView.setNativeAd(ad)
        NativeViewStyle.apply(nativeView, dark)

        return object : NativeAdHandle {
            override val view: View = nativeView
            override fun applyTheme(dark: Boolean) = NativeViewStyle.apply(nativeView, dark)
            override fun destroy() {
                runCatching { nativeView.destroy() }
                runCatching { ad.destroy() }
            }
        }
    }

    private companion object {
        const val TAG = "HuaweiAds"
    }
}
