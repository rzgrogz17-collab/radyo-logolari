package com.elmas.sudoku.ads

import android.content.Context
import android.telephony.TelephonyManager
import java.util.Locale

object CountryDetector {

    @Volatile
    private var cached: String? = null

    /** Sırayla mobil şebeke, SIM ve cihaz bölgesi denenir. İki harfli büyük kod döner, bulunamazsa boş. */
    fun country(context: Context): String {
        cached?.let { return it }
        val forced = normalize(AdConfig.TEST_COUNTRY)
        if (forced != null) return forced.also { cached = it }

        val telephony = context.applicationContext
            .getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        val candidates = listOf(
            runCatching { telephony?.networkCountryIso }.getOrNull(),
            runCatching { telephony?.simCountryIso }.getOrNull(),
            runCatching { context.resources.configuration.locales[0]?.country }.getOrNull(),
            Locale.getDefault().country
        )
        val code = candidates.firstNotNullOfOrNull { normalize(it) } ?: ""
        cached = code
        return code
    }

    private fun normalize(raw: String?): String? {
        val code = raw?.trim()?.uppercase(Locale.US) ?: return null
        return code.takeIf { it.length == 2 && it.all { ch -> ch in 'A'..'Z' } }
    }
}
