package com.elmas.sudoku.ads

import android.content.Context
import android.util.AttributeSet
import android.widget.RatingBar
import com.yandex.mobile.ads.nativeads.Rating

/** Yandex native reklamında puan yıldızları. */
class YandexRatingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : RatingBar(context, attrs, android.R.attr.ratingBarStyleSmall), Rating {

    override fun getRating(): Float = super.getRating()

    override fun setRating(rating: Float) {
        super.setRating(rating)
    }
}
