package com.elmas.sudoku.logic

import android.media.AudioManager
import android.media.ToneGenerator

class SoundManager {
    private var toneGen: ToneGenerator? = null
    var isMuted = false

    init {
        try {
            toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
        } catch (e: Exception) {
            toneGen = null
        }
    }

    fun toggleSound(): Boolean {
        isMuted = !isMuted
        return isMuted
    }

    private fun playTone(toneType: Int, duration: Int) {
        if (!isMuted && toneGen != null) {
            try {
                toneGen?.startTone(toneType, duration)
            } catch (e: Exception) {
                // Ses çalınamazsa oyun devam eder.
            }
        }
    }

    fun playClick() { playTone(ToneGenerator.TONE_PROP_BEEP, 50) }
    fun playError() { playTone(ToneGenerator.TONE_SUP_ERROR, 150) }
    fun playSuccess() { playTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 200) }
    fun playPencil() { playTone(ToneGenerator.TONE_PROP_PROMPT, 50) }
    fun playWin() { playTone(ToneGenerator.TONE_DTMF_0, 600) }
    fun playReward() { playTone(ToneGenerator.TONE_DTMF_1, 400) }

    fun release() {
        try {
            toneGen?.release()
        } catch (e: Exception) {
            // Kapatılırken hata önemsiz.
        }
        toneGen = null
    }
}
