package com.elmas.sudoku.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.elmas.sudoku.theme.GoldStar
import com.elmas.sudoku.theme.SudokuPalette
import com.elmas.sudoku.theme.WinGreen
import com.elmas.sudoku.theme.levelColor
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun WinDialog(
    info: WinInfo,
    palette: SudokuPalette,
    onNewGame: (() -> Unit)?,
    onMenu: () -> Unit
) {
    Dialog(
        onDismissRequest = onMenu,
        properties = DialogProperties(dismissOnClickOutside = false)
    ) {
        val appear = remember { Animatable(0.6f) }
        LaunchedEffect(Unit) {
            appear.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 300f))
        }
        WinCard(
            info = info,
            palette = palette,
            onNewGame = onNewGame,
            onMenu = onMenu,
            modifier = Modifier.graphicsLayer {
                scaleX = appear.value
                scaleY = appear.value
            }
        )
    }
}

@Composable
fun WinCard(
    info: WinInfo,
    palette: SudokuPalette,
    onNewGame: (() -> Unit)?,
    onMenu: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(28.dp)
    Box(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(palette.surfaceStrong)
            .border(1.5.dp, Brush.linearGradient(listOf(GoldStar, palette.glow)), shape)
    ) {
        Confetti(Modifier.matchParentSize())
        Column(
            Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier
                    .size(78.dp)
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Color(0xFFFFE066), GoldStar))),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Filled.EmojiEvents,
                    null,
                    tint = Color(0xFF6D4C00),
                    modifier = Modifier.size(44.dp)
                )
            }
            Spacer(Modifier.height(14.dp))
            Text(
                Lang.get("win"),
                style = TextStyle(brush = Brush.linearGradient(listOf(WinGreen, Color(0xFF69F0AE)))),
                fontSize = 30.sp,
                fontWeight = FontWeight.Black
            )
            val level = info.difficulty
            if (level != null) {
                Spacer(Modifier.height(4.dp))
                Text(
                    Lang.get(level.labelKey),
                    color = levelColor(level, palette.dark),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                StatBlock(Icons.Filled.Timer, Lang.get("time"), formatTime(info.seconds), palette)
                if (info.bestSeconds > 0) {
                    StatBlock(Icons.Filled.EmojiEvents, Lang.get("best"), formatTime(info.bestSeconds), palette)
                }
            }
            if (info.newRecord) {
                Spacer(Modifier.height(12.dp))
                Text(
                    Lang.get("new_record"),
                    color = Color(0xFF3E2A00),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Brush.horizontalGradient(listOf(Color(0xFFFFE066), GoldStar)))
                        .padding(horizontal = 14.dp, vertical = 5.dp)
                )
            }
            Spacer(Modifier.height(22.dp))
            if (onNewGame != null) {
                Button(
                    onClick = onNewGame,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = palette.accent)
                ) {
                    Text(Lang.get("new_game"), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(10.dp))
            }
            OutlinedButton(
                onClick = onMenu,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, palette.text.copy(alpha = 0.25f))
            ) {
                Text(Lang.get("menu"), color = palette.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun StatBlock(icon: ImageVector, label: String, value: String, palette: SudokuPalette) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = palette.textDim, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(4.dp))
            Text(label, color = palette.textDim, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(2.dp))
        Text(value, color = palette.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

private class ConfettiPiece(
    val x: Float,
    val speed: Float,
    val sizeDp: Float,
    val phase: Float,
    val spin: Float,
    val color: Color
)

@Composable
private fun Confetti(modifier: Modifier) {
    val pieces = remember {
        val colors = listOf(
            GoldStar,
            WinGreen,
            Color(0xFF2979FF),
            Color(0xFFB388FF),
            Color(0xFFFF4081),
            Color(0xFF00E5FF)
        )
        List(36) {
            ConfettiPiece(
                x = Random.nextFloat(),
                speed = 0.35f + Random.nextFloat() * 0.5f,
                sizeDp = 3f + Random.nextFloat() * 3f,
                phase = Random.nextFloat(),
                spin = Random.nextFloat() * 360f,
                color = colors[it % colors.size]
            )
        }
    }
    val time by rememberInfiniteTransition(label = "confetti").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3_200, easing = LinearEasing)),
        label = "confettiTime"
    )
    Canvas(modifier) {
        val sway = 12.dp.toPx()
        pieces.forEach { p ->
            val progress = (time * p.speed + p.phase) % 1f
            val x = p.x * size.width + sin(progress * 6.28f + p.phase * 6.28f) * sway
            val y = progress * size.height
            val half = p.sizeDp.dp.toPx()
            rotate(p.spin + progress * 360f, Offset(x, y)) {
                drawRect(
                    color = p.color.copy(alpha = 0.55f),
                    topLeft = Offset(x - half, y - half / 2f),
                    size = Size(half * 2f, half)
                )
            }
        }
    }
}
