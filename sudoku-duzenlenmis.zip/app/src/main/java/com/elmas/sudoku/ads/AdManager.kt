package com.elmas.sudoku.ads

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import androidx.compose.runtime.mutableStateOf

enum class AdNetwork { YANDEX, HUAWEI, ADMOB }

/** Yüklenmiş ve görünümü hazırlanmış native reklam. */
interface NativeAdHandle {
    val view: View
    fun applyTheme(dark: Boolean)
    fun destroy()
}

internal interface AdProvider {
    fun initialize(activity: Activity, onReady: () -> Unit)

    fun loadInterstitial(context: Context, done: (Boolean) -> Unit)
    fun hasInterstitial(): Boolean
    fun showInterstitial(activity: Activity, onClosed: () -> Unit): Boolean

    fun loadRewarded(context: Context, done: (Boolean) -> Unit)
    fun hasRewarded(): Boolean
    fun showRewarded(activity: Activity, onReward: () -> Unit, onClosed: () -> Unit): Boolean

    fun createBanner(activity: Activity, widthDp: Int, onLoaded: () -> Unit, onFailed: () -> Unit): View
    fun pauseBanner(view: View) {}
    fun resumeBanner(view: View) {}
    fun destroyBanner(view: View)

    /** Dönen fonksiyon isteği iptal eder. */
    fun loadNative(activity: Activity, dark: Boolean, done: (NativeAdHandle?) -> Unit): () -> Unit
}

/**
 * Reklam ağını seçer ve bütün reklam çağrılarını o ağa yönlendirir.
 * Ağ, uygulama açılırken bir kez seçilir.
 */
object AdManager {

    private const val TAG = "AdManager"
    private const val MAX_RETRY = 6

    private val main = Handler(Looper.getMainLooper())
    private var provider: AdProvider? = null
    private var appContext: Context? = null
    private var started = false

    var network: AdNetwork = AdNetwork.ADMOB
        private set

    /** Reklam SDK'sı hazır olunca true olur. Banner ve native reklam bunu bekler. */
    val ready = mutableStateOf(false)

    /** AdMob gizlilik ayarları düğmesinin gösterilmesi gerekiyorsa true olur. */
    val privacyOptionsRequired = mutableStateOf(false)

    private var interstitialLoading = false
    private var interstitialRetry = 0
    private var rewardedLoading = false
    private var rewardedRetry = 0

    fun initialize(activity: Activity) {
        if (started || !AdConfig.ADS_ENABLED) return
        started = true
        appContext = activity.applicationContext

        val country = CountryDetector.country(activity)
        network = when {
            !AdConfig.USE_YANDEX_AND_HUAWEI -> AdNetwork.ADMOB
            country in AdConfig.YANDEX_COUNTRIES -> AdNetwork.YANDEX
            else -> AdNetwork.HUAWEI
        }
        Log.d(TAG, "Ulke: '$country', reklam agi: $network")

        val selected = when (network) {
            AdNetwork.YANDEX -> YandexAds()
            AdNetwork.HUAWEI -> HuaweiAds()
            AdNetwork.ADMOB -> AdMobAds()
        }
        provider = selected
        try {
            selected.initialize(activity) {
                main.post {
                    ready.value = true
                    loadInterstitial()
                    loadRewarded()
                }
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Reklam SDK baslatilamadi", t)
        }
    }

    internal fun setPrivacyOptionsRequired(required: Boolean) {
        main.post { privacyOptionsRequired.value = required }
    }

    fun showPrivacyOptions(activity: Activity) {
        (provider as? AdMobAds)?.showPrivacyOptions(activity)
    }

    fun loadInterstitial() {
        val p = provider ?: return
        val context = appContext ?: return
        if (!ready.value || interstitialLoading || p.hasInterstitial()) return
        interstitialLoading = true
        try {
            p.loadInterstitial(context) { ok ->
                main.post {
                    interstitialLoading = false
                    if (ok) {
                        interstitialRetry = 0
                    } else {
                        retryLater(interstitialRetry++) { loadInterstitial() }
                    }
                }
            }
        } catch (t: Throwable) {
            interstitialLoading = false
            Log.e(TAG, "Gecis reklami yuklenemedi", t)
        }
    }

    /** Gecis reklami hazirsa gosterir. Hazir degilse sessizce gecer ve yenisini yukler. */
    fun showInterstitial(activity: Activity) {
        val p = provider ?: return
        if (!ready.value) return
        if (!p.hasInterstitial()) {
            interstitialRetry = 0
            loadInterstitial()
            return
        }
        val shown = try {
            p.showInterstitial(activity) { main.post { loadInterstitial() } }
        } catch (t: Throwable) {
            Log.e(TAG, "Gecis reklami gosterilemedi", t)
            false
        }
        if (!shown) loadInterstitial()
    }

    fun loadRewarded() {
        val p = provider ?: return
        val context = appContext ?: return
        if (!ready.value || rewardedLoading || p.hasRewarded()) return
        rewardedLoading = true
        try {
            p.loadRewarded(context) { ok ->
                main.post {
                    rewardedLoading = false
                    if (ok) {
                        rewardedRetry = 0
                    } else {
                        retryLater(rewardedRetry++) { loadRewarded() }
                    }
                }
            }
        } catch (t: Throwable) {
            rewardedLoading = false
            Log.e(TAG, "Odullu reklam yuklenemedi", t)
        }
    }

    /**
     * Ödüllü reklamı gösterir. Kullanıcı ödülü kazanırsa [onReward] bir kez çalışır.
     * Reklam hazır değilse false döner.
     */
    fun showRewarded(activity: Activity, onReward: () -> Unit): Boolean {
        if (!AdConfig.ADS_ENABLED) {
            onReward()
            return true
        }
        val p = provider ?: return false
        if (!ready.value || !p.hasRewarded()) {
            rewardedRetry = 0
            loadRewarded()
            return false
        }
        var granted = false
        val shown = try {
            p.showRewarded(
                activity,
                onReward = {
                    main.post {
                        if (!granted) {
                            granted = true
                            onReward()
                        }
                    }
                },
                onClosed = { main.post { loadRewarded() } }
            )
        } catch (t: Throwable) {
            Log.e(TAG, "Odullu reklam gosterilemedi", t)
            false
        }
        if (!shown) loadRewarded()
        return shown
    }

    fun createBanner(
        activity: Activity,
        widthDp: Int,
        onLoaded: () -> Unit,
        onFailed: () -> Unit
    ): View? {
        val p = provider ?: return null
        if (!ready.value) return null
        return try {
            p.createBanner(activity, widthDp, { main.post(onLoaded) }, { main.post(onFailed) })
        } catch (t: Throwable) {
            Log.e(TAG, "Banner olusturulamadi", t)
            null
        }
    }

    fun pauseBanner(view: View) {
        runCatching { provider?.pauseBanner(view) }
    }

    fun resumeBanner(view: View) {
        runCatching { provider?.resumeBanner(view) }
    }

    fun destroyBanner(view: View) {
        runCatching { provider?.destroyBanner(view) }
    }

    fun loadNative(activity: Activity, dark: Boolean, done: (NativeAdHandle?) -> Unit): () -> Unit {
        val noCancel: () -> Unit = {}
        val p = provider
        if (p == null || !ready.value) {
            done(null)
            return noCancel
        }
        return try {
            p.loadNative(activity, dark) { handle -> main.post { done(handle) } }
        } catch (t: Throwable) {
            Log.e(TAG, "Native reklam yuklenemedi", t)
            done(null)
            noCancel
        }
    }

    private fun retryLater(attempt: Int, action: () -> Unit) {
        if (attempt >= MAX_RETRY) return
        val delayMs = (5_000L shl attempt).coerceAtMost(60_000L)
        main.postDelayed({ action() }, delayMs)
    }
}
