package com.elmas.sudoku.ui

import java.util.Locale

object Lang {
    private val translations = mapOf(
        "en" to mapOf(
            "resume" to "RESUME", "hint" to "HINT", "menu" to "MENU",
            "win" to "YOU WON!", "new_game" to "NEW GAME", "pencil_on" to "NOTE ON",
            "pencil_off" to "NOTE OFF", "diff_easy" to "EASY", "diff_medium" to "MEDIUM",
            "diff_hard" to "HARD", "diff_ultra" to "ULTRA", "undo" to "UNDO", "erase" to "ERASE",
            "loading" to "LOADING...", "ad_not_ready" to "Ad is loading, please wait...",
            "ad_label" to "Ad", "time" to "Time", "best" to "Best", "new_record" to "NEW RECORD!",
            "select_cell" to "Select a cell first", "nothing_to_undo" to "Nothing to undo",
            "reward_earned" to "+3 added", "privacy" to "Privacy settings", "wins" to "Wins",
            "preparing" to "Preparing..."
        ),
        "tr" to mapOf(
            "resume" to "DEVAM ET", "hint" to "İPUCU", "menu" to "MENÜ",
            "win" to "KAZANDIN!", "new_game" to "YENİ OYUN", "pencil_on" to "NOT AÇIK",
            "pencil_off" to "NOT KAPALI", "diff_easy" to "KOLAY", "diff_medium" to "ORTA",
            "diff_hard" to "ZOR", "diff_ultra" to "ULTRA", "undo" to "GERİ AL", "erase" to "SİL",
            "loading" to "YÜKLENİYOR...", "ad_not_ready" to "Reklam yükleniyor, lütfen bekleyin...",
            "ad_label" to "Reklam", "time" to "Süre", "best" to "En iyi", "new_record" to "YENİ REKOR!",
            "select_cell" to "Önce bir kare seç", "nothing_to_undo" to "Geri alınacak hamle yok",
            "reward_earned" to "+3 eklendi", "privacy" to "Gizlilik ayarları", "wins" to "Kazanılan",
            "preparing" to "Hazırlanıyor..."
        ),
        "es" to mapOf(
            "resume" to "CONTINUAR", "hint" to "PISTA", "menu" to "MENÚ",
            "win" to "¡GANASTE!", "new_game" to "NUEVO JUEGO", "pencil_on" to "NOTA ON",
            "pencil_off" to "NOTA OFF", "diff_easy" to "FÁCIL", "diff_medium" to "MEDIO",
            "diff_hard" to "DIFÍCIL", "diff_ultra" to "ULTRA", "undo" to "DESHACER", "erase" to "BORRAR",
            "loading" to "CARGANDO...", "ad_not_ready" to "El anuncio se está cargando...",
            "ad_label" to "Anuncio", "time" to "Tiempo", "best" to "Mejor", "new_record" to "¡NUEVO RÉCORD!",
            "select_cell" to "Primero elige una casilla", "nothing_to_undo" to "Nada que deshacer",
            "reward_earned" to "+3 añadido", "privacy" to "Privacidad", "wins" to "Victorias",
            "preparing" to "Preparando..."
        ),
        "de" to mapOf(
            "resume" to "FORTSETZEN", "hint" to "HINWEIS", "menu" to "MENÜ",
            "win" to "GEWONNEN!", "new_game" to "NEUES SPIEL", "pencil_on" to "NOTIZ AN",
            "pencil_off" to "NOTIZ AUS", "diff_easy" to "EINFACH", "diff_medium" to "MITTEL",
            "diff_hard" to "SCHWER", "diff_ultra" to "ULTRA", "undo" to "ZURÜCK", "erase" to "LÖSCHEN",
            "loading" to "LADEN...", "ad_not_ready" to "Werbung wird geladen...",
            "ad_label" to "Anzeige", "time" to "Zeit", "best" to "Bestzeit", "new_record" to "NEUER REKORD!",
            "select_cell" to "Wähle zuerst ein Feld", "nothing_to_undo" to "Nichts rückgängig zu machen",
            "reward_earned" to "+3 hinzugefügt", "privacy" to "Datenschutz", "wins" to "Siege",
            "preparing" to "Wird vorbereitet..."
        ),
        "fr" to mapOf(
            "resume" to "REPRENDRE", "hint" to "INDICE", "menu" to "MENU",
            "win" to "GAGNÉ!", "new_game" to "NOUVEAU", "pencil_on" to "NOTE ON",
            "pencil_off" to "NOTE OFF", "diff_easy" to "FACILE", "diff_medium" to "MOYEN",
            "diff_hard" to "DIFFICILE", "diff_ultra" to "ULTRA", "undo" to "ANNULER", "erase" to "EFFACER",
            "loading" to "CHARGEMENT...", "ad_not_ready" to "Chargement de la publicité...",
            "ad_label" to "Annonce", "time" to "Temps", "best" to "Record", "new_record" to "NOUVEAU RECORD !",
            "select_cell" to "Choisissez d'abord une case", "nothing_to_undo" to "Rien à annuler",
            "reward_earned" to "+3 ajouté", "privacy" to "Confidentialité", "wins" to "Victoires",
            "preparing" to "Préparation..."
        ),
        "ru" to mapOf(
            "resume" to "ПРОДОЛЖИТЬ", "hint" to "ПОДСКАЗКА", "menu" to "МЕНЮ",
            "win" to "ПОБЕДА!", "new_game" to "НОВАЯ ИГРА", "pencil_on" to "ЗАМЕТКИ ВКЛ",
            "pencil_off" to "ЗАМЕТКИ ВЫКЛ", "diff_easy" to "ЛЕГКО", "diff_medium" to "СРЕДНЕ",
            "diff_hard" to "СЛОЖНО", "diff_ultra" to "УЛЬТРА", "undo" to "НАЗАД", "erase" to "СТЕРЕТЬ",
            "loading" to "ЗАГРУЗКА...", "ad_not_ready" to "Реклама загружается, ждите...",
            "ad_label" to "Реклама", "time" to "Время", "best" to "Рекорд", "new_record" to "НОВЫЙ РЕКОРД!",
            "select_cell" to "Сначала выберите клетку", "nothing_to_undo" to "Нечего отменять",
            "reward_earned" to "+3 добавлено", "privacy" to "Конфиденциальность", "wins" to "Победы",
            "preparing" to "Подготовка..."
        ),
        "zh" to mapOf(
            "resume" to "继续", "hint" to "提示", "menu" to "菜单",
            "win" to "你赢了!", "new_game" to "新游戏", "pencil_on" to "笔记开",
            "pencil_off" to "笔记关", "diff_easy" to "简单", "diff_medium" to "中等",
            "diff_hard" to "困难", "diff_ultra" to "极端", "undo" to "撤销", "erase" to "擦除",
            "loading" to "加载中...", "ad_not_ready" to "广告正在加载，请稍候...",
            "ad_label" to "广告", "time" to "时间", "best" to "最佳", "new_record" to "新纪录！",
            "select_cell" to "请先选择一个格子", "nothing_to_undo" to "没有可撤销的操作",
            "reward_earned" to "已增加 +3", "privacy" to "隐私设置", "wins" to "胜利",
            "preparing" to "准备中..."
        ),
        "ar" to mapOf(
            "resume" to "استأنف", "hint" to "تلميح", "menu" to "قائمة",
            "win" to "فزت!", "new_game" to "لعبة جديدة", "pencil_on" to "ملاحظة",
            "pencil_off" to "بدون ملاحظة", "diff_easy" to "سهل", "diff_medium" to "متوسط",
            "diff_hard" to "صعب", "diff_ultra" to "الترا", "undo" to "تراجع", "erase" to "مسح",
            "loading" to "جار التحميل...", "ad_not_ready" to "جاري تحميل الإعلان...",
            "ad_label" to "إعلان", "time" to "الوقت", "best" to "الأفضل", "new_record" to "رقم قياسي جديد!",
            "select_cell" to "اختر خانة أولاً", "nothing_to_undo" to "لا شيء للتراجع",
            "reward_earned" to "تمت إضافة +3", "privacy" to "إعدادات الخصوصية", "wins" to "انتصارات",
            "preparing" to "جار التحضير..."
        ),
        "hi" to mapOf(
            "resume" to "फिर से शुरू", "hint" to "संकेत", "menu" to "मेन्यू",
            "win" to "जीत!", "new_game" to "नया खेल", "pencil_on" to "नोट चालू",
            "pencil_off" to "नोट बंद", "diff_easy" to "आसान", "diff_medium" to "मध्यम",
            "diff_hard" to "मुश्किल", "diff_ultra" to "अल्ट्रा", "undo" to "पूर्ववत", "erase" to "मिटाएँ",
            "loading" to "लोड हो रहा है...", "ad_not_ready" to "विज्ञापन लोड हो रहा है...",
            "ad_label" to "विज्ञापन", "time" to "समय", "best" to "सर्वश्रेष्ठ", "new_record" to "नया रिकॉर्ड!",
            "select_cell" to "पहले एक खाना चुनें", "nothing_to_undo" to "पूर्ववत करने को कुछ नहीं",
            "reward_earned" to "+3 जोड़े गए", "privacy" to "गोपनीयता सेटिंग", "wins" to "जीत",
            "preparing" to "तैयारी हो रही है..."
        )
    )

    fun get(key: String): String {
        val langCode = Locale.getDefault().language
        return translations[langCode]?.get(key) ?: translations["en"]?.get(key) ?: key
    }

    /** Türkçede yüzde işareti sayının önüne gelir. */
    fun percent(value: Int): String =
        if (Locale.getDefault().language == "tr") "%$value" else "$value%"
}
