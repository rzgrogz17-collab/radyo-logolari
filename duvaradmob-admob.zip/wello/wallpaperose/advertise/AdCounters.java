package com.wello.wallpaperose.advertise;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;

import com.wello.wallpaperose.AppConfig;
import com.wello.wallpaperose.activity.ActivitySplash;

/**
 * Gecis reklami: ekrana her donuste sayac 1 artar, 10. donuste acilir.
 * Favori kalbi ayri sayactir, 3. basista acilir. Kalp islemi reklamdan once yapilir.
 */
public final class AdCounters {

    private static int screenReturns = 0;
    private static int favoriteTaps = 0;
    private static boolean skipNextResume = false;
    private static boolean showPending = false;
    private static Activity bound;
    private static AdNetworkHelper helper;
    private static final Handler handler = new Handler(Looper.getMainLooper());

    private AdCounters() {}

    public static void onScreenResumed(Activity activity) {
        if (activity == null || activity instanceof ActivitySplash) return;
        if (skipNextResume) {
            skipNextResume = false;
            bind(activity);
            return;
        }
        bind(activity);
        if (screenReturns < 10) screenReturns++;
        if (screenReturns >= 10) requestShow(activity, true);
    }

    public static void onFavoriteTap(Activity activity) {
        if (activity == null) return;
        bind(activity);
        if (favoriteTaps < 3) favoriteTaps++;
        if (favoriteTaps >= 3) requestShow(activity, false);
    }

    /** onResume icinde hemen acilirsa AdMob siyah ekran basar. Odak geldikten sonra gosterilir. */
    private static void requestShow(Activity activity, boolean fromScreen) {
        if (showPending || activity == null) return;
        showPending = true;
        attemptShow(activity, fromScreen, 0);
    }

    private static void attemptShow(Activity activity, boolean fromScreen, int attempt) {
        if (activity.isFinishing() || activity.isDestroyed()) {
            showPending = false;
            return;
        }
        handler.postDelayed(() -> {
            if (activity.isFinishing() || activity.isDestroyed()) {
                showPending = false;
                return;
            }
            if (!activity.hasWindowFocus() && attempt < 8) {
                attemptShow(activity, fromScreen, attempt + 1);
                return;
            }
            showPending = false;
            if (!activity.hasWindowFocus() || helper == null || bound != activity) return;
            if (helper.showInterstitialAd(AppConfig.ads.ad_main_interstitial)) {
                if (fromScreen) screenReturns = 0;
                else favoriteTaps = 0;
                skipNextResume = true;
            }
        }, attempt == 0 ? 350 : 200);
    }

    private static void bind(Activity activity) {
        if (activity == bound && helper != null) return;
        bound = activity;
        helper = new AdNetworkHelper(activity);
        helper.updateConsentStatus();
        helper.loadInterstitialAd(AppConfig.ads.ad_main_interstitial);
    }
}
