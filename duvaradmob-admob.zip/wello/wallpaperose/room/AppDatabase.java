package com.wello.wallpaperose.room;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.wello.wallpaperose.R;
import com.wello.wallpaperose.room.table.EntityCategory;
import com.wello.wallpaperose.room.table.EntityListing;
import com.wello.wallpaperose.room.table.NotificationEntity;


@Database(entities = {EntityListing.class, NotificationEntity.class, EntityCategory.class}, version = 3, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    public abstract DAO get();

    private static AppDatabase INSTANCE;

    public static AppDatabase getDb(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context, AppDatabase.class, context.getString(R.string.app_name) + "_database")
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return INSTANCE;
    }

    public static void destroyInstance() {
        INSTANCE = null;
    }
}