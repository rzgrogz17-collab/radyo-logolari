package com.wello.wallpaperose.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.ProductDetails.SubscriptionOfferDetails;
import com.wello.wallpaperose.AppConfig;
import com.wello.wallpaperose.R;
import com.wello.wallpaperose.databinding.ActivityBillingBinding;
import com.wello.wallpaperose.utils.BillingHelper;
import com.wello.wallpaperose.utils.GlassDialog;

import java.util.List;

public class ActivityBilling extends AppCompatActivity {

    private ActivityBillingBinding binding;
    private BillingHelper billingHelper;
    private boolean premium;
    private List<ProductDetails> productDetailsList;

    // activity transition
    public static void navigate(Activity activity) {
        Intent i = new Intent(activity, ActivityBilling.class);
        activity.startActivity(i);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityBillingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        initToolbar();

        binding.btSubscriptionWeekly.setVisibility(View.GONE);
        binding.btSubscriptionMonthly.setVisibility(View.GONE);
        binding.btSubscriptionYearly.setVisibility(View.GONE);

        initComponent();
    }

    private void initToolbar() {
        setSupportActionBar(binding.toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle(null);
    }

    private void initComponent(){
        Log.d("BillingHelper", "initComponent");
        binding.btBack.setOnClickListener(v -> finish());

        showLoading(getResources().getString(R.string.please_wait));
        billingHelper = new BillingHelper(this);
        billingHelper.initAndConnect();
        showLoading(getResources().getString(R.string.checking_purchase));
        billingHelper.setResponseListener(new BillingHelper.ResponseListener() {
            @Override
            public void onLoaded(List<ProductDetails> products, boolean purchased, String currentPurchase) {
                showLoading(null);
                productDetailsList = products;
                if (purchased) {
                    premium = true;
                    updatePlanStatus();
                }
                if (!productDetailsList.isEmpty()) {
                    setButtonSubscribe(products);
                }
            }

            @Override
            public void onFailed(String message) {
                GlassDialog.show(new AlertDialog.Builder(ActivityBilling.this)
                    .setTitle(R.string.failed)
                    .setPositiveButton(R.string.RETRY, (dialog, which) -> {
                        initComponent();
                    }).create());
            }

            @Override
            public void onReload(boolean success) {
                initComponent();
                if(success) ActivitySplash.restart(ActivityBilling.this);
            }
        });
    }

    private void setButtonSubscribe(List<ProductDetails> products){
        binding.subscribeLyt.postDelayed(() -> {
            ProductDetails product = products.get(0);
            if(product == null || product.getSubscriptionOfferDetails() == null){
                return;
            }
            boolean haveWeekly = false, haveMonthly = false, haveYearly = false;
            List<SubscriptionOfferDetails> offerDetails = product.getSubscriptionOfferDetails();
            Log.d("BillingHelper", "SubscriptionOfferDetails : " + offerDetails.size());
            for (SubscriptionOfferDetails offer : offerDetails) {
                ProductDetails.PricingPhases pricingPhases = offer.getPricingPhases();
                ProductDetails.PricingPhase pricing = pricingPhases.getPricingPhaseList().get(0);
                String text = pricing.getFormattedPrice() + " " + BillingHelper.convertDuration(pricing.getBillingPeriod());
                Log.d("BillingHelper", "getBillingPeriod : " + pricing.getBillingPeriod());
                if(pricing.getBillingPeriod().equals("P1W")){
                    haveWeekly = true;
                    binding.btSubscriptionWeekly.setText(text);
                    binding.btSubscriptionWeekly.setOnClickListener(view -> {
                        billingHelper.launchPurchase(product, offer.getOfferToken());
                    });
                }
                if(pricing.getBillingPeriod().equals("P1M")){
                    haveMonthly = true;
                    binding.btSubscriptionMonthly.setText(text);
                    binding.btSubscriptionMonthly.setOnClickListener(view -> {
                        billingHelper.launchPurchase(product, offer.getOfferToken());
                    });
                }
                if(pricing.getBillingPeriod().equals("P1Y")){
                    haveYearly = true;
                    binding.btSubscriptionYearly.setText(text);
                    binding.btSubscriptionYearly.setOnClickListener(view -> {
                        billingHelper.launchPurchase(product, offer.getOfferToken());
                    });
                }
            }

            Log.d("BillingHelper", "haveWeekly : " + haveWeekly);
            Log.d("BillingHelper", "haveMonthly : " + haveMonthly);
            Log.d("BillingHelper", "haveYearly : " + haveYearly);
            binding.btSubscriptionWeekly.setVisibility(AppConfig.billing.billing_weekly_enable && haveWeekly ? View.VISIBLE : View.GONE);
            binding.btSubscriptionMonthly.setVisibility(AppConfig.billing.billing_monthly_enable && haveMonthly ? View.VISIBLE : View.GONE);
            binding.btSubscriptionYearly.setVisibility(AppConfig.billing.billing_yearly_enable && haveYearly ? View.VISIBLE : View.GONE);
        }, 500);
    }

    private void updatePlanStatus(){
        binding.getRoot().postDelayed(() -> {
            if(premium) {
                binding.icon.setVisibility(View.VISIBLE);
                binding.upgradeTitle.setText(R.string.upgrade_title_premium);
                binding.upgradeMessage.setText(R.string.upgrade_message_premium);
                binding.currentPlan.setText(R.string.PREMIUM);
                binding.cardPremium.setCardBackgroundColor(getResources().getColor(R.color.premium));
            } else {
                binding.icon.setVisibility(View.GONE);
                binding.upgradeTitle.setText(R.string.upgrade_title);
                binding.upgradeMessage.setText(R.string.upgrade_message);
                binding.currentPlan.setText(R.string.FREE);
                binding.cardPremium.setCardBackgroundColor(getResources().getColor(R.color.free));
            }

        }, 500);
    }

    private void showLoading(String message) {
        new Handler(getMainLooper()).postDelayed(() -> {
            if (!TextUtils.isEmpty(message)) {
                binding.progressLoading.setVisibility(View.VISIBLE);
                binding.message.setText(message);
                binding.nestedScroll.setVisibility(View.INVISIBLE);
            } else {
                binding.progressLoading.setVisibility(View.INVISIBLE);
                binding.message.setText("");
                binding.nestedScroll.setVisibility(View.VISIBLE);
            }
        }, 500);

    }
}