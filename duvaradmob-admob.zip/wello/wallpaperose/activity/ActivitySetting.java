package com.wello.wallpaperose.activity;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.graphics.drawable.Drawable;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.wello.wallpaperose.AppConfig;
import com.wello.wallpaperose.R;
import com.wello.wallpaperose.data.ThisApp;
import com.wello.wallpaperose.databinding.ActivitySettingBinding;
import com.wello.wallpaperose.room.DAO;
import com.wello.wallpaperose.utils.GlassDialog;
import com.wello.wallpaperose.utils.Tools;
import com.google.android.material.snackbar.Snackbar;

import java.util.Locale;

public class ActivitySetting extends AppCompatActivity {

    public static void navigate(Activity activity) {
        Intent i = new Intent(activity, ActivitySetting.class);
        activity.startActivity(i);
    }

    public ActivitySettingBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initToolbar();
        initComponent();
        validateTheme();
        validateAutoWallpaper();
        Tools.RTLMode(getWindow());
    }

    private void initToolbar() {
        binding.toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        binding.toolbar.getNavigationIcon().setColorFilter(
                getResources().getColor(R.color.toolbarIconText), PorterDuff.Mode.SRC_ATOP);
        setSupportActionBar(binding.toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeButtonEnabled(true);
            actionBar.setTitle(R.string.activity_title_setting);
        }
    }

    private void initComponent() {
        String cacheSize = Tools.getImageCacheSize(this);
        String subTitle = String.format(Locale.getDefault(),
                getString(R.string.setting_subtitle_cache), cacheSize);
        binding.subtitleCache.setText(subTitle);

        binding.actionCache.setOnClickListener(v -> showDialogClearCache());
        binding.actionSwitchTheme.setOnClickListener(view -> dialogThemeConfirmation());
        binding.actionTheme.setOnClickListener(view -> dialogThemeConfirmation());
        binding.actionAutoWallpaper.setOnClickListener(view -> dialogAutoWallpaper());
        binding.actionSwitchAutoWallpaper.setOnClickListener(view -> dialogAutoWallpaper());
        binding.actionNotification.setOnClickListener(view -> ActivityNotification.navigate(this));
        binding.actionNotificationSetting.setOnClickListener(
                view -> Tools.goToNotificationSettings(this));
        binding.actionRemoveAds.setOnClickListener(view ->
                Toast.makeText(this, "Premium Page", Toast.LENGTH_SHORT).show());
        binding.actionRemoveAds.setVisibility(
                AppConfig.billing.billing_enable ? View.VISIBLE : View.GONE);
        binding.actionPrivacy.setOnClickListener(view ->
                Tools.directLinkCustomTab(this, AppConfig.general.privacy_policy_url));
        binding.actionMoreApp.setOnClickListener(view ->
                Tools.directLinkCustomTab(this, AppConfig.general.more_apps_url));
        binding.actionRate.setOnClickListener(view -> showDialogRateApp());
        binding.actionAboutApp.setOnClickListener(view -> showDialogAbout());
    }

    // Açık / Koyu / Otomatik (saate göre) — anahtar her zaman ŞU AN aktif
    // olan görünümü yansıtır (otomatik moddayken de doğru gösterir).
    private void validateTheme() {
        int nightModeFlags = getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK;
        boolean isNight = nightModeFlags == Configuration.UI_MODE_NIGHT_YES;
        binding.actionSwitchTheme.setImageResource(
                isNight ? R.drawable.ic_toggle_on : R.drawable.ic_toggle_off);
    }

    // YENİ: Otomatik Duvar Kağıdı Değiştirici anahtarı + alt yazısı,
    // şu anki kayıtlı tercihe göre güncellenir.
    private void validateAutoWallpaper() {
        boolean enabled = ThisApp.pref().isAutoWallpaperEnabled();
        binding.actionSwitchAutoWallpaper.setImageResource(
                enabled ? R.drawable.ic_toggle_on : R.drawable.ic_toggle_off);
        if (!enabled) {
            binding.subtitleAutoWallpaper.setText(getString(R.string.setting_subtitle_auto_wallpaper_off));
        } else {
            boolean weekly = ThisApp.pref().isAutoWallpaperWeekly();
            binding.subtitleAutoWallpaper.setText(weekly
                    ? getString(R.string.setting_subtitle_auto_wallpaper_on_weekly)
                    : getString(R.string.setting_subtitle_auto_wallpaper_on_daily));
        }
    }

    // ── Otomatik Duvar Kağıdı Değiştirici: Kapalı / Günlük / Haftalık ────────

    public void dialogAutoWallpaper() {
        String[] labels = {
                getString(R.string.auto_wallpaper_off),
                getString(R.string.auto_wallpaper_daily),
                getString(R.string.auto_wallpaper_weekly)
        };

        // 0 = Kapalı, 1 = Günlük, 2 = Haftalık
        int checkedIndex;
        if (!ThisApp.pref().isAutoWallpaperEnabled()) {
            checkedIndex = 0;
        } else {
            checkedIndex = ThisApp.pref().isAutoWallpaperWeekly() ? 2 : 1;
        }
        final int[] selectedIndex = {checkedIndex};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.auto_wallpaper_dialog_title);
        builder.setSingleChoiceItems(labels, checkedIndex,
                (dialog, which) -> selectedIndex[0] = which);
        builder.setPositiveButton(R.string.CONTINUE, (di, i) -> {
            di.dismiss();
            int choice = selectedIndex[0];
            if (choice == 0) {
                ThisApp.pref().setAutoWallpaperEnabled(false);
                Tools.cancelAutoWallpaper(this);
            } else {
                boolean weekly = (choice == 2);
                if (ThisApp.dao().getListingCount() == 0) {
                    Toast.makeText(this, R.string.auto_wallpaper_need_favorites, Toast.LENGTH_LONG).show();
                }
                ThisApp.pref().setAutoWallpaperEnabled(true);
                ThisApp.pref().setAutoWallpaperWeekly(weekly);
                Tools.scheduleAutoWallpaper(this, weekly);
            }
            validateAutoWallpaper();
        });
        builder.setNegativeButton(R.string.CANCEL, null);

        AlertDialog dialog = builder.create();
        customizeAndShowDialog(dialog);
        styleChoiceRows(dialog);
    }

    // ── Tema değiştirme: Açık / Koyu / Otomatik (saate göre) ─────────────────

    public void dialogThemeConfirmation() {
        String[] themeLabels = {
                getString(R.string.theme_light),
                getString(R.string.theme_dark),
                getString(R.string.theme_auto)
        };

        // 0 = Açık, 1 = Koyu, 2 = Otomatik
        int checkedIndex = ThisApp.pref().isAutoTheme()
                ? 2
                : (ThisApp.pref().isDarkTheme() ? 1 : 0);
        final int[] selectedIndex = {checkedIndex};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.change_theme_title);
        builder.setSingleChoiceItems(themeLabels, checkedIndex,
                (dialog, which) -> selectedIndex[0] = which);
        builder.setPositiveButton(R.string.CONTINUE, (di, i) -> {
            di.dismiss();
            int choice = selectedIndex[0];
            boolean wasAuto = ThisApp.pref().isAutoTheme();

            if (choice == 2) {
                // Otomatik seçildi: bundan sonra cihazın saatine göre kendisi karar verir
                if (!wasAuto) {
                    ThisApp.pref().setAutoTheme(true);
                    Tools.applyAutoOrManualTheme();
                    validateTheme();
                    Tools.restartApp(ActivitySetting.this);
                }
            } else {
                boolean newDark = (choice == 1);
                if (wasAuto || newDark != ThisApp.pref().isDarkTheme()) {
                    ThisApp.pref().setAutoTheme(false);
                    ThisApp.pref().setDarkTheme(newDark);
                    Tools.applyTheme(newDark);
                    validateTheme();
                    Tools.restartApp(ActivitySetting.this);
                }
            }
        });
        builder.setNegativeButton(R.string.CANCEL, null);

        AlertDialog dialog = builder.create();
        customizeAndShowDialog(dialog);
        styleChoiceRows(dialog);
    }

    private void styleChoiceRows(AlertDialog dialog) {
        int titleWhite = Color.WHITE;
        int optionWhite = Color.parseColor("#D5D5D5");
        int bone = Color.parseColor("#F3EDE2");
        int titleId = getResources().getIdentifier("alertTitle", "id", "android");
        TextView titleView = titleId > 0 ? dialog.findViewById(titleId) : null;
        if (titleView == null) {
            titleId = getResources().getIdentifier("alertTitle", "id", getPackageName());
            if (titleId > 0) titleView = dialog.findViewById(titleId);
        }
        if (titleView != null) {
            titleView.setTextColor(titleWhite);
            titleView.setTypeface(null, Typeface.BOLD);
        }
        ListView list = dialog.getListView();
        if (list == null) return;
        list.setDivider(null);
        Runnable paint = () -> {
            for (int i = 0; i < list.getChildCount(); i++) {
                paintChoice(list.getChildAt(i), optionWhite, bone);
            }
        };
        list.setOnHierarchyChangeListener(new android.view.ViewGroup.OnHierarchyChangeListener() {
            @Override public void onChildViewAdded(View parent, View child) {
                paintChoice(child, optionWhite, bone);
            }
            @Override public void onChildViewRemoved(View parent, View child) {}
        });
        paint.run();
        list.post(paint);
    }

    private void paintChoice(View child, int textColor, int bone) {
        if (!(child instanceof CheckedTextView)) return;
        CheckedTextView row = (CheckedTextView) child;
        row.setTextColor(textColor);
        row.setCheckMarkDrawable(null);
        Drawable radio = ContextCompat.getDrawable(row.getContext(), R.drawable.radio_choice_bone);
        if (radio != null) radio = radio.mutate();
        int pad = Math.round(12 * row.getResources().getDisplayMetrics().density);
        row.setCompoundDrawablePadding(pad);
        row.setCompoundDrawablesRelativeWithIntrinsicBounds(radio, null, null, null);
    }

    // ── Pop-up'lar ────────────────────────────────────────────────────────────

    private void showDialogClearCache() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.dialog_confirm_title));
        builder.setMessage(getString(R.string.message_clear_image_cache));
        builder.setPositiveButton(R.string.YES, (dialogInterface, i) -> {
            Tools.clearImageCacheOnBackground(getApplicationContext());
            String zeroBytes = String.format(Locale.getDefault(),
                    getString(R.string.setting_subtitle_cache), "0 Bytes");
            binding.subtitleCache.setText(zeroBytes);
            Snackbar.make(binding.getRoot(),
                    getString(R.string.message_after_clear_image_cache),
                    Snackbar.LENGTH_SHORT).show();
        });
        builder.setNegativeButton(R.string.CANCEL, null);
        customizeAndShowDialog(builder.create());
    }

    private void showDialogRateApp() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.setting_title_rate_app);
        builder.setMessage("Would you like to support us by rating 5 stars? ⭐");
        builder.setPositiveButton("RATE US", (dialog, which) -> openMarket());
        builder.setNegativeButton(R.string.CANCEL, null);
        customizeAndShowDialog(builder.create());
    }

    private void showDialogAbout() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.setting_title_about));
        String versionName;
        try {
            versionName = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) { versionName = "1.0"; }
        builder.setMessage("Version: " + versionName + "\n\n" + getString(R.string.about_text));
        builder.setPositiveButton("OK", null);
        customizeAndShowDialog(builder.create());
    }

    private void openMarket() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=" + getPackageName())));
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
        }
    }

    // ── Ortak şık dialog stili ────────────────────────────────────────────────

    private void customizeAndShowDialog(AlertDialog dialog) {
        dialog.show();
        GlassDialog.apply(dialog);
        if (true) return;
        int nightModeFlags = getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK;
        boolean isNight = nightModeFlags == Configuration.UI_MODE_NIGHT_YES;

        if (dialog.getWindow() != null) {
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(60f);
            bg.setColor(isNight ? Color.parseColor("#1B2530") : Color.parseColor("#FDFBF7"));
            bg.setStroke(2, isNight ? Color.parseColor("#2C3D4F") : Color.parseColor("#E0E0E0"));
            dialog.getWindow().setBackgroundDrawable(bg);
            try {
                int screenW = getResources().getDisplayMetrics().widthPixels;
                int targetW = (int) Math.min(screenW * 0.86f,
                        getResources().getDisplayMetrics().density * 340);
                dialog.getWindow().setLayout(targetW,
                        android.view.WindowManager.LayoutParams.WRAP_CONTENT);
            } catch (Exception ignored) {}
        }

        int textColor = isNight ? Color.WHITE : Color.parseColor("#222222");
        int subColor  = isNight ? Color.parseColor("#C2CED5") : Color.parseColor("#555555");
        int posColor  = isNight ? Color.parseColor("#00E5FF") : Color.parseColor("#00838F");
        int negColor  = isNight ? Color.parseColor("#FF4081") : Color.parseColor("#C2185B");

        int titleId = getResources().getIdentifier("alertTitle", "id", "android");
        if (titleId > 0) {
            TextView titleView = dialog.findViewById(titleId);
            if (titleView != null) {
                titleView.setTextColor(textColor);
                titleView.setTextSize(17f);
                titleView.setTypeface(null, Typeface.BOLD);
            }
        }
        TextView messageView = dialog.findViewById(android.R.id.message);
        if (messageView != null) {
            messageView.setTextColor(subColor);
            messageView.setTextSize(15f);
            messageView.setLineSpacing(0f, 1.15f);
        }
        Button btnPos = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        Button btnNeg = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        if (btnPos != null) { btnPos.setTextColor(posColor); btnPos.setTypeface(null, Typeface.BOLD); btnPos.setAllCaps(false); }
        if (btnNeg != null) { btnNeg.setTextColor(negColor); btnNeg.setTypeface(null, Typeface.BOLD); btnNeg.setAllCaps(false); }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (binding.notifCount != null) {
            DAO dao = ThisApp.dao();
            binding.notifCount.setText(dao.getNotificationCount() + "");
            int notifCount = ThisApp.dao().getNotificationUnreadCount();
            binding.read.setVisibility(notifCount > 0 ? View.VISIBLE : View.INVISIBLE);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) finish();
        return super.onOptionsItemSelected(item);
    }
}
