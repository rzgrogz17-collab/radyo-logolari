package com.wello.wallpaperose.activity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayoutMediator;
import com.wello.wallpaperose.AppConfig;
import com.wello.wallpaperose.R;
import com.wello.wallpaperose.advertise.AdNetworkHelper;
import com.wello.wallpaperose.data.ThisApp;
import com.wello.wallpaperose.databinding.ActivityMainBinding;
import com.wello.wallpaperose.fragment.FragmentFavoriteList;
import com.wello.wallpaperose.fragment.FragmentWallpaper;
import com.wello.wallpaperose.utils.PermissionUtil;
import com.wello.wallpaperose.utils.Tools;

public class ActivityMain extends AppCompatActivity {

    // YENİ: Artık gizle/göster (FragmentManager) yerine ViewPager2 ile
    // Ana Sayfa <-> Favoriler arasında parmakla kaydırarak geçiliyor.
    private static final int PAGE_HOME = 0;
    private static final int PAGE_FAVORITES = 1;

    private ActivityMainBinding binding;
    private AdNetworkHelper adNetworkHelper;

    // YENİ: Ana Sayfa/Favoriler listesi kaydırılırken üstteki toolbar'ı
    // gizleyip gösterebilmek için mevcut durumu takip eder.
    private boolean toolbarExpanded = true;
    private static final int TOOLBAR_SCROLL_THRESHOLD = 6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        initComponent();

        prepareAds();

        Tools.checkNotification(this);
        PermissionUtil.checkAndRequestNotification(this);
        Tools.RTLMode(getWindow());
    }

    private void initComponent() {
        setSupportActionBar(binding.toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) actionBar.setTitle(null);
        Tools.changeOverflowMenuIconColor(binding.toolbar, Color.WHITE);

        binding.viewPagerMain.setAdapter(new MainPagerAdapter(this));
        // Her iki sayfayı da (Ana Sayfa + Favoriler) canlı tutar,
        // aralarında kaydırırken yeniden yükleme olmadan akıcı geçiş sağlar.
        binding.viewPagerMain.setOffscreenPageLimit(1);

        // YENİ: Favoriler/Ana Sayfa listesini dikey kaydırırken parmak hafifçe
        // çapraz hareket ettiğinde, ViewPager2'nin varsayılan "gerilme" (stretch)
        // kenar efekti yanlışlıkla tetiklenip ekran sağa/sola esniyormuş gibi
        // görünüyordu. ViewPager2'nin iç RecyclerView'ında bu efekti kapatıyoruz.
        View innerRecyclerView = binding.viewPagerMain.getChildAt(0);
        if (innerRecyclerView instanceof RecyclerView) {
            innerRecyclerView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        }

        new TabLayoutMediator(binding.tabLayoutMain, binding.viewPagerMain, (tab, position) -> {
            tab.setText(position == PAGE_HOME
                    ? getString(R.string.tab_home)
                    : getString(R.string.tab_favorites));
        }).attach();

        binding.title.setText(getString(R.string.menu_wallpapers));

        binding.viewPagerMain.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                binding.title.setText(position == PAGE_HOME
                        ? getString(R.string.menu_wallpapers)
                        : getString(R.string.menu_favorite));
                setToolbarExpanded(true);
            }
        });
    }

    // YENİ: Ana Sayfa/Favoriler listesindeki RecyclerView'dan (AdapterListing
    // üzerinden) gelen kaydırma bildirimi. ViewPager2 içindeki bir listenin
    // dokunma/kaydırma olayları CoordinatorLayout'a doğal yoldan iletilmediği
    // için (ViewPager2'nin bilinen bir kısıtı) toolbar'ın otomatik
    // gizlenmesi/gösterilmesi çalışmıyordu. Bunun yerine AppBarLayout,
    // scroll flag'lerine (Toolbar = scroll|enterAlways, TabLayout = pinned)
    // uygun şekilde elle genişletilip daraltılıyor: sekme çubuğu (TabLayout)
    // her zaman yerinde sabit kalırken sadece üstteki toolbar gizlenip
    // gösteriliyor.
    public void handleListScroll(int dy, boolean atTop) {
        if (binding == null) return;
        if (atTop) {
            setToolbarExpanded(true);
        } else if (dy > TOOLBAR_SCROLL_THRESHOLD) {
            setToolbarExpanded(false);
        } else if (dy < -TOOLBAR_SCROLL_THRESHOLD) {
            setToolbarExpanded(true);
        }
    }

    private void setToolbarExpanded(boolean expand) {
        if (binding == null || toolbarExpanded == expand) return;
        toolbarExpanded = expand;
        binding.appbarLayout.setExpanded(expand, true);
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        if (binding.viewPagerMain.getCurrentItem() != PAGE_HOME) {
            binding.viewPagerMain.setCurrentItem(PAGE_HOME, true);
        } else {
            showDialogExit();
        }
    }

    private void showDialogExit() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_exit);
        if (dialog.getWindow() != null)
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCancelable(true);

        Button btnRate = dialog.findViewById(R.id.btn_rate);
        Button btnExit = dialog.findViewById(R.id.btn_exit);
        Button btnCancel = dialog.findViewById(R.id.btn_cancel);

        if (btnRate != null) btnRate.setOnClickListener(v -> {
            dialog.dismiss();
            openMarket();
        });
        if (btnExit != null) btnExit.setOnClickListener(v -> {
            dialog.dismiss();
            finishAffinity();
        });
        if (btnCancel != null) btnCancel.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    private void openMarket() {
        try {
            Tools.rateAction(this);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("market://details?id=" + getPackageName())));
            } catch (android.content.ActivityNotFoundException anfe) {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
            }
        }
    }

    static boolean active = false;

    @Override
    public void onStart() {
        super.onStart();
        active = true;
        // YENİ: Uygulama açık kalıp saat 07:30/18:30 eşiğini geçerse veya
        // arka plandan öne dönülürse, "Otomatik" tema modu güncel kalsın diye
        // burada da tekrar kontrol edilir (önceden sadece soğuk açılışta kontrol
        // ediliyordu — bu yüzden "gündüz ama hâlâ gece modunda" görünebiliyordu).
        if (ThisApp.pref().isAutoTheme()) {
            boolean shouldBeNight = Tools.isNightTimeNow();
            int nightModeFlags = getResources().getConfiguration().uiMode
                    & Configuration.UI_MODE_NIGHT_MASK;
            boolean isCurrentlyNight = nightModeFlags == Configuration.UI_MODE_NIGHT_YES;
            if (shouldBeNight != isCurrentlyNight) {
                Tools.applyTheme(shouldBeNight);
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        active = false;
        if (adNetworkHelper != null) adNetworkHelper.destroyAndDetachBanner();
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        Tools.checkGooglePlayUpdate(this);
    }

    @Override
    protected void onStop() {
        super.onStop();
        Tools.checkGooglePlayUpdateStopListener();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_activity_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_setting) {
            ActivitySetting.navigate(this);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // ── Reklam ───────────────────────────────────────────────────────────

    private void prepareAds() {
        adNetworkHelper = new AdNetworkHelper(this);
        adNetworkHelper.init();
        adNetworkHelper.updateConsentStatus();
        adNetworkHelper.loadShowUMPConsentForm();       // SDK'da gerçekten var
        adNetworkHelper.loadBannerAd(AppConfig.ads.ad_main_banner);
        adNetworkHelper.loadInterstitialAd(AppConfig.ads.ad_main_interstitial);
    }

    // Gecis reklami AdCounters icinde: 10 ekran donusu ve 3 favori dokunusu.
    // Eski 5 tiklama sayaci kaldirildi. Indirme ve kaydetme odullu reklamla kalir.

    // ── Ana sayfa / Favoriler sayfa adaptörü ──────────────────────────────

    private static class MainPagerAdapter extends FragmentStateAdapter {

        MainPagerAdapter(@NonNull AppCompatActivity activity) {
            super(activity);
        }

        @Override
        public int getItemCount() {
            return 2;
        }

        @NonNull
        @Override
        public Fragment createFragment(int position) {
            if (position == PAGE_HOME) {
                return FragmentWallpaper.instance();
            }
            // DEĞİŞTİ: Favoriler artık tek bir liste — "Yeni Eklenenler / En Çok
            // Beğenilen / En Çok İndirilen" alt sekmeleri kaldırıldı, çünkü bu
            // sayılar tüm kullanıcılar genelinde değil sadece cihazda tutuluyordu
            // ve kafa karıştırıyordu. Sadece favoriye eklenen görseller, eklenme
            // tarihine göre (en yeni en üstte) gösteriliyor.
            return FragmentFavoriteList.instance();
        }
    }
}