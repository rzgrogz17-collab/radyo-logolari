package com.wello.wallpaperose.activity;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.wello.wallpaperose.AppConfig;
import com.wello.wallpaperose.R;
import com.wello.wallpaperose.advertise.AdNetworkHelper;
import com.wello.wallpaperose.data.ThisApp;
import com.wello.wallpaperose.databinding.ActivitySplashBinding;
import com.wello.wallpaperose.utils.AppConfigExt;
import com.wello.wallpaperose.utils.GlassDialog;
import com.wello.wallpaperose.utils.Tools;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;

import java.util.List;

import dreamspace.blogger.sdk.listener.RequestListener;

public class ActivitySplash extends AppCompatActivity {

    public static void restart(Activity activity) {
        Intent i = new Intent(activity, ActivitySplash.class);
        activity.finishAffinity();
        activity.startActivity(i);
    }

    public static void navigate(Activity activity) {
        activity.startActivity(new Intent(activity, ActivitySplash.class));
    }

    private ActivitySplashBinding binding;
    private AlertDialog alertDialog;
    private boolean categoryFinish = false;
    private boolean openAppShowing = false;
    private boolean openAdStarted = false;
    private boolean navigating = false;

    static boolean active = false;

    // YENİ: Splash ekranı, tüm veriler/reklam hazır olduktan sonra bile
    // ekranda 3 saniye daha kalsın diye eklenen ekstra bekleme süresi.
    private static final long EXTRA_SPLASH_WAIT_MS = 5000L;

    // Logo "nefes alıp verme" (breathing) animasyonu
    private ObjectAnimator logoBreath;
    private final Handler dotHandler = new Handler(Looper.getMainLooper());
    private final Handler navigateHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.Theme_RemoveSplashScreenTheme);
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 31) {
            getSplashScreen().setOnExitAnimationListener(view -> view.remove());
        }
        binding = ActivitySplashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        startEntranceAnimations();

        if (AppConfig.USE_REMOTE_CONFIG) {
            requestRemoteConfig();
        } else {
            requestCategoriesData();
        }

        Tools.fullScreen(this);
    }

    // ── Tema: ilk açılışta gece modu, sonraki açılışlarda kullanıcı tercihi ──

    private void applyInitialTheme() {
        boolean isDark = ThisApp.pref().isDarkTheme();
        Tools.applyTheme(isDark);
    }

    // ── Giriş animasyonları ───────────────────────────────────────────────────

    private void startEntranceAnimations() {
        binding.lytCenter.animate()
                .alpha(1f).translationY(0f)
                .setDuration(700).setStartDelay(150)
                .setInterpolator(new DecelerateInterpolator(2f))
                .withEndAction(this::startLogoBreathing)
                .start();

        // Dış halka artık dönmüyor, sabit ince şerit olarak beliriyor
        binding.glowRingOuter.animate().alpha(1f).setDuration(1000).setStartDelay(300).start();

        // Halka şeridi üzerinde gidip gelen iki ışık hüzmesi (kendi içinde sonsuz salınır)
        binding.ringBeams.animate().alpha(1f).setDuration(1000).setStartDelay(500).start();

        binding.shimmer.startAnimation(
                android.view.animation.AnimationUtils.loadAnimation(
                        getApplicationContext(), R.anim.push_up_in));

        animateDot(binding.dot1, 0L);
        animateDot(binding.dot2, 300L);
        animateDot(binding.dot3, 600L);

        animateStar(binding.star1, 400L, 2200L);
        animateStar(binding.star2, 900L, 2800L);
        animateStar(binding.star3, 600L, 1900L);
        animateStar(binding.star4, 1200L, 3100L);
        animateStar(binding.star5, 200L, 2500L);
    }

    // Dairenin içindeki logonun sürekli nefes alıp veriyormuş gibi hafifçe
    // büyüyüp küçülmesini sağlar.
    private void startLogoBreathing() {
        logoBreath = ObjectAnimator.ofPropertyValuesHolder(
                binding.logo,
                android.animation.PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.08f),
                android.animation.PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.08f));
        logoBreath.setDuration(1400);
        logoBreath.setRepeatCount(ValueAnimator.INFINITE);
        logoBreath.setRepeatMode(ValueAnimator.REVERSE);
        logoBreath.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
        logoBreath.start();
    }

    private void animateDot(View dot, long delay) {
        Runnable pulse = new Runnable() {
            @Override
            public void run() {
                if (!active) return;
                dot.animate().alpha(1f).scaleX(1.4f).scaleY(1.4f).setDuration(300)
                        .withEndAction(() -> dot.animate().alpha(0.15f).scaleX(1f).scaleY(1f)
                                .setDuration(300).start()).start();
                dotHandler.postDelayed(this, 900L);
            }
        };
        dotHandler.postDelayed(pulse, delay);
    }

    private void animateStar(View star, long initDelay, long period) {
        Runnable twinkle = new Runnable() {
            @Override
            public void run() {
                if (!active) return;
                star.animate().alpha(0.85f).translationYBy(-6f).setDuration(period / 2)
                        .withEndAction(() -> star.animate().alpha(0f).translationYBy(6f)
                                .setDuration(period / 2).start()).start();
                dotHandler.postDelayed(this, period + 400L);
            }
        };
        dotHandler.postDelayed(twinkle, initDelay);
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────

    @Override
    public void onStart() {
        super.onStart();
        active = true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        active = false;
        dotHandler.removeCallbacksAndMessages(null);
        navigateHandler.removeCallbacksAndMessages(null);
        if (logoBreath != null) logoBreath.cancel();
    }

    // ── Remote Config ────────────────────────────────────────────────────────

    private void requestRemoteConfig() {
        Log.d("Splash", "requestRemoteConfig");
        FirebaseRemoteConfig firebaseRemoteConfig = ThisApp.get().getFirebaseRemoteConfig();
        firebaseRemoteConfig.fetchAndActivate().addOnCompleteListener(this,
                (OnCompleteListener<Boolean>) task -> {
                    if (!ActivitySplash.active || (alertDialog != null && alertDialog.isShowing()))
                        return;
                    if (task.isSuccessful()) {
                        Log.d("Splash", "Remote config başarılı.");
                        AppConfigExt.setFromRemoteConfig(firebaseRemoteConfig);
                        requestCategoriesData();
                    } else {
                        Log.w("Splash", "Remote config başarısız.");
                        dialogFailedRemoteConfig(getString(R.string.message_failed_config));
                    }
                });
    }

    // ── Kategori Verisi + Reklam ─────────────────────────────────────────────

    private void requestCategoriesData() {
        ThisApp.get().initBloggerAPI();
        ThisApp.get().bloggerAPI.getCategories(AppConfig.general.blogger_url,
                new RequestListener<List<String>>() {
                    @Override
                    public void onSuccess(List<String> resp) {
                        super.onSuccess(resp);
                        ThisApp.get().setCategories(resp);
                        categoryFinish = true;
                        startActivityMain();
                    }

                    @Override
                    public void onFailed(String messages) {
                        super.onFailed(messages);
                        if (messages != null) Log.e("Splash", messages);
                        dialogFailedCategories(messages == null
                                ? getString(R.string.message_failed_server)
                                : messages);
                    }
                });

        if (openAdStarted) return;
        openAdStarted = true;

        // GDPR formu kapandıktan sonra AdMob açılış reklamı. Form yoksa reklam hemen istenir.
        AdNetworkHelper adNetworkHelper = new AdNetworkHelper(this);
        adNetworkHelper.loadShowUMPConsentForm(() -> {
            if (isFinishing() || isDestroyed()) return;
            adNetworkHelper.init();
            adNetworkHelper.loadAndShowOpenAppAd(this, AppConfig.ads.ad_splash_open_app, () -> {
                new Handler(getMainLooper()).postDelayed(() -> {
                    openAppShowing = true;
                    startActivityMain();
                }, 500);
            });
        });
    }

    // ── Sonraki Ekran ────────────────────────────────────────────────────────

    private void startActivityMain() {
        if (alertDialog != null && alertDialog.isShowing()) alertDialog.dismiss();
        if (!categoryFinish || !openAppShowing) return;
        if (navigating) return;
        navigating = true;

        // YENİ: Her şey hazır olduktan sonra bile splash ekranı 3 saniye
        // daha ekranda kalsın diye ekstra bekleme eklendi.
        navigateHandler.postDelayed(this::navigateToNextScreen, EXTRA_SPLASH_WAIT_MS);
    }

    private void navigateToNextScreen() {
        if (!active) return;
        // YENİ: İlk açılışta kısa bir tanıtım (onboarding) ekranı gösterilir.
        if (AppConfig.SHOW_ONBOARDING && ThisApp.pref().isFirstLaunch()) {
            startActivity(new Intent(this, ActivityOnboarding.class));
        } else {
            startActivity(new Intent(this, ActivityMain.class));
        }
        finish();
    }

    // ── Hata Diyalogları ─────────────────────────────────────────────────────

    public void dialogFailedRemoteConfig(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.failed).setMessage(message).setCancelable(false)
                .setPositiveButton(R.string.RETRY, (d, w) -> {
                    d.dismiss();
                    requestRemoteConfig();
                });
        alertDialog = builder.create();
        alertDialog.show();
        styleDialog(alertDialog);
    }

    public void dialogFailedCategories(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.failed).setMessage(message).setCancelable(false)
                .setPositiveButton(R.string.RETRY, (d, w) -> {
                    d.dismiss();
                    requestCategoriesData();
                });
        alertDialog = builder.create();
        alertDialog.show();
        styleDialog(alertDialog);
    }

    private void styleDialog(AlertDialog dialog) {
        GlassDialog.apply(dialog);
    }
}