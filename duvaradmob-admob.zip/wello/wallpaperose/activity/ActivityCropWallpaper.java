package com.wello.wallpaperose.activity;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.wello.wallpaperose.R;
import com.wello.wallpaperose.clock.ClockStore;
import com.wello.wallpaperose.utils.FavoriteImageStore;
import com.wello.wallpaperose.utils.GlassDialog;
import com.wello.wallpaperose.utils.Tools;
import com.wello.wallpaperose.widget.CropOverlayView;

import java.io.IOException;

/**
 * YENİ: Kullanıcının bir duvar kağıdının istediği bölgesini seçip (kırpıp)
 * Ana Ekran veya Kilit Ekranı olarak ayarlayabildiği ekran. Kırpma işlemi
 * dışa bağımlılık gerektirmeyen {@link CropOverlayView} ile yapılır; kırpma
 * çerçevesinin altında cam (glassmorphism) görünümlü bir onay butonu vardır.
 */
public class ActivityCropWallpaper extends AppCompatActivity {

    private static final String EXTRA_IMAGE_URL = "extra_image_url";
    private static final String EXTRA_WALLPAPER_ID = "extra_wallpaper_id";
    private String wallpaperId;

    private ImageView imgSource;
    private CropOverlayView cropOverlay;
    private ProgressBar progressBar;
    private Bitmap sourceBitmap;

    public static void navigate(Activity activity, String imageUrl) {
        navigate(activity, imageUrl, null);
    }

    public static void navigate(Activity activity, String imageUrl, String wallpaperId) {
        Intent intent = new Intent(activity, ActivityCropWallpaper.class);
        intent.putExtra(EXTRA_IMAGE_URL, imageUrl);
        intent.putExtra(EXTRA_WALLPAPER_ID, wallpaperId);
        activity.startActivity(intent);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_wallpaper);
        wallpaperId = getIntent().getStringExtra(EXTRA_WALLPAPER_ID);

        imgSource = findViewById(R.id.img_crop_source);
        cropOverlay = findViewById(R.id.crop_overlay);
        progressBar = findViewById(R.id.crop_progress);
        Button btApply = findViewById(R.id.bt_crop_apply);
        ImageView btBack = findViewById(R.id.bt_crop_back);

        btBack.setOnClickListener(v -> finish());
        btApply.setOnClickListener(v -> onCropConfirmed());

        String imageUrl = getIntent().getStringExtra(EXTRA_IMAGE_URL);
        loadSourceImage(imageUrl);
    }

    private void loadSourceImage(final String url) {
        progressBar.setVisibility(View.VISIBLE);
        new Thread(() -> {
            try {
                final Bitmap bitmap = Glide.with(getApplicationContext())
                        .asBitmap()
                        .load(url)
                        .submit()
                        .get();
                runOnUiThread(() -> {
                    sourceBitmap = bitmap;
                    imgSource.setImageBitmap(bitmap);
                    progressBar.setVisibility(View.GONE);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    Tools.showToastCenter(this, R.string.crop_load_failed);
                    finish();
                });
            }
        }).start();
    }

    private void onCropConfirmed() {
        if (sourceBitmap == null) return;
        Bitmap cropped = extractCroppedBitmap();
        if (cropped == null) {
            Tools.showToastCenter(this, R.string.crop_failed);
            return;
        }
        showApplyTargetDialog(cropped);
    }

    /**
     * CropOverlayView üzerindeki (view piksel) kırpma dikdörtgenini, ImageView
     * içindeki fitCenter yerleşimine göre gerçek bitmap piksel koordinatlarına
     * çevirip o bölgeyi keser. ImageView.getImageMatrix() yerine fitCenter
     * mantığı elle hesaplanır — daha öngörülebilir ve test edilebilir.
     */
    @Nullable
    private Bitmap extractCroppedBitmap() {
        RectF r = cropOverlay.getCropRect();
        if (r == null) return null;

        int viewW = imgSource.getWidth();
        int viewH = imgSource.getHeight();
        int bmpW = sourceBitmap.getWidth();
        int bmpH = sourceBitmap.getHeight();
        if (viewW <= 0 || viewH <= 0 || bmpW <= 0 || bmpH <= 0) return null;

        float scale = Math.min((float) viewW / bmpW, (float) viewH / bmpH);
        float displayedW = bmpW * scale;
        float displayedH = bmpH * scale;
        float offsetX = (viewW - displayedW) / 2f;
        float offsetY = (viewH - displayedH) / 2f;

        float left = (r.left - offsetX) / scale;
        float top = (r.top - offsetY) / scale;
        float right = (r.right - offsetX) / scale;
        float bottom = (r.bottom - offsetY) / scale;

        left = Math.max(0, left);
        top = Math.max(0, top);
        right = Math.min(bmpW, right);
        bottom = Math.min(bmpH, bottom);

        int width = Math.max(1, Math.round(right - left));
        int height = Math.max(1, Math.round(bottom - top));

        try {
            return Bitmap.createBitmap(sourceBitmap, Math.round(left), Math.round(top), width, height);
        } catch (Exception e) {
            return null;
        }
    }

    private void showApplyTargetDialog(final Bitmap cropped) {
        String[] options = {getString(R.string.set_home), getString(R.string.set_lock)};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, options) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View row = super.getView(position, convertView, parent);
                TextView label = row.findViewById(android.R.id.text1);
                if (label != null) {
                    label.setTextColor(Color.WHITE);
                    label.setTextSize(16f);
                }
                return row;
            }
        };
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(R.string.crop_apply_target_title)
                .setAdapter(adapter, (d, which) -> {
                    int flag = (which == 0) ? WallpaperManager.FLAG_SYSTEM : WallpaperManager.FLAG_LOCK;
                    applyCroppedWallpaper(cropped, flag);
                })
                .setNegativeButton(R.string.CANCEL, null)
                .create();
        GlassDialog.show(dialog);
    }

    private void applyCroppedWallpaper(Bitmap bitmap, int flag) {
        try {
            ClockStore.publish(this, bitmap, flag);
            FavoriteImageStore.save(this, wallpaperId, bitmap);
            Tools.showToastCenter(this, R.string.set_success);
            Tools.vibrate(this, 40);
            finish();
        } catch (IOException | RuntimeException e) {
            Tools.showToastCenter(this, R.string.set_failed);
        }
    }
}