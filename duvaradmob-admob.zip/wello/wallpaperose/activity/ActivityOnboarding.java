package com.wello.wallpaperose.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.wello.wallpaperose.R;
import com.wello.wallpaperose.data.ThisApp;
import com.wello.wallpaperose.databinding.ActivityOnboardingBinding;
import com.wello.wallpaperose.databinding.ItemOnboardingPageBinding;

/**
 * YENİ: Uygulama ilk kez açıldığında gösterilen kısa tanıtım ekranları.
 * "Atla" veya son sayfada "Başla" ile ActivityMain'e geçilir ve bir daha
 * gösterilmemesi için ThisApp.pref().setFirstLaunch(false) çağrılır.
 * <p>
 * DEĞİŞTİ: Sayfa göstergesi artık TabLayout ile taklit edilen ovalimsi
 * noktalar değil, sabit boyutlu gerçekten yuvarlak View'lerden oluşan
 * manuel bir gösterge. Rozetler de her sayfada farklı renkte cam
 * (glassmorphism) görünümünde.
 */
public class ActivityOnboarding extends AppCompatActivity {

    private ActivityOnboardingBinding binding;
    private View[] dots;

    private static final int PAGE_COUNT = 3;
    private final int[] titles = {
            R.string.onboarding_title_1,
            R.string.onboarding_title_2,
            R.string.onboarding_title_3
    };
    private final int[] descriptions = {
            R.string.onboarding_desc_1,
            R.string.onboarding_desc_2,
            R.string.onboarding_desc_3
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityOnboardingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.viewPagerOnboarding.setAdapter(new OnboardingAdapter());
        binding.viewPagerOnboarding.setPageTransformer((page, position) -> {
            float abs = Math.abs(position);
            page.setAlpha(1f - Math.min(abs, 1f) * 0.45f);
            page.setTranslationX(-position * page.getWidth() * 0.12f);
            page.setScaleY(1f - Math.min(abs, 1f) * 0.08f);
        });
        buildDots();
        selectDot(0);

        binding.btSkip.setOnClickListener(v -> finishOnboarding());

        binding.btNext.setOnClickListener(v -> {
            int next = binding.viewPagerOnboarding.getCurrentItem() + 1;
            if (next < PAGE_COUNT) {
                binding.viewPagerOnboarding.setCurrentItem(next, true);
            } else {
                finishOnboarding();
            }
        });

        binding.viewPagerOnboarding.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                selectDot(position);
                boolean isLast = position == PAGE_COUNT - 1;
                binding.btNext.setText(isLast
                        ? getString(R.string.onboarding_start)
                        : getString(R.string.onboarding_next));
                binding.btSkip.setVisibility(isLast ? View.INVISIBLE : View.VISIBLE);
            }
        });
    }

    // YENİ: Sabit boyutlu, gerçekten yuvarlak gösterge noktalarını kod ile oluşturur.
    private void buildDots() {
        dots = new View[PAGE_COUNT];
        int size = (int) (8 * getResources().getDisplayMetrics().density);
        int margin = (int) (5 * getResources().getDisplayMetrics().density);

        binding.lytDots.removeAllViews();
        for (int i = 0; i < PAGE_COUNT; i++) {
            View dot = new View(this);
            applyDotLayoutParams(dot, size, size, margin);
            dot.setBackgroundResource(R.drawable.shape_dot_unselected);
            binding.lytDots.addView(dot);
            dots[i] = dot;
        }
    }

    private void applyDotLayoutParams(View dot, int width, int height, int margin) {
        android.widget.LinearLayout.LayoutParams params =
                new android.widget.LinearLayout.LayoutParams(width, height);
        params.setMargins(margin, 0, margin, 0);
        dot.setLayoutParams(params);
    }

    private void selectDot(int position) {
        if (dots == null) return;
        float density = getResources().getDisplayMetrics().density;
        int margin = (int) (5 * density);
        for (int i = 0; i < dots.length; i++) {
            boolean selected = i == position;
            dots[i].setBackgroundResource(selected
                    ? R.drawable.shape_dot_selected
                    : R.drawable.shape_dot_unselected);
            applyDotLayoutParams(dots[i], (int) ((selected ? 22 : 8) * density), (int) (8 * density), margin);
        }
    }

    private void finishOnboarding() {
        ThisApp.pref().setFirstLaunch(false);
        startActivity(new Intent(this, ActivityMain.class));
        finish();
    }

    @Override
    public void onBackPressed() {
        int current = binding.viewPagerOnboarding.getCurrentItem();
        if (current > 0) {
            binding.viewPagerOnboarding.setCurrentItem(current - 1, true);
        } else {
            super.onBackPressed();
        }
    }

    private class OnboardingAdapter extends RecyclerView.Adapter<OnboardingAdapter.VH> {

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ItemOnboardingPageBinding itemBinding = ItemOnboardingPageBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false);
            return new VH(itemBinding);
        }

        @Override
        public void onBindViewHolder(@NonNull VH holder, int position) {
            holder.itemBinding.onboardingStage.setScene(position);
            holder.itemBinding.onboardingKicker.setText(R.string.app_name);
            holder.itemBinding.onboardingTitle.setText(titles[position]);
            holder.itemBinding.onboardingDesc.setText(descriptions[position]);
        }

        @Override
        public int getItemCount() {
            return PAGE_COUNT;
        }

        class VH extends RecyclerView.ViewHolder {
            ItemOnboardingPageBinding itemBinding;

            VH(ItemOnboardingPageBinding itemBinding) {
                super(itemBinding.getRoot());
                this.itemBinding = itemBinding;
            }
        }
    }
}
