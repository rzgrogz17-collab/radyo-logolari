package com.wello.wallpaperose.activity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;

import com.wello.wallpaperose.AppConfig;
import com.wello.wallpaperose.R;
import com.wello.wallpaperose.adapter.AdapterListener;
import com.wello.wallpaperose.adapter.AdapterListing;
import com.wello.wallpaperose.data.ThisApp;
import com.wello.wallpaperose.databinding.ActivityFavoriteBinding;
import com.wello.wallpaperose.model.Wallpaper;
import com.wello.wallpaperose.room.table.EntityListing;
import com.wello.wallpaperose.utils.Tools;

import java.util.ArrayList;
import java.util.List;

import dreamspace.blogger.sdk.model.ParamList;

public class ActivityFavorite extends AppCompatActivity {

    private ActivityFavoriteBinding binding;
    private AdapterListing adapter;
    private boolean allLoaded = false;
    private static int last_count = -1;

    // KAYDIRMA İÇİN GEREKLİ LİSTE (YENİ EKLENDİ)
    private List<Wallpaper> tumFavorilerListesi = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityFavoriteBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        binding.toolbar.setNavigationOnClickListener(view -> finish());


        initComponent();
        requestAction(1);
    }

    private void initComponent() {

        binding.recyclerView.setLayoutManager(new GridLayoutManager(this, Tools.getGridSpanCount(this)));

        //set data and list adapter
        adapter = new AdapterListing(this, binding.recyclerView, AppConfig.general.listing_pagination_count);
        binding.recyclerView.setAdapter(adapter);

        // Scroll (Kaydırma) sona gelince tetiklenir
        adapter.setListener(new AdapterListener<Object>() {
            @Override
            public void onClick(View view, String type, Object obj, int position) {
                super.onClick(view, type, obj, position);

                // --- BURASI DEĞİŞTİ (KAYDIRMA İÇİN) ---
                // Sadece tek resmi değil, tüm listeyi gönderiyoruz.
                Wallpaper w = (Wallpaper) obj;

                // 1. Tüm listeyi global değişkene yükle
                ThisApp.itemsWallpaper = new ArrayList<>(tumFavorilerListesi);

                // 2. Doğru pozisyonu bul (Listede kaçıncı sırada?)
                int gercekPozisyon = tumFavorilerListesi.indexOf(w);

                // 3. Detay sayfasını bu pozisyonla aç (Böylece sağ-sol çalışır)
                if (gercekPozisyon != -1) {
                    ActivityListingDetail.navigate(ActivityFavorite.this, gercekPozisyon);
                } else {
                    // Hata olursa eski usül aç
                    ActivityListingDetail.navigate(ActivityFavorite.this, w);
                }
            }

            @Override
            public void onLoadMore(int page) {
                super.onLoadMore(page);
                if (allLoaded) {
                    adapter.setLoaded();
                } else {
                    int next_page = page + 1;
                    requestAction(next_page);
                }
            }

        });

        binding.swipeRefresh.setOnRefreshListener(() -> {
            allLoaded = false;
            adapter.resetListData();
            requestAction(1);
        });
    }

    private void requestAction(final int page_no) {
        if (page_no == 1) {
            adapter.resetListData();
            tumFavorilerListesi.clear(); // Listeyi temizle
            showNoItemView(false);
            swipeProgress(true);
        } else {
            adapter.setLoadingOrFailed(null);
        }
        new Handler(Looper.getMainLooper()).postDelayed(() -> request(page_no), 200);
    }

    private void request(Integer pageNo) {
        ParamList param = new ParamList();
        param.page = pageNo.toString();
        param.count = AppConfig.general.listing_pagination_count.toString();

        Integer count = Integer.parseInt(param.count);
        int offset = (pageNo - 1) * count;
        List<EntityListing> entityListings = ThisApp.dao().getAllListingByPage(count, offset);
        List<Wallpaper> items = new ArrayList<>();
        for (EntityListing e : entityListings) {
            items.add(e.original());
        }
        displayApiResultPlace(items);
        allLoaded = (adapter.getItemCount() >= ThisApp.dao().getListingCount());
    }

    private void showNoItemView(boolean show) {
        ((TextView) binding.lytFailed.findViewById(R.id.failed_subtitle)).setText(getString(R.string.empty_state_no_data));
        if (show) {
            binding.lytFailed.setVisibility(View.VISIBLE);
        } else {
            binding.lytFailed.setVisibility(View.GONE);
        }
    }

    private void swipeProgress(final boolean show) {
        binding.swipeRefresh.post(() -> binding.swipeRefresh.setRefreshing(show));
        if (!show) {
            binding.recyclerView.setVisibility(View.VISIBLE);
            binding.shimmer.setVisibility(View.GONE);
            binding.shimmer.stopShimmer();
            return;
        }
        binding.recyclerView.setVisibility(View.GONE);
        binding.shimmer.setVisibility(View.VISIBLE);
        binding.shimmer.startShimmer();
    }

    private void displayApiResultPlace(final List<Wallpaper> items) {
        adapter.insertData(items);
        tumFavorilerListesi.addAll(items); // Gelen verileri kaydırma listesine de ekle
        swipeProgress(false);
        showNoItemView(adapter.getItemCount() == 0);
    }

    public void updateData(){
        int listing_count = ThisApp.dao().getListingCount();
        if(listing_count != last_count){
            last_count = listing_count;
            requestAction(1);
        }
    }
}