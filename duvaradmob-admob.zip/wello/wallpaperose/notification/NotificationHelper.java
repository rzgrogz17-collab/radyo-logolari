package com.wello.wallpaperose.notification;

import android.content.Context;
import android.content.Intent;

import com.wello.wallpaperose.AppConfig;
import com.wello.wallpaperose.BuildConfig;
import com.wello.wallpaperose.R;
import com.wello.wallpaperose.activity.ActivityDialogNotification;
import com.wello.wallpaperose.activity.ActivitySplash;
import com.wello.wallpaperose.room.AppDatabase;
import com.wello.wallpaperose.room.DAO;
import com.wello.wallpaperose.room.table.NotificationEntity;
import com.onesignal.OSNotification;
import com.onesignal.OneSignal;

public class NotificationHelper {

    public static void init(Context context) {
        oneSignalInit(context);
    }

    public static void oneSignalInit(Context context) {
        if (BuildConfig.DEBUG) {
            OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);
        }

        // init one signal with client data
        OneSignal.initWithContext(context);
        OneSignal.setAppId(AppConfig.notification.notif_one_signal_appid);
        OneSignal.sendTag("APP", context.getResources().getString(R.string.app_name));

        // handle when use click notification
        onOneSignalOpenNotification(context);

    }

    public static void onOneSignalOpenNotification(Context context) {
        DAO dao = AppDatabase.getDb(context).get();
        OneSignal.setNotificationOpenedHandler(result -> {
            OSNotification notification = result.getNotification();
            NotificationEntity notificationEntity = dao.getNotification(notification.getSentTime());
            Intent intent = new Intent(context, ActivitySplash.class);
            if (notificationEntity != null) {
                intent = ActivityDialogNotification.navigateBase(context, notificationEntity, true);
            }
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);

        });

    }


}