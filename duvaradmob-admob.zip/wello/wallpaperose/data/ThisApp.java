package com.wello.wallpaperose.data;

import android.app.Activity;
import android.app.Application;
import android.location.Location;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.wello.wallpaperose.AppConfig;
import com.wello.wallpaperose.BuildConfig;
import com.wello.wallpaperose.clock.ClockStore;
import com.wello.wallpaperose.clock.ClockWallpaperWorker;
import com.wello.wallpaperose.advertise.AdCounters;
import com.wello.wallpaperose.model.Wallpaper;
import com.wello.wallpaperose.notification.NotificationHelper;
import com.wello.wallpaperose.room.AppDatabase;
import com.wello.wallpaperose.room.DAO;
import com.wello.wallpaperose.room.table.NotificationEntity;
import com.wello.wallpaperose.utils.Tools;
import com.google.firebase.FirebaseApp;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import dreamspace.blogger.sdk.BloggerAPI;

public class ThisApp extends Application {

    private static ThisApp mInstance;
    private static SharedPref sharedPref;
    private static DAO dao;

    public static synchronized SharedPref pref() {
        return sharedPref;
    }

    public static synchronized DAO dao() {
        return dao;
    }

    public static synchronized ThisApp get() {
        return mInstance;
    }

    private Location location = null;
    private List<String> categories = new ArrayList<>();
    private NotificationEntity notification;
    private FirebaseRemoteConfig firebaseRemoteConfig;

    public BloggerAPI bloggerAPI;
    public static List<Wallpaper> itemsWallpaper = new ArrayList<>();

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        sharedPref = new SharedPref(this);
        dao = AppDatabase.getDb(this).get();

        initFirebase();
        initRemoteConfig();

        // FIX: bloggerAPI artık burada, en başta oluşturuluyor.
        // Önceden bu metod hiç çağrılmıyordu, bu yüzden FragmentWallpaper
        // ekrana gelip API'yi kullanmaya çalıştığında bloggerAPI null kalıyor
        // ve NullPointerException fırlatılıyordu.
        initBloggerAPI();

        // YENİ: Otomatik mod açıksa cihaz saatine göre (gündüz/gece), kapalıysa
        // kullanıcının ayarlardan elle seçtiği temaya göre uygulanır.
        Tools.applyAutoOrManualTheme();
        if (AppConfig.CLOCK_ENABLE) {
            ClockWallpaperWorker.schedule(this);
        } else {
            ClockStore.releaseScreen(this);
        }
        NotificationHelper.init(this);
        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override public void onActivityResumed(@NonNull Activity activity) {
                AdCounters.onScreenResumed(activity);
            }
            @Override public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {}
            @Override public void onActivityStarted(@NonNull Activity activity) {}
            @Override public void onActivityPaused(@NonNull Activity activity) {}
            @Override public void onActivityStopped(@NonNull Activity activity) {}
            @Override public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {}
            @Override public void onActivityDestroyed(@NonNull Activity activity) {}
        });
    }

    private void initRemoteConfig() {
        firebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
        if (!AppConfig.USE_REMOTE_CONFIG) return;
        FirebaseRemoteConfigSettings configSettings = new FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(BuildConfig.DEBUG ? 0 : 60)
                .setFetchTimeoutInSeconds(4)
                .build();
        firebaseRemoteConfig.setConfigSettingsAsync(configSettings);
    }

    private void initFirebase() {
        FirebaseApp.initializeApp(this);
        FirebaseAnalytics.getInstance(this);
    }

    public void initBloggerAPI() {
        bloggerAPI = new BloggerAPI(AppConfig.general.access_key);
    }

    // FIX: ekstra güvenlik katmanı. Herhangi bir nedenle (örn. process
    // restore, başka bir init sırası değişikliği) bloggerAPI hâlâ null
    // gelirse, burada otomatik olarak oluşturulur. Böylece hiçbir Fragment
    // veya Activity artık "null object reference" hatası alamaz.
    public BloggerAPI getBloggerAPI() {
        if (bloggerAPI == null) {
            initBloggerAPI();
        }
        return bloggerAPI;
    }

    public FirebaseRemoteConfig getFirebaseRemoteConfig() {
        return firebaseRemoteConfig;
    }

    public NotificationEntity getNotification() {
        return notification;
    }

    public void setNotification(NotificationEntity n) {
        this.notification = n;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public List<String> getCategories() {
        return categories;
    }

    public void setCategories(List<String> categories) {
        if (AppConfig.general.sort_category_alphabetically) Collections.sort(categories);
        this.categories = categories;
    }
}