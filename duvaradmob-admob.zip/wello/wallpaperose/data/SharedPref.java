package com.wello.wallpaperose.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.text.TextUtils;

public class SharedPref {

    private static SharedPref mInstance;

    public static synchronized SharedPref get() {
        return mInstance;
    }

    private static String default_ringtone_url = "content://settings/system/notification_sound";
    private Context context;
    private SharedPreferences sharedPreferences;
    private SharedPreferences prefs;

    public SharedPref(Context context) {
        mInstance = this;
        this.context = context;
        sharedPreferences = context.getSharedPreferences("MAIN_PREF", Context.MODE_PRIVATE);
        prefs = PreferenceManager.getDefaultSharedPreferences(context);
    }

    // Preference for theme — boolean (dark=true default)
    public void setDarkTheme(boolean flag) {
        sharedPreferences.edit().putBoolean("DARK_THEME", flag).apply();
    }

    public boolean isDarkTheme() {
        return sharedPreferences.getBoolean("DARK_THEME", true); // default: gece modu
    }

    // YENİ: Otomatik (saate göre gündüz/gece) tema tercihi.
    // Varsayılan: açık — kullanıcı ayarlardan elle Açık/Koyu seçerse kapanır.
    public void setAutoTheme(boolean flag) {
        sharedPreferences.edit().putBoolean("AUTO_THEME", flag).apply();
    }

    public boolean isAutoTheme() {
        return sharedPreferences.getBoolean("AUTO_THEME", true);
    }

    // Preference for Fcm register
    public void setFcmRegId(String fcmRegId) {
        sharedPreferences.edit().putString("FCM_PREF_KEY", fcmRegId).apply();
    }

    public String getFcmRegId() {
        return sharedPreferences.getString("FCM_PREF_KEY", null);
    }

    public boolean isFcmRegIdEmpty() {
        return TextUtils.isEmpty(getFcmRegId());
    }

    public void setTextSize(String value) {
        sharedPreferences.edit().putString("TEXT_SIZE_NEWS", value).apply();
    }

    public String getTextSize() {
        return sharedPreferences.getString("TEXT_SIZE_NEWS", "small");
    }

    public void setSubscibeNotif(boolean value) {
        sharedPreferences.edit().putBoolean("SUBSCRIBE_NOTIF", value).apply();
    }

    public boolean isSubscibeNotif() {
        return sharedPreferences.getBoolean("SUBSCRIBE_NOTIF", false);
    }

    // Preference for first launch
    public void setFirstLaunch(boolean flag) {
        sharedPreferences.edit().putBoolean("FIRST_LAUNCH", flag).apply();
    }

    public boolean isFirstLaunch() {
        return sharedPreferences.getBoolean("FIRST_LAUNCH", true);
    }

    // YENİ: Otomatik Duvar Kağıdı Değiştirici tercihi.
    // Varsayılan: kapalı. Açıksa "weekly" false=günlük, true=haftalık demektir.
    public void setAutoWallpaperEnabled(boolean flag) {
        sharedPreferences.edit().putBoolean("AUTO_WALLPAPER_ENABLED", flag).apply();
    }

    public boolean isAutoWallpaperEnabled() {
        return sharedPreferences.getBoolean("AUTO_WALLPAPER_ENABLED", false);
    }

    public void setAutoWallpaperWeekly(boolean weekly) {
        sharedPreferences.edit().putBoolean("AUTO_WALLPAPER_WEEKLY", weekly).apply();
    }

    public boolean isAutoWallpaperWeekly() {
        return sharedPreferences.getBoolean("AUTO_WALLPAPER_WEEKLY", false);
    }

    // Preference for settings
    public void setPushNotification(boolean value) {
        sharedPreferences.edit().putBoolean("SETTINGS_PUSH_NOTIF", value).apply();
    }

    public boolean getPushNotification() {
        return sharedPreferences.getBoolean("SETTINGS_PUSH_NOTIF", true);
    }

    public String getRingtone() {
        return sharedPreferences.getString("SETTINGS_RINGTONE", default_ringtone_url);
    }

    public void setImageCache(boolean value) {
        sharedPreferences.edit().putBoolean("SETTINGS_IMG_CACHE", value).apply();
    }

    public boolean getImageCache() {
        return sharedPreferences.getBoolean("SETTINGS_IMG_CACHE", true);
    }

    public String getAppStatus() {
        return sharedPreferences.getString("APP_STATUS", "");
    }

    public void setAppStatus(String status) {
        sharedPreferences.edit().putString("APP_STATUS", status).apply();
    }

    // Preference for first launch
    public void setIntersCounter(int counter) {
        sharedPreferences.edit().putInt("INTERS_COUNT", counter).apply();
    }

    public int getIntersCounter() {
        return sharedPreferences.getInt("INTERS_COUNT", 0);
    }

    public void clearIntersCounter() {
        sharedPreferences.edit().putInt("INTERS_COUNT", 0).apply();
    }

    /**
     * To save dialog permission state
     */
    public void setNeverAskAgain(String key, boolean value) {
        sharedPreferences.edit().putBoolean(key, value).apply();
    }

    public boolean getNeverAskAgain(String key) {
        return sharedPreferences.getBoolean(key, false);
    }

    /**
     * To save purchase flag
     */
    public void setPurchased(String key, boolean value) {
        sharedPreferences.edit().putBoolean(key, value).apply();
    }

    public boolean isPurchased(String key) {
        return sharedPreferences.getBoolean(key, false);
    }

    /**
     * To save feature use limit
     */
    public void setFeatureUseLimit(int value) {
        sharedPreferences.edit().putInt("billing_feature_use_limit", value).apply();
    }

    public int getFeatureUseLimit() {
        return sharedPreferences.getInt("billing_feature_use_limit", 0);
    }

    /**
     * To save date
     */
    public void setLastDate(String value) {
        sharedPreferences.edit().putString("billing_feature_date", value).apply();
    }

    public String getLastDate() {
        return sharedPreferences.getString("billing_feature_date", "");
    }

}
