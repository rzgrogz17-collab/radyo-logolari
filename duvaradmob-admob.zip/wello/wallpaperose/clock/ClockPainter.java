package com.wello.wallpaperose.clock;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;

import java.util.Calendar;
import java.util.Locale;

/**
 * Saat modellerini resmin üstüne çizer. Rakamlar ve ibreler verilen takvimin saatidir.
 */
public final class ClockPainter {

    private static final ThreadLocal<ClockPlacement> ACTIVE = new ThreadLocal<>();

    private ClockPainter() {}

    public static void draw(Canvas canvas, ClockPlacement placement, int width, int height,
                            Calendar cal, boolean is24) {
        if (placement == null || width <= 0 || height <= 0) return;
        ACTIVE.set(placement);
        try {
            drawStyle(canvas, placement, width, height, cal, is24);
        } finally {
            ACTIVE.remove();
        }
    }

    private static void drawStyle(Canvas canvas, ClockPlacement placement, int width, int height,
                                  Calendar cal, boolean is24) {
        float cx = placement.nx * width;
        float cy = placement.ny * height;
        float size = width * 0.20f * placement.scale;
        int shadow = placement.shadow;
        int color = placement.color;
        switch (placement.style) {
            case 1:
                outline(canvas, cx, cy, size, shadow, cal, is24);
                break;
            case 2:
                neon(canvas, cx, cy, size, shadow, cal, is24);
                break;
            case 3:
                poster(canvas, cx, cy, size, shadow, cal, is24);
                break;
            case 4:
                split(canvas, cx, cy, size, shadow, cal, is24);
                break;
            case 5:
                AnalogFaces.field(canvas, cx, cy, size, shadow, color, cal);
                break;
            case 6:
                stack(canvas, cx, cy, size, shadow, cal, is24);
                break;
            case 7:
                bar(canvas, cx, cy, size, shadow, cal, is24);
                break;
            case 8:
                AnalogFaces.sport(canvas, cx, cy, size, shadow, color, cal);
                break;
            case 9:
                AnalogFaces.gauge(canvas, cx, cy, size, shadow, color, cal, is24);
                break;
            case 10:
                AnalogFaces.matrix(canvas, cx, cy, size, shadow, color, cal, is24);
                break;
            case 11:
                AnalogFaces.info(canvas, cx, cy, size, shadow, color, cal, is24);
                break;
            default:
                glass(canvas, cx, cy, size, shadow, cal, is24);
                break;
        }
    }

    private static void glass(Canvas canvas, float cx, float cy, float size, int shadow, Calendar cal, boolean is24) {
        Paint fill = textPaint(ink(), font(), size * 1.05f, shadow, 0xCC000000);
        Paint stroke = textPaint(ink(), font(), size * 1.05f, 0, 0);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Math.max(2f, size * 0.03f));
        String time = timeColon(cal, is24);
        drawCentered(canvas, time, cx, cy, stroke);
        drawCentered(canvas, time, cx, cy, fill);
        Paint date = textPaint(Color.WHITE, Typeface.create("sans-serif", Typeface.BOLD), size * 0.22f, shadow, 0xAA000000);
        date.setLetterSpacing(0.18f);
        drawCentered(canvas, dateLong(cal), cx, cy - size * 0.95f, date);
    }

    private static void outline(Canvas canvas, float cx, float cy, float size, int shadow, Calendar cal, boolean is24) {
        Paint stroke = textPaint(ink(), font(), size * 1.05f, shadow, 0xEE000000);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Math.max(2f, size * 0.035f));
        drawCentered(canvas, hour(cal, is24), cx, cy - size * 0.85f, stroke);
        drawCentered(canvas, minute(cal), cx, cy + size * 0.15f, stroke);
        drawCentered(canvas, second(cal), cx, cy + size * 1.05f, stroke);
        Paint date = textPaint(Color.WHITE, Typeface.create("sans-serif", Typeface.NORMAL), size * 0.18f, shadow, 0xAA000000);
        date.setLetterSpacing(0.22f);
        drawCentered(canvas, dateLong(cal), cx, cy - size * 1.85f, date);
    }

    private static void neon(Canvas canvas, float cx, float cy, float size, int shadow, Calendar cal, boolean is24) {
        int glow = ink();
        Paint paint = textPaint(glow, font(), size * 0.95f, Math.max(shadow, 3), glow);
        drawCentered(canvas, timeColon(cal, is24), cx, cy, paint);
        Paint date = textPaint(Color.WHITE, Typeface.create("sans-serif", Typeface.BOLD), size * 0.2f, shadow, 0xAA000000);
        date.setLetterSpacing(0.16f);
        drawCentered(canvas, dateShort(cal), cx, cy + size * 0.75f, date);
    }

    private static void poster(Canvas canvas, float cx, float cy, float size, int shadow, Calendar cal, boolean is24) {
        Paint date = textPaint(Color.BLACK, Typeface.create("sans-serif", Typeface.BOLD), size * 0.22f, shadow, 0x66FFFFFF);
        date.setLetterSpacing(0.14f);
        drawCentered(canvas, dateLong(cal), cx, cy - size * 0.95f, date);
        Paint time = textPaint(ink(), font(), size * 1.45f, shadow, 0xEE000000);
        drawCentered(canvas, timeCompact(cal, is24), cx, cy + size * 0.05f, time);
        Paint sec = textPaint(ink(), font(), size * 0.55f, shadow, 0xEE000000);
        drawCentered(canvas, second(cal), cx, cy + size * 0.95f, sec);
    }

    private static void split(Canvas canvas, float cx, float cy, float size, int shadow, Calendar cal, boolean is24) {
        Paint hourPaint = textPaint(ink(), font(), size * 1.55f, shadow, 0xEE000000);
        Paint minutePaint = textPaint(ink(), font(), size * 1.05f, shadow, 0xEE000000);
        Paint secondPaint = textPaint(ink(), font(), size * 0.48f, shadow, 0xEE000000);
        drawCentered(canvas, hour(cal, is24), cx - size * 0.15f, cy - size * 0.45f, hourPaint);
        drawCentered(canvas, minute(cal), cx + size * 0.55f, cy + size * 0.55f, minutePaint);
        drawCentered(canvas, second(cal), cx + size * 0.15f, cy + size * 1.15f, secondPaint);
    }

    private static void stack(Canvas canvas, float cx, float cy, float size, int shadow, Calendar cal, boolean is24) {
        Paint hourPaint = textPaint(ink(), font(), size * 1.05f, shadow, 0xEE000000);
        Paint minutePaint = textPaint(ink(), font(), size * 1.2f, shadow, 0xEE000000);
        Paint secondPaint = textPaint(ink(), font(), size * 0.55f, shadow, 0xEE000000);
        Paint date = textPaint(Color.WHITE, Typeface.create("sans-serif", Typeface.BOLD), size * 0.2f, shadow, 0xAA000000);
        date.setLetterSpacing(0.2f);
        drawCentered(canvas, hour(cal, is24), cx, cy - size * 0.85f, hourPaint);
        drawCentered(canvas, minute(cal), cx, cy + size * 0.25f, minutePaint);
        drawCentered(canvas, second(cal), cx, cy + size * 1.05f, secondPaint);
        drawCentered(canvas, dateShort(cal), cx, cy + size * 1.55f, date);
    }

    private static void bar(Canvas canvas, float cx, float cy, float size, int shadow, Calendar cal, boolean is24) {
        Paint time = textPaint(ink(), font(), size * 0.85f, shadow, 0xEE000000);
        String text = timeColon(cal, is24);
        float textW = time.measureText(text);
        Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
        bar.setColor(ink());
        applyShadow(bar, shadow, 0xFF000000);
        float left = cx - textW / 2f - size * 0.16f;
        canvas.drawRoundRect(new RectF(left, cy - size * 0.55f, left + size * 0.06f, cy + size * 0.45f), 8f, 8f, bar);
        time.setTextAlign(Paint.Align.LEFT);
        canvas.drawText(text, left + size * 0.18f, cy + size * 0.15f, time);
        Paint date = textPaint(ink(), Typeface.create("sans-serif", Typeface.BOLD), size * 0.18f, shadow, 0xAA000000);
        date.setTextAlign(Paint.Align.LEFT);
        date.setLetterSpacing(0.14f);
        canvas.drawText(dateShort(cal), left + size * 0.18f, cy + size * 0.55f, date);
    }

    private static int ink() {
        ClockPlacement placement = ACTIVE.get();
        if (placement == null || placement.color == 0) return Color.WHITE;
        return placement.color | 0xFF000000;
    }

    private static Typeface font() {
        ClockPlacement placement = ACTIVE.get();
        return ClockPlacement.typeface(placement == null ? 0 : placement.font);
    }

    private static Paint textPaint(int color, Typeface face, float size, int shadow, int shadowColor) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(color);
        paint.setTypeface(face);
        paint.setTextSize(size);
        paint.setTextAlign(Paint.Align.CENTER);
        applyShadow(paint, shadow, shadowColor);
        return paint;
    }

    private static void applyShadow(Paint paint, int shadow, int shadowColor) {
        if (shadow <= 0) {
            paint.clearShadowLayer();
            return;
        }
        int alpha = Math.min(255, 40 + shadow * 18);
        int color = Color.argb(alpha, Color.red(shadowColor), Color.green(shadowColor), Color.blue(shadowColor));
        paint.setShadowLayer(shadow * 3.2f, 0f, shadow * 1.4f, color);
    }

    private static void drawCentered(Canvas canvas, String text, float cx, float cy, Paint paint) {
        Paint.FontMetrics fm = paint.getFontMetrics();
        float baseline = cy - (fm.ascent + fm.descent) / 2f;
        canvas.drawText(text, cx, baseline, paint);
    }

    private static String hour(Calendar cal, boolean is24) {
        int h = is24 ? cal.get(Calendar.HOUR_OF_DAY) : cal.get(Calendar.HOUR);
        if (!is24 && h == 0) h = 12;
        return String.format(Locale.US, "%02d", h);
    }

    private static String minute(Calendar cal) {
        return String.format(Locale.US, "%02d", cal.get(Calendar.MINUTE));
    }

    private static String second(Calendar cal) {
        return String.format(Locale.US, "%02d", cal.get(Calendar.SECOND));
    }

    private static String timeCompact(Calendar cal, boolean is24) {
        return hour(cal, is24) + minute(cal);
    }

    private static String timeColon(Calendar cal, boolean is24) {
        return hour(cal, is24) + ":" + minute(cal) + ":" + second(cal);
    }

    private static String dateLong(Calendar cal) {
        String raw = new java.text.SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(cal.getTime());
        return raw.toUpperCase(Locale.getDefault());
    }

    private static String dateShort(Calendar cal) {
        String raw = new java.text.SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(cal.getTime());
        return raw.toUpperCase(Locale.getDefault());
    }
}
