package com.wello.wallpaperose.clock;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/**
 * Kadranlı analog saatler. Akrep, yelkovan ve saniye ibresi verilen takvime göre döner.
 */
final class AnalogFaces {

    private static final int[][] MATRIX = {
            {0x0E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0E},
            {0x04, 0x0C, 0x04, 0x04, 0x04, 0x04, 0x0E},
            {0x0E, 0x11, 0x01, 0x02, 0x04, 0x08, 0x1F},
            {0x1F, 0x02, 0x04, 0x02, 0x01, 0x11, 0x0E},
            {0x02, 0x06, 0x0A, 0x12, 0x1F, 0x02, 0x02},
            {0x1F, 0x10, 0x1E, 0x01, 0x01, 0x11, 0x0E},
            {0x06, 0x08, 0x10, 0x1E, 0x11, 0x11, 0x0E},
            {0x1F, 0x01, 0x02, 0x04, 0x08, 0x08, 0x08},
            {0x0E, 0x11, 0x11, 0x0E, 0x11, 0x11, 0x0E},
            {0x0E, 0x11, 0x11, 0x0F, 0x01, 0x02, 0x0C}
    };

    private AnalogFaces() {}

    static void field(Canvas canvas, float cx, float cy, float size, int shadow, int color, Calendar cal) {
        float r = size * 1.08f;
        dial(canvas, cx, cy, r, shadow);
        ticks(canvas, cx, cy, r, size, color, 60, true);
        Paint numeral = text(ink(color), Typeface.create("sans-serif-condensed", Typeface.BOLD), size * 0.26f, shadow);
        for (int n = 1; n <= 12; n++) {
            if (n == 4) continue;
            double a = Math.toRadians(n * 30 - 90);
            float nr = r * 0.64f;
            centered(canvas, String.valueOf(n), cx + (float) Math.cos(a) * nr, cy + (float) Math.sin(a) * nr, numeral);
        }
        hands(canvas, cx, cy, r, size, color, cal, 0.50f, 0.72f, 0.078f, 0.042f);
        double dateAngle = Math.toRadians(30);
        dateWindow(canvas, cx + (float) Math.cos(dateAngle) * r * 0.42f,
                cy + (float) Math.sin(dateAngle) * r * 0.42f, size, color, cal);
    }

    static void sport(Canvas canvas, float cx, float cy, float size, int shadow, int color, Calendar cal) {
        float r = size * 1.08f;
        dial(canvas, cx, cy, r, shadow);
        ticks(canvas, cx, cy, r, size, color, 12, false);
        Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeCap(Paint.Cap.ROUND);
        arc.setStrokeWidth(Math.max(3f, size * 0.045f));
        arc.setColor(secondInk(color));
        RectF oval = new RectF(cx - r * 0.82f, cy - r * 0.82f, cx + r * 0.82f, cy + r * 0.82f);
        canvas.drawArc(oval, 140, 70, false, arc);
        blade(canvas, cx, cy, hourAngle(cal), r * 0.46f, size * 0.11f, size * 0.08f, ink(color));
        blade(canvas, cx, cy, minuteAngle(cal), r * 0.72f, size * 0.07f, size * 0.08f, ink(color));
        blade(canvas, cx, cy, secondAngle(cal), r * 0.78f, size * 0.018f, size * 0.12f, secondInk(color));
        cap(canvas, cx, cy, size * 0.055f, secondInk(color));
        String day = new SimpleDateFormat("EEE", Locale.getDefault()).format(cal.getTime()).toUpperCase(Locale.getDefault());
        String date = String.valueOf(cal.get(Calendar.DAY_OF_MONTH));
        Paint label = text(ink(color), Typeface.create("sans-serif-medium", Typeface.BOLD), size * 0.16f, shadow);
        label.setTextAlign(Paint.Align.LEFT);
        canvas.drawText(day + "  " + date, cx + r * 0.08f, cy + size * 0.05f, label);
    }

    static void gauge(Canvas canvas, float cx, float cy, float size, int shadow, int color, Calendar cal, boolean is24) {
        float r = size * 1.12f;
        dial(canvas, cx, cy, r, shadow);
        ticks(canvas, cx, cy, r, size * 0.7f, color, 60, true);
        Paint numeral = text(ink(color), Typeface.create("sans-serif-condensed", Typeface.BOLD), size * 0.16f, shadow);
        for (int i = 0; i < 12; i++) {
            int value = i == 0 ? 60 : i * 5;
            double a = Math.toRadians(i * 30 - 90);
            float nr = r * 0.78f;
            centered(canvas, String.format(Locale.US, "%02d", value),
                    cx + (float) Math.cos(a) * nr, cy + (float) Math.sin(a) * nr, numeral);
        }
        float w = r * 1.28f;
        float h = r * 0.38f;
        Paint capsule = new Paint(Paint.ANTI_ALIAS_FLAG);
        capsule.setColor(ink(color));
        canvas.drawRoundRect(new RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f), h / 2f, h / 2f, capsule);
        Paint time = text(on(ink(color)), Typeface.create("sans-serif-black", Typeface.BOLD), size * 0.24f, 0);
        centered(canvas, hour(cal, is24) + ":" + minute(cal) + ":" + second(cal), cx, cy, time);
    }

    static void matrix(Canvas canvas, float cx, float cy, float size, int shadow, int color, Calendar cal, boolean is24) {
        float r = size * 1.08f;
        dial(canvas, cx, cy, r, shadow);
        Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
        dot.setColor(withAlpha(ink(color), 70));
        for (int i = 0; i < 48; i++) {
            double a = Math.toRadians(i * 7.5 - 90);
            canvas.drawCircle(cx + (float) Math.cos(a) * r * 0.88f, cy + (float) Math.sin(a) * r * 0.88f, size * 0.012f, dot);
        }
        float dotSize = size * 0.055f;
        String hh = hour(cal, is24);
        String mm = minute(cal);
        float block = dotSize * 1.35f * 12f;
        matrixText(canvas, hh, cx - block / 2f, cy - size * 0.48f, dotSize, ink(color));
        matrixText(canvas, mm, cx - block / 2f, cy + size * 0.02f, dotSize, ink(color));
        Paint side = text(ink(color), Typeface.create("sans-serif", Typeface.BOLD), size * 0.14f, shadow);
        String date = new SimpleDateFormat("MMM d", Locale.getDefault()).format(cal.getTime());
        centered(canvas, date, cx, cy - r * 0.62f, side);
        Paint sec = text(secondInk(color), Typeface.create("monospace", Typeface.BOLD), size * 0.2f, shadow);
        centered(canvas, second(cal), cx, cy + r * 0.62f, sec);
    }

    static void info(Canvas canvas, float cx, float cy, float size, int shadow, int color, Calendar cal, boolean is24) {
        float r = size * 1.08f;
        dial(canvas, cx, cy, r, shadow);
        ticks(canvas, cx, cy, r, size, color, 60, true);
        hands(canvas, cx, cy, r, size, color, cal, 0.48f, 0.70f, 0.05f, 0.028f);
        float bx = cx + r * 0.48f;
        float by = cy;
        Paint badge = new Paint(Paint.ANTI_ALIAS_FLAG);
        badge.setColor(0xFF141418);
        badge.setStyle(Paint.Style.FILL);
        canvas.drawCircle(bx, by, size * 0.28f, badge);
        Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(Math.max(2f, size * 0.012f));
        ring.setColor(ink(color));
        canvas.drawCircle(bx, by, size * 0.28f, ring);
        String month = new SimpleDateFormat("MMM", Locale.getDefault()).format(cal.getTime()).toUpperCase(Locale.getDefault());
        Paint monthPaint = text(ink(color), Typeface.create("sans-serif-medium", Typeface.BOLD), size * 0.11f, 0);
        Paint dayPaint = text(Color.WHITE, Typeface.create("sans-serif-black", Typeface.BOLD), size * 0.18f, 0);
        centered(canvas, month, bx, by - size * 0.08f, monthPaint);
        centered(canvas, String.valueOf(cal.get(Calendar.DAY_OF_MONTH)), bx, by + size * 0.12f, dayPaint);
        Paint digital = text(ink(color), Typeface.create("sans-serif-medium", Typeface.BOLD), size * 0.2f, shadow);
        centered(canvas, hour(cal, is24) + ":" + minute(cal) + ":" + second(cal), cx, cy + r * 0.62f, digital);
    }

    private static void dial(Canvas canvas, float cx, float cy, float r, int shadow) {
        Paint face = new Paint(Paint.ANTI_ALIAS_FLAG);
        face.setShader(new RadialGradient(cx, cy - r * 0.2f, r, 0xFF323238, 0xFF050506, Shader.TileMode.CLAMP));
        if (shadow > 0) face.setShadowLayer(shadow * 2.4f, 0f, shadow * 0.8f, 0xAA000000);
        canvas.drawCircle(cx, cy, r, face);
        Paint bezel = new Paint(Paint.ANTI_ALIAS_FLAG);
        bezel.setStyle(Paint.Style.STROKE);
        bezel.setStrokeWidth(Math.max(3f, r * 0.045f));
        bezel.setColor(0xFFD7D7DC);
        canvas.drawCircle(cx, cy, r * 0.985f, bezel);
        Paint inner = new Paint(Paint.ANTI_ALIAS_FLAG);
        inner.setStyle(Paint.Style.STROKE);
        inner.setStrokeWidth(Math.max(1.5f, r * 0.012f));
        inner.setColor(0x66FFFFFF);
        canvas.drawCircle(cx, cy, r * 0.90f, inner);
    }

    private static void ticks(Canvas canvas, float cx, float cy, float r, float size, int color, int count, boolean fine) {
        Paint tick = new Paint(Paint.ANTI_ALIAS_FLAG);
        tick.setStrokeCap(Paint.Cap.ROUND);
        int step = 360 / Math.max(1, count);
        for (int i = 0; i < count; i++) {
            boolean major = !fine || i % 5 == 0;
            double a = Math.toRadians(i * step - 90);
            float inner = r * (major ? 0.78f : 0.88f);
            float outer = r * 0.95f;
            tick.setStrokeWidth(major ? size * 0.035f : size * 0.012f);
            tick.setColor(major ? ink(color) : withAlpha(ink(color), 150));
            canvas.drawLine(cx + (float) Math.cos(a) * inner, cy + (float) Math.sin(a) * inner,
                    cx + (float) Math.cos(a) * outer, cy + (float) Math.sin(a) * outer, tick);
        }
    }

    private static void hands(Canvas canvas, float cx, float cy, float r, float size, int color, Calendar cal,
                              float hourLen, float minuteLen, float hourW, float minuteW) {
        blade(canvas, cx, cy, hourAngle(cal), r * hourLen, size * hourW, size * 0.07f, ink(color));
        blade(canvas, cx, cy, minuteAngle(cal), r * minuteLen, size * minuteW, size * 0.08f, ink(color));
        blade(canvas, cx, cy, secondAngle(cal), r * 0.82f, Math.max(2f, size * 0.016f), size * 0.14f, secondInk(color));
        cap(canvas, cx, cy, size * 0.05f, secondInk(color));
    }

    private static void blade(Canvas canvas, float cx, float cy, float angleDeg, float length, float width, float tail, int color) {
        canvas.save();
        canvas.rotate(angleDeg + 90f, cx, cy);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(color);
        canvas.drawRoundRect(new RectF(cx - width / 2f, cy - length, cx + width / 2f, cy + tail), width / 2f, width / 2f, paint);
        canvas.restore();
    }

    private static void cap(Canvas canvas, float cx, float cy, float radius, int color) {
        Paint metal = new Paint(Paint.ANTI_ALIAS_FLAG);
        metal.setColor(0xFFE6E6EA);
        canvas.drawCircle(cx, cy, radius, metal);
        Paint pin = new Paint(Paint.ANTI_ALIAS_FLAG);
        pin.setColor(color);
        canvas.drawCircle(cx, cy, radius * 0.45f, pin);
    }

    private static void dateWindow(Canvas canvas, float x, float y, float size, int color, Calendar cal) {
        float w = size * 0.62f;
        float h = size * 0.34f;
        RectF window = new RectF(x - w / 2f, y - h / 2f, x + w / 2f, y + h / 2f);
        Paint box = new Paint(Paint.ANTI_ALIAS_FLAG);
        box.setColor(0xFFF4F4F6);
        canvas.drawRoundRect(window, size * 0.04f, size * 0.04f, box);
        Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(Math.max(1.5f, size * 0.012f));
        border.setColor(ink(color) == Color.WHITE ? 0xFF222226 : ink(color));
        canvas.drawRoundRect(window, size * 0.04f, size * 0.04f, border);
        String day = new SimpleDateFormat("EEE", Locale.getDefault()).format(cal.getTime()).toUpperCase(Locale.getDefault());
        Paint dayPaint = text(0xFF222226, Typeface.create("sans-serif-medium", Typeface.BOLD), size * 0.11f, 0);
        Paint numPaint = text(0xFF111114, Typeface.create("sans-serif-black", Typeface.BOLD), size * 0.2f, 0);
        dayPaint.setTextAlign(Paint.Align.LEFT);
        numPaint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText(day, x - w * 0.42f, y + size * 0.045f, dayPaint);
        canvas.drawText(String.valueOf(cal.get(Calendar.DAY_OF_MONTH)), x + w * 0.02f, y + size * 0.06f, numPaint);
    }

    private static void matrixText(Canvas canvas, String text, float left, float top, float dot, int color) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(color);
        float x = left;
        float step = dot * 1.35f;
        for (int i = 0; i < text.length(); i++) {
            int d = text.charAt(i) - '0';
            if (d < 0 || d > 9) {
                x += step * 6f;
                continue;
            }
            int[] rows = MATRIX[d];
            for (int row = 0; row < rows.length; row++) {
                for (int col = 0; col < 5; col++) {
                    if (((rows[row] >> (4 - col)) & 1) == 1) {
                        canvas.drawCircle(x + col * step, top + row * step, dot * 0.42f, paint);
                    }
                }
            }
            x += step * 6f;
        }
    }

    private static float hourAngle(Calendar cal) {
        return (cal.get(Calendar.HOUR) + cal.get(Calendar.MINUTE) / 60f) * 30f - 90f;
    }

    private static float minuteAngle(Calendar cal) {
        return (cal.get(Calendar.MINUTE) + cal.get(Calendar.SECOND) / 60f) * 6f - 90f;
    }

    private static float secondAngle(Calendar cal) {
        return cal.get(Calendar.SECOND) * 6f - 90f;
    }

    private static String hour(Calendar cal, boolean is24) {
        int h = is24 ? cal.get(Calendar.HOUR_OF_DAY) : cal.get(Calendar.HOUR);
        if (!is24 && h == 0) h = 12;
        return String.format(Locale.US, "%02d", h);
    }

    private static String minute(Calendar cal) {
        return String.format(Locale.US, "%02d", cal.get(Calendar.MINUTE));
    }

    private static String second(Calendar cal) {
        return String.format(Locale.US, "%02d", cal.get(Calendar.SECOND));
    }

    private static int ink(int color) {
        if (color == 0) return Color.WHITE;
        return color | 0xFF000000;
    }

    private static int secondInk(int color) {
        int solid = ink(color);
        if (solid == Color.WHITE) return 0xFFFF5C1C;
        return solid;
    }

    private static int on(int color) {
        double light = 0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color);
        return light > 160 ? 0xFF111114 : Color.WHITE;
    }

    private static int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    private static Paint text(int color, Typeface face, float size, int shadow) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(color);
        paint.setTypeface(face);
        paint.setTextSize(size);
        paint.setTextAlign(Paint.Align.CENTER);
        if (shadow > 0) {
            paint.setShadowLayer(shadow * 2f, 0f, shadow * 0.6f, 0x88000000);
        }
        return paint;
    }

    private static void centered(Canvas canvas, String value, float x, float y, Paint paint) {
        Paint.FontMetrics fm = paint.getFontMetrics();
        canvas.drawText(value, x, y - (fm.ascent + fm.descent) / 2f, paint);
    }
}
