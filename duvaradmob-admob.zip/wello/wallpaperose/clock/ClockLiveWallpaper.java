package com.wello.wallpaperose.clock;

import android.app.Activity;
import android.app.WallpaperInfo;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

import java.io.File;

/**
 * Ana ekranda saati her saniye cihaz saatine göre yeniden çizer.
 * Kilit ekranı durağan resim olduğu için orası dakikalık güncellemeyle akar.
 */
public class ClockLiveWallpaper extends WallpaperService {

    @Override
    public void onCreate() {
        super.onCreate();
        ClockFonts.bind(this);
    }

    @Override
    public Engine onCreateEngine() {
        return new ClockEngine();
    }

    public static boolean isRunning(android.content.Context context) {
        if (context == null) return false;
        try {
            WallpaperInfo info = WallpaperManager.getInstance(context).getWallpaperInfo();
            return info != null && ClockLiveWallpaper.class.getName().equals(info.getComponent().getClassName());
        } catch (Exception ignored) {
            return false;
        }
    }

    public static boolean ask(Activity activity, int flags) {
        if (activity == null || (flags & WallpaperManager.FLAG_SYSTEM) == 0) return false;
        if (isRunning(activity)) return true;
        try {
            Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    new ComponentName(activity, ClockLiveWallpaper.class));
            activity.startActivity(intent);
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    private class ClockEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private Bitmap source;
        private String sourceId;
        private long sourceStamp;
        private final Runnable tick = new Runnable() {
            @Override
            public void run() {
                drawFrame();
                handler.postDelayed(this, 1000);
            }
        };

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            setOffsetNotificationsEnabled(false);
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            handler.removeCallbacks(tick);
            if (visible) handler.post(tick);
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            drawFrame();
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            handler.removeCallbacks(tick);
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onDestroy() {
            handler.removeCallbacks(tick);
            if (source != null) {
                source.recycle();
                source = null;
            }
            super.onDestroy();
        }

        private void reloadSource() {
            String id = ClockStore.activeId(ClockLiveWallpaper.this);
            if (id == null) {
                if (source != null) source.recycle();
                source = null;
                sourceId = null;
                return;
            }
            File file = ClockStore.sourceFile(ClockLiveWallpaper.this, id);
            long stamp = file.lastModified();
            if (id.equals(sourceId) && stamp == sourceStamp && source != null && !source.isRecycled()) return;
            Bitmap decoded = BitmapFactory.decodeFile(file.getAbsolutePath());
            if (source != null && source != decoded) source.recycle();
            source = decoded;
            sourceId = id;
            sourceStamp = stamp;
        }

        private void drawFrame() {
            reloadSource();
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas == null) return;
                String id = ClockStore.activeId(ClockLiveWallpaper.this);
                ClockPlacement placement = ClockStore.effective(ClockLiveWallpaper.this, id);
                if (placement != null) placement.enabled = false;
                ClockComposer.paint(ClockLiveWallpaper.this, canvas, source, placement);
            } catch (Exception ignored) {
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas);
                    } catch (Exception ignored) {
                    }
                }
            }
        }
    }
}
