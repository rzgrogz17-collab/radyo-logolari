package com.wello.wallpaperose.clock;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.wello.wallpaperose.AppConfig;

/** Telefon açılınca kurulmuş saati duvar kağıdına dokunmadan geri getirir. */
public class ClockOverlayBoot extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) return;
        String action = intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action) && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            return;
        }
        if (!AppConfig.CLOCK_ENABLE) {
            ClockStore.releaseScreen(context);
            return;
        }
        if (!ClockStore.isClockOn(context) || !ClockOverlayService.canDraw(context)) return;
        ClockOverlayService.start(context);
    }
}
