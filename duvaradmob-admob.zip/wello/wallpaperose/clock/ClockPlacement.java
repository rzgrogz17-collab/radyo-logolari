package com.wello.wallpaperose.clock;

import android.graphics.Typeface;

/**
 * Seçilen saat modeli, rengi, yazı tipi, ekrandaki yeri, boyutu ve gölge şiddeti.
 * nx/ny 0 ile 1 arasında, saatin merkezidir.
 */
public class ClockPlacement {

    public static final int STYLE_COUNT = 12;
    public static final int FONT_COUNT = 10;
    public static final int[] COLORS = {
            0xFFFFFFFF,
            0xFF00E5FF,
            0xFFFFB020,
            0xFFFF4D6A,
            0xFF39FFB6,
            0xFFB388FF,
            0xFFE7F2FF,
            0xFFFF6A2A
    };

    public int style;
    public int color;
    public int font;
    public float nx;
    public float ny;
    public float scale;
    public int shadow;
    public boolean enabled;

    public ClockPlacement() {
        style = 0;
        color = 0xFFFFFFFF;
        font = 0;
        nx = 0.5f;
        ny = 0.30f;
        scale = 1f;
        shadow = 6;
        enabled = false;
    }

    public boolean digital() {
        return !analog(style);
    }

    public static boolean analog(int style) {
        return style == 5 || style >= 8;
    }

    public static Typeface typeface(int font) {
        return ClockFonts.of(font);
    }

    public ClockPlacement copy() {
        ClockPlacement p = new ClockPlacement();
        p.style = style;
        p.color = color;
        p.font = font;
        p.nx = nx;
        p.ny = ny;
        p.scale = scale;
        p.shadow = shadow;
        p.enabled = enabled;
        return p;
    }
}
