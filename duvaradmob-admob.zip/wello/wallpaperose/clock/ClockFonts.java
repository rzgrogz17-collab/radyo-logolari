package com.wello.wallpaperose.clock;

import android.content.Context;
import android.graphics.Typeface;
import android.util.SparseArray;

import androidx.core.content.res.ResourcesCompat;

import com.wello.wallpaperose.R;

/**
 * Dijital saat yazı tipleri. 0-5 sistem, 6-9 pakete eklenen özel yazı tipleri.
 */
public final class ClockFonts {

    private static Context app;
    private static final SparseArray<Typeface> CUSTOM = new SparseArray<>();

    private ClockFonts() {}

    public static void bind(Context context) {
        if (context != null && app == null) app = context.getApplicationContext();
    }

    public static Typeface of(int index) {
        int font = index;
        if (font < 0 || font >= ClockPlacement.FONT_COUNT) font = 0;
        switch (font) {
            case 1:
                return Typeface.create("sans-serif-black", Typeface.BOLD);
            case 2:
                return Typeface.create("sans-serif-thin", Typeface.NORMAL);
            case 3:
                return Typeface.create("sans-serif-condensed", Typeface.BOLD);
            case 4:
                return Typeface.create("serif", Typeface.NORMAL);
            case 5:
                return Typeface.create("monospace", Typeface.BOLD);
            case 6:
                return bundled(6, R.font.melloida_extra_bold);
            case 7:
                return bundled(7, R.font.digital_7);
            case 8:
                return bundled(8, R.font.nevera_regular);
            case 9:
                return bundled(9, R.font.balgio);
            default:
                return Typeface.create("sans-serif-light", Typeface.NORMAL);
        }
    }

    private static Typeface bundled(int key, int resId) {
        Typeface cached = CUSTOM.get(key);
        if (cached != null) return cached;
        if (app == null) return Typeface.create("sans-serif-black", Typeface.BOLD);
        try {
            Typeface face = ResourcesCompat.getFont(app, resId);
            if (face == null) return Typeface.create("sans-serif-black", Typeface.BOLD);
            CUSTOM.put(key, face);
            return face;
        } catch (Exception ignored) {
            return Typeface.create("sans-serif-black", Typeface.BOLD);
        }
    }
}
