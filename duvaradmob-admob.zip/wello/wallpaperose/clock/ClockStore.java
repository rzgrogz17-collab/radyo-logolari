package com.wello.wallpaperose.clock;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Context;

import com.wello.wallpaperose.AppConfig;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Saat seçimi uygulama genelindedir. Saatli seçildiyse sonraki duvar kağıtları
 * bu saatle kurulur, saatsiz seçildiyse saatsiz kurulur. Galeriden veya başka
 * uygulamadan kurulan duvar kağıdının kimliği bizde kayıtlı değilse üzerine yazılmaz.
 */
public final class ClockStore {

    private static final String PREF = "clock_wallpaper";
    private static final String ACTIVE_ID = "active_id";
    private static final String ACTIVE_FLAGS = "active_flags";
    private static final String GLOBAL = "global_placement";
    private static final String GLOBAL_ON = "global_on";
    private static final String GLOBAL_SET = "global_set";
    private static final String OWN_SYSTEM = "own_system";
    private static final String OWN_LOCK = "own_lock";

    /** Saat, uygulama görselinden bağımsız olarak cihazın ekranına kurulur. */
    public static final String DEVICE_ID = "device_screen";

    private ClockStore() {}

    private static SharedPreferences pref(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static ClockPlacement load(Context context, String wallpaperId) {
        ClockPlacement placement = new ClockPlacement();
        if (wallpaperId == null) return placement;
        return decode(pref(context).getString(key(wallpaperId), null), placement);
    }

    /** Düzenleyicide gösterilecek son saat. Kapalı olsa da son model durur. */
    public static ClockPlacement preferred(Context context, String wallpaperId) {
        String raw = pref(context).getString(GLOBAL, null);
        if (pref(context).getBoolean(GLOBAL_SET, false) && raw != null) {
            return decode(raw, new ClockPlacement());
        }
        return load(context, wallpaperId);
    }

    /**
     * Duvar kağıdı kurulurken kullanılacak saat.
     * Kullanıcı saatli dediyse seçilen saat, saatsiz dediyse kapalıdır.
     */
    public static ClockPlacement effective(Context context, String wallpaperId) {
        if (pref(context).getBoolean(GLOBAL_SET, false)) {
            if (!pref(context).getBoolean(GLOBAL_ON, false)) return new ClockPlacement();
            ClockPlacement placement = decode(pref(context).getString(GLOBAL, null), new ClockPlacement());
            placement.enabled = true;
            return placement;
        }
        return load(context, wallpaperId);
    }

    public static void save(Context context, String wallpaperId, ClockPlacement placement) {
        if (wallpaperId == null || placement == null) return;
        pref(context).edit().putString(key(wallpaperId), encode(placement)).apply();
    }

    public static void rememberChoice(Context context, String wallpaperId, ClockPlacement placement, boolean on) {
        ClockPlacement stored = placement == null ? new ClockPlacement() : placement.copy();
        stored.enabled = on;
        if (wallpaperId != null) save(context, wallpaperId, stored);
        SharedPreferences.Editor editor = pref(context).edit();
        editor.putBoolean(GLOBAL_SET, true);
        editor.putBoolean(GLOBAL_ON, on);
        if (on) editor.putString(GLOBAL, encode(stored));
        editor.apply();
    }

    public static void clear(Context context, String wallpaperId) {
        if (wallpaperId == null) return;
        pref(context).edit().remove(key(wallpaperId)).apply();
        if (wallpaperId.equals(activeId(context))) clearActive(context);
    }

    public static void setActive(Context context, String wallpaperId, int flags) {
        pref(context).edit()
                .putString(ACTIVE_ID, wallpaperId)
                .putInt(ACTIVE_FLAGS, flags)
                .apply();
    }

    public static void clearActive(Context context) {
        pref(context).edit()
                .remove(ACTIVE_ID)
                .remove(ACTIVE_FLAGS)
                .remove(OWN_SYSTEM)
                .remove(OWN_LOCK)
                .apply();
        ClockWallpaperWorker.cancel(context);
    }

    public static String activeId(Context context) {
        return pref(context).getString(ACTIVE_ID, null);
    }

    public static int activeFlags(Context context) {
        return pref(context).getInt(ACTIVE_FLAGS, 0);
    }

    public static void publish(Context context, Bitmap bitmap, int which) throws IOException {
        WallpaperManager manager = WallpaperManager.getInstance(context);
        int id = manager.setBitmap(bitmap, null, true, which);
        if (id == 0) {
            try {
                id = manager.getWallpaperId(which);
            } catch (RuntimeException ignored) {
            }
        }
        SharedPreferences.Editor editor = pref(context).edit();
        if ((which & WallpaperManager.FLAG_SYSTEM) != 0) editor.putInt(OWN_SYSTEM, id);
        if ((which & WallpaperManager.FLAG_LOCK) != 0) editor.putInt(OWN_LOCK, id);
        editor.apply();
    }

    public static boolean stillOurs(Context context, int which) {
        int saved = pref(context).getInt(which == WallpaperManager.FLAG_LOCK ? OWN_LOCK : OWN_SYSTEM, 0);
        if (saved == 0) return false;
        try {
            return WallpaperManager.getInstance(context).getWallpaperId(which) == saved;
        } catch (RuntimeException ignored) {
            return false;
        }
    }

    public static boolean isClockOn(Context context) {
        if (context == null) return false;
        SharedPreferences preferences = pref(context);
        return preferences.getBoolean(GLOBAL_SET, false) && preferences.getBoolean(GLOBAL_ON, false);
    }

    /**
     * Yalnızca saati kurar. Duvar kağıdını değiştirmez, eski saat görselini yeniden basmaz.
     * Saat, ekranın üstünde her saniye akan saydam bir katmandır.
     */
    public static boolean installClockOnly(Activity activity, ClockPlacement placement) {
        if (!AppConfig.CLOCK_ENABLE || activity == null || placement == null) return false;
        if (!ClockOverlayService.canDraw(activity)) {
            ClockOverlayService.requestPermission(activity);
            return false;
        }
        ClockPlacement stored = placement.copy();
        stored.enabled = true;
        SharedPreferences.Editor editor = pref(activity).edit();
        editor.putString(key(DEVICE_ID), encode(stored));
        editor.putBoolean(GLOBAL_SET, true);
        editor.putBoolean(GLOBAL_ON, true);
        editor.putString(GLOBAL, encode(stored));
        editor.putString(ACTIVE_ID, DEVICE_ID);
        editor.putInt(ACTIVE_FLAGS, 0);
        editor.commit();
        ClockWallpaperWorker.cancel(activity);
        ClockOverlayService.start(activity);
        return true;
    }

    /** Canlı saat açıkken yeni görsel yalnızca arka plan olur; saat durmaz. */
    public static void updateLiveBackground(Context context, Bitmap bitmap) {
        if (context == null || bitmap == null) return;
        String id = activeId(context);
        if (id == null) id = DEVICE_ID;
        saveSource(context, id, bitmap);
    }

    public static Bitmap captureHome(Context context) {
        try {
            WallpaperManager manager = WallpaperManager.getInstance(context);
            Drawable drawable = manager.getDrawable();
            if (drawable == null) return null;
            int[] size = ClockComposer.screenSize(context);
            int width = Math.max(1, size[0]);
            int height = Math.max(1, size[1]);
            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, width, height);
            drawable.draw(canvas);
            return bitmap;
        } catch (Exception ignored) {
            return null;
        }
    }

    /** Ekrandaki saati kapatır. Duvar kağıdına dokunmaz. */
    public static void releaseScreen(Context context) {
        if (context == null) return;
        String id = activeId(context);
        ClockPlacement current = preferred(context, id);
        current.enabled = false;
        SharedPreferences.Editor editor = pref(context).edit();
        editor.putBoolean(GLOBAL_SET, true);
        editor.putBoolean(GLOBAL_ON, false);
        editor.putString(GLOBAL, encode(current));
        if (id != null) editor.putString(key(id), encode(current));
        editor.remove(ACTIVE_ID);
        editor.remove(ACTIVE_FLAGS);
        editor.commit();
        ClockWallpaperWorker.cancel(context);
        ClockOverlayService.stop(context);
    }

    public static File sourceFile(Context context, String wallpaperId) {
        File dir = new File(context.getApplicationContext().getFilesDir(), "clock_source");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, wallpaperId.hashCode() + ".jpg");
    }

    public static void saveSource(Context context, String wallpaperId, Bitmap bitmap) {
        if (wallpaperId == null || bitmap == null) return;
        File file = sourceFile(context, wallpaperId);
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out);
        } catch (Exception ignored) {
        } finally {
            if (out != null) {
                try { out.close(); } catch (Exception ignored) {}
            }
        }
    }

    private static String key(String wallpaperId) {
        return "p_" + wallpaperId;
    }

    private static String encode(ClockPlacement placement) {
        return placement.style + "," + placement.nx + "," + placement.ny + "," + placement.scale + ","
                + placement.shadow + "," + (placement.enabled ? "1" : "0") + ","
                + placement.color + "," + placement.font;
    }

    private static ClockPlacement decode(String raw, ClockPlacement fallback) {
        if (raw == null) return fallback;
        String[] parts = raw.split(",");
        if (parts.length < 6) return fallback;
        ClockPlacement placement = new ClockPlacement();
        try {
            placement.style = clampStyle(Integer.parseInt(parts[0]));
            placement.nx = clamp01(Float.parseFloat(parts[1]));
            placement.ny = clamp01(Float.parseFloat(parts[2]));
            placement.scale = clampScale(Float.parseFloat(parts[3]));
            placement.shadow = clampShadow(Integer.parseInt(parts[4]));
            placement.enabled = "1".equals(parts[5]);
            if (parts.length >= 8) {
                placement.color = Integer.parseInt(parts[6]);
                placement.font = clampFont(Integer.parseInt(parts[7]));
            }
        } catch (Exception ignored) {
            return new ClockPlacement();
        }
        return placement;
    }

    static int clampStyle(int style) {
        if (style < 0) return 0;
        if (style >= ClockPlacement.STYLE_COUNT) return ClockPlacement.STYLE_COUNT - 1;
        return style;
    }

    static float clamp01(float v) {
        return Math.max(0.08f, Math.min(0.92f, v));
    }

    static float clampScale(float v) {
        return Math.max(0.45f, Math.min(2.4f, v));
    }

    static int clampShadow(int v) {
        return Math.max(0, Math.min(12, v));
    }

    static int clampFont(int v) {
        if (v < 0) return 0;
        if (v >= ClockPlacement.FONT_COUNT) return ClockPlacement.FONT_COUNT - 1;
        return v;
    }
}
