package com.wello.wallpaperose.clock;

import android.app.WallpaperInfo;
import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import androidx.annotation.NonNull;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.io.File;
import java.util.concurrent.TimeUnit;

/**
 * Canlı duvar kağıdı yoksa ana ekranı, kilit ekranını ise her durumda
 * yaklaşık dakikada bir cihaz saatiyle yeniler. Ana ekrandaki saniye akışı
 * ClockLiveWallpaper içindedir; bu iş o yüzeyi statik resimle değiştirmez.
 */
public class ClockWallpaperWorker extends Worker {

    static final String WORK_NAME = "clock_wallpaper_tick";

    public ClockWallpaperWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    public static void schedule(Context context) {
        if (ClockStore.activeId(context) == null) return;
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(ClockWallpaperWorker.class)
                .setInitialDelay(60, TimeUnit.SECONDS)
                .build();
        WorkManager.getInstance(context).enqueueUniqueWork(WORK_NAME, ExistingWorkPolicy.REPLACE, request);
    }

    public static void cancel(Context context) {
        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME);
    }

    private static boolean ourLive(WallpaperManager manager) {
        try {
            WallpaperInfo info = manager.getWallpaperInfo();
            return info != null && ClockLiveWallpaper.class.getName().equals(info.getComponent().getClassName());
        } catch (Exception ignored) {
            return false;
        }
    }

    @NonNull
    @Override
    public Result doWork() {
        Context context = getApplicationContext();
        String id = ClockStore.activeId(context);
        if (id == null) return Result.success();
        WallpaperManager manager = WallpaperManager.getInstance(context);
        if (ClockStore.DEVICE_ID.equals(id) || ourLive(manager)) {
            return Result.success();
        }
        ClockPlacement placement = ClockStore.effective(context, id);
        if (!placement.enabled) {
            return Result.success();
        }
        boolean live = ourLive(manager);
        int flags = ClockStore.activeFlags(context);
        int next = flags;
        if ((flags & WallpaperManager.FLAG_SYSTEM) != 0 && !live
                && !ClockStore.stillOurs(context, WallpaperManager.FLAG_SYSTEM)) {
            next &= ~WallpaperManager.FLAG_SYSTEM;
        }
        if ((flags & WallpaperManager.FLAG_LOCK) != 0
                && !ClockStore.stillOurs(context, WallpaperManager.FLAG_LOCK)) {
            next &= ~WallpaperManager.FLAG_LOCK;
        }
        if (next == 0) {
            ClockStore.clearActive(context);
            return Result.success();
        }
        if (next != flags) ClockStore.setActive(context, id, next);
        File source = ClockStore.sourceFile(context, id);
        Bitmap original = BitmapFactory.decodeFile(source.getAbsolutePath());
        if (original == null) {
            schedule(context);
            return Result.success();
        }
        Bitmap framed = null;
        try {
            framed = ClockComposer.frame(context, original, placement);
            if ((next & WallpaperManager.FLAG_SYSTEM) != 0 && !live) {
                ClockStore.publish(context, framed, WallpaperManager.FLAG_SYSTEM);
            }
            if ((next & WallpaperManager.FLAG_LOCK) != 0) {
                ClockStore.publish(context, framed, WallpaperManager.FLAG_LOCK);
            }
        } catch (Exception ignored) {
        } finally {
            if (original != null && original != framed) original.recycle();
            if (framed != null && framed != original) framed.recycle();
        }
        schedule(context);
        return Result.success();
    }
}
