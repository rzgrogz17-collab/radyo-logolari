package com.wello.wallpaperose.clock;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.text.format.DateFormat;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.util.Calendar;

/**
 * Önizlemede saati çizer. Tek parmakla taşınır, iki parmakla büyür ve küçülür.
 */
public class ClockOverlayView extends View {

    public interface Listener {
        void onPlacementChanged(ClockPlacement placement);
    }

    private ClockPlacement placement = new ClockPlacement();
    private Listener listener;
    private final ScaleGestureDetector scaleDetector;
    private boolean dragging;
    private float lastX;
    private float lastY;
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            invalidate();
            postDelayed(this, 1000);
        }
    };

    public ClockOverlayView(Context context) {
        this(context, null);
    }

    public ClockOverlayView(Context context, AttributeSet attrs) {
        super(context, attrs);
        ClockFonts.bind(context);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                placement.scale = ClockStore.clampScale(placement.scale * detector.getScaleFactor());
                notifyChanged();
                invalidate();
                return true;
            }
        });
    }

    public void setPlacement(ClockPlacement placement) {
        this.placement = placement == null ? new ClockPlacement() : placement;
        invalidate();
    }

    public ClockPlacement getPlacement() {
        return placement;
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        removeCallbacks(tick);
        post(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(tick);
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        ClockPainter.draw(canvas, placement, getWidth(), getHeight(), Calendar.getInstance(), DateFormat.is24HourFormat(getContext()));
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        if (scaleDetector.isInProgress()) {
            dragging = false;
            return true;
        }
        float x = event.getX();
        float y = event.getY();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dragging = nearClock(x, y);
                lastX = x;
                lastY = y;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragging && getWidth() > 0 && getHeight() > 0) {
                    placement.nx = ClockStore.clamp01(placement.nx + (x - lastX) / getWidth());
                    placement.ny = ClockStore.clamp01(placement.ny + (y - lastY) / getHeight());
                    lastX = x;
                    lastY = y;
                    notifyChanged();
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                return true;
            default:
                return true;
        }
    }

    private boolean nearClock(float x, float y) {
        float cx = placement.nx * getWidth();
        float cy = placement.ny * getHeight();
        float reach = getWidth() * 0.28f * placement.scale;
        float dx = x - cx;
        float dy = y - cy;
        return dx * dx + dy * dy <= reach * reach;
    }

    private void notifyChanged() {
        if (listener != null) listener.onPlacementChanged(placement);
    }

    /** Stil şeridindeki küçük önizleme. */
    public static class Chip extends View {
        private final ClockPlacement placement = new ClockPlacement();
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);

        public Chip(Context context) {
            super(context);
            setLayerType(LAYER_TYPE_SOFTWARE, null);
            placement.nx = 0.5f;
            placement.ny = 0.48f;
            placement.scale = 0.72f;
            placement.shadow = 2;
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(3f);
        }

        public void bind(int style, int color, int font, boolean selected) {
            placement.style = style;
            placement.color = color;
            placement.font = font;
            placement.scale = ClockPlacement.analog(style) ? 2.05f : 0.78f;
            placement.ny = 0.5f;
            ring.setColor(selected ? Color.parseColor("#00E5FF") : Color.parseColor("#33FFFFFF"));
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            canvas.drawColor(Color.parseColor("#CC10141C"));
            ClockPainter.draw(canvas, placement, getWidth(), getHeight(), Calendar.getInstance(), true);
            canvas.drawRoundRect(2, 2, getWidth() - 2, getHeight() - 2, 18f, 18f, ring);
        }
    }
}
