package com.wello.wallpaperose.clock;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.text.format.DateFormat;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

import androidx.core.app.NotificationCompat;

import com.wello.wallpaperose.AppConfig;
import com.wello.wallpaperose.R;

import java.util.Calendar;

/**
 * Saati duvar kağıdına basmadan, ekranın üstünde her saniye çizer.
 * Duvar kağıdı değişse de saat aynı yerde kalır.
 */
public class ClockOverlayService extends Service {

    private static final String CHANNEL = "aurawall_clock";
    private static final int NOTIF = 7041;
    private static volatile boolean running;
    private static volatile ClockOverlayService instance;

    private WindowManager windowManager;
    private View clockView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (clockView != null) clockView.invalidate();
            handler.postDelayed(this, 1000);
        }
    };

    public static boolean isRunning() {
        return running;
    }

    public static boolean canDraw(Context context) {
        if (context == null) return false;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        return Settings.canDrawOverlays(context);
    }

    public static void requestPermission(Activity activity) {
        if (activity == null) return;
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + activity.getPackageName()));
            activity.startActivity(intent);
        } catch (Exception ignored) {
        }
    }

    public static void start(Context context) {
        if (context == null) return;
        Context app = context.getApplicationContext();
        Intent intent = new Intent(app, ClockOverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            app.startForegroundService(intent);
        } else {
            app.startService(intent);
        }
    }

    public static void stop(Context context) {
        if (context == null) return;
        context.getApplicationContext().stopService(new Intent(context.getApplicationContext(), ClockOverlayService.class));
    }

    /** Saat düzenlenirken ekrandaki saati gizler; kayıtlı saati silmez. */
    public static void setShown(boolean shown) {
        ClockOverlayService service = instance;
        if (service == null) return;
        service.handler.post(() -> {
            if (service.clockView != null) {
                service.clockView.setVisibility(shown ? View.VISIBLE : View.GONE);
            }
        });
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        ClockFonts.bind(this);
        instance = this;
        running = true;
        startInForeground();
        if (!AppConfig.CLOCK_ENABLE) {
            stopSelf();
            return;
        }
        attach();
        handler.post(tick);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        running = true;
        startInForeground();
        if (!AppConfig.CLOCK_ENABLE) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (clockView == null) attach();
        else clockView.invalidate();
        handler.removeCallbacks(tick);
        handler.post(tick);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        running = false;
        handler.removeCallbacks(tick);
        detach();
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }

    private void startInForeground() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && manager != null) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Saat", NotificationManager.IMPORTANCE_MIN);
            channel.setSound(null, null);
            channel.enableVibration(false);
            channel.setShowBadge(false);
            manager.createNotificationChannel(channel);
        }
        Notification notification = new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_clock_menu)
                .setContentTitle("Saat çalışıyor")
                .setOngoing(true)
                .setSilent(true)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF, notification);
        }
    }

    private void attach() {
        if (clockView != null) return;
        if (!canDraw(this)) {
            stopSelf();
            return;
        }
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (windowManager == null) {
            stopSelf();
            return;
        }
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        int windowFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                windowFlags,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        clockView = new ClockLayer(this);
        try {
            windowManager.addView(clockView, params);
        } catch (Exception ignored) {
            clockView = null;
            stopSelf();
        }
    }

    private void detach() {
        if (windowManager != null && clockView != null) {
            try {
                windowManager.removeView(clockView);
            } catch (Exception ignored) {
            }
        }
        clockView = null;
    }

    private static final class ClockLayer extends View {
        ClockLayer(Context context) {
            super(context);
            setWillNotDraw(false);
            setBackgroundColor(0);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            int width = getWidth();
            int height = getHeight();
            if (width <= 0 || height <= 0) return;
            ClockPlacement placement = ClockStore.effective(getContext(), ClockStore.DEVICE_ID);
            if (placement == null || !placement.enabled) return;
            ClockPainter.draw(canvas, placement, width, height, Calendar.getInstance(),
                    DateFormat.is24HourFormat(getContext()));
        }
    }
}
