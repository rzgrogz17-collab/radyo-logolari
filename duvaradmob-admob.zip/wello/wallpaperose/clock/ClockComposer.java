package com.wello.wallpaperose.clock;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.RectF;
import android.text.format.DateFormat;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.util.Calendar;

/**
 * Duvar kağıdını ekran oranında keser ve kayıtlı saati üstüne işler.
 */
public final class ClockComposer {

    private ClockComposer() {}

    public static int[] screenSize(Context context) {
        DisplayMetrics dm = new DisplayMetrics();
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        if (wm != null) {
            wm.getDefaultDisplay().getRealMetrics(dm);
        } else {
            dm = context.getResources().getDisplayMetrics();
        }
        int w = Math.max(1, dm.widthPixels);
        int h = Math.max(1, dm.heightPixels);
        return new int[]{w, h};
    }

    public static Bitmap frame(Context context, Bitmap source, ClockPlacement placement) {
        int[] size = screenSize(context);
        return frame(context, source, placement, size[0], size[1]);
    }

    public static Bitmap frame(Context context, Bitmap source, ClockPlacement placement, int outW, int outH) {
        if (source == null) return null;
        Bitmap out = Bitmap.createBitmap(Math.max(1, outW), Math.max(1, outH), Bitmap.Config.ARGB_8888);
        paint(context, new Canvas(out), source, placement);
        return out;
    }

    public static void paint(Context context, Canvas canvas, Bitmap source, ClockPlacement placement) {
        ClockFonts.bind(context);
        canvas.drawColor(Color.BLACK);
        if (source != null && source.getWidth() > 0 && source.getHeight() > 0 && canvas.getWidth() > 0 && canvas.getHeight() > 0) {
            float scale = Math.max(canvas.getWidth() / (float) source.getWidth(), canvas.getHeight() / (float) source.getHeight());
            float dw = source.getWidth() * scale;
            float dh = source.getHeight() * scale;
            float left = (canvas.getWidth() - dw) / 2f;
            float top = (canvas.getHeight() - dh) / 2f;
            canvas.drawBitmap(source, null, new RectF(left, top, left + dw, top + dh), null);
        }
        if (placement != null && placement.enabled && canvas.getWidth() > 0 && canvas.getHeight() > 0) {
            ClockPainter.draw(canvas, placement, canvas.getWidth(), canvas.getHeight(), Calendar.getInstance(), DateFormat.is24HourFormat(context));
        }
    }

    public static Bitmap drawOn(Context context, Bitmap source, ClockPlacement placement) {
        if (source == null) return null;
        if (placement == null || !placement.enabled) return source;
        Bitmap out = source.copy(Bitmap.Config.ARGB_8888, true);
        if (out == null) return source;
        ClockPainter.draw(new Canvas(out), placement, out.getWidth(), out.getHeight(), Calendar.getInstance(), DateFormat.is24HourFormat(context));
        return out;
    }
}
