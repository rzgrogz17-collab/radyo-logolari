package com.wello.wallpaperose.utils;


import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.text.Html;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.URLUtil;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.browser.customtabs.CustomTabColorSchemeParams;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.content.FileProvider;
import androidx.core.content.res.ResourcesCompat;
import androidx.multidex.BuildConfig;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.wello.wallpaperose.AppConfig;

import com.wello.wallpaperose.R;
import com.wello.wallpaperose.activity.ActivitySplash;
import com.wello.wallpaperose.activity.ActivityWebView;
import com.wello.wallpaperose.data.ThisApp;
import com.wello.wallpaperose.model.Wallpaper;
import com.wello.wallpaperose.room.table.NotificationEntity;
import com.wello.wallpaperose.worker.AutoWallpaperWorker;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DecodeFormat;
import com.bumptech.glide.load.MultiTransformation;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.RequestBuilder;
import jp.wasabeef.glide.transformations.BlurTransformation;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.InstallStateUpdatedListener;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.InstallStatus;
import com.google.android.play.core.install.model.UpdateAvailability;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import dreamspace.blogger.sdk.model.Listing;

public class Tools {

    public static boolean needRequestPermission() {
        return (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1);
    }

    public static void RTLMode(Window window) {
        if (AppConfig.RTL_LAYOUT) {
            window.getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        }
    }

    public static void darkNavigation(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            activity.getWindow().setNavigationBarColor(Color.BLACK);
            activity.getWindow().setStatusBarColor(Color.BLACK);
            activity.getWindow().getDecorView().setSystemUiVisibility(0);
        }
    }

    public static void restartApp(Activity activity) {
        activity.finishAffinity();
        activity.startActivity(new Intent(activity, ActivitySplash.class));
    }

    public static Wallpaper parseListingToWallpaper(Listing listing) {
        Document htmlData = Jsoup.parse(listing.content);

        Wallpaper p = new Wallpaper();
        p.id = listing.id;
        p.type = listing.type;
        p.title = listing.title;
        p.published = listing.published;
        p.updated = listing.updated;
        p.content = listing.content;
        p.link = listing.link;
        p.images = Tools.findImagesFromContent(htmlData);
        p.premiums = Tools.findPremiumFromContent(htmlData);
        p.multiple = p.images.size() > 1;

        Element e = htmlData.select("img").first();
        if (e != null && e.hasAttr("src")) {
            p.image = e.attr("src");
            p.premium = e.hasAttr("alt") && e.attr("alt").equalsIgnoreCase("premium");
        } else {
            p.image = null;
        }

        p.category = listing.category;
        return p;
    }

    public static List<String> findImagesFromContent(Document htmlData) {
        List<String> images = new ArrayList<>();
        Elements elements = htmlData.select("img");
        for (Element e : elements) {
            if (e.hasAttr("src")) {
                images.add(e.attr("src"));
            }
        }
        return images;
    }

    public static List<Boolean> findPremiumFromContent(Document htmlData) {
        List<Boolean> premiums = new ArrayList<>();
        Elements elements = htmlData.select("img");
        for (Element e : elements) {
            premiums.add(e.hasAttr("alt") && e.attr("alt").equalsIgnoreCase("premium"));
        }
        return premiums;
    }

    public static boolean checkMultipleImages(String content) {
        if (TextUtils.isEmpty(content)) return false;
        Document htmlData = Jsoup.parse(content);
        Elements elements = htmlData.select("img");
        return elements.size() > 1;
    }

    public static void fullScreen(Activity activity) {
        Window w = activity.getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    public static void displayImage(Context ctx, ImageView img, String url) {
        try {
            // crossFade/blur kaldırıldı — resim direkt açılır
            Glide.with(ctx.getApplicationContext()).load(url)
                    .error(R.drawable.bg_splash_instant)
                    .diskCacheStrategy(ThisApp.pref().getImageCache() ? DiskCacheStrategy.ALL : DiskCacheStrategy.NONE)
                    .into(img);
        } catch (Exception e) {
            Log.e("tag", "error img => " + e.getMessage());
        }
    }

    // YENİ: Ana Sayfa / Favoriler ızgarasındaki (grid) her hücre küçük bir
    // önizleme olduğu halde, üstteki displayImage() orijinal (yüksek
    // çözünürlüklü) duvar kağıdını olduğu gibi belleğe alıyordu. Kaydırma
    // sırasında her hücre için bu ağır decode/bellek işi, parmakla yukarı
    // aşağı sürüklerken hissedilen takılmanın (jank) asıl kaynağıydı.
    // Bu metot SADECE ızgara hücreleri için kullanılır: RGB_565 formatı
    // (yarı bellek) ve centerCrop ile görsel, hücre boyutuna göre daha
    // hafif decode edilir. displayImage()/displayImageThumb() hiç
    // değişmedi — tam ekran önizleme ve diğer ekranlardaki görsel kalitesi
    // aynı kalıyor.
    //
    // gridImageRequest() burada ayrı bir metoda çıkarıldı ki hem ekrana
    // basarken (into) hem de arka planda önceden indirirken (preload,
    // aşağıya bakın) BİREBİR AYNI ayarlar kullanılsın. Glide'ın disk
    // önbellek anahtarı bu ayarlara (boyut dahil) göre hesaplandığı için,
    // hedef genişlik/yükseklik açıkça (override) verilmezse preload'un
    // hedef ImageView'ı olmadığından Glide orijinal boyutu indirmeye
    // çalışır ve önbellek anahtarı gerçek gösterimle eşleşmez — yani
    // prefetch boşa gider. Bunu önlemek için ızgara hücresinin gerçek
    // piksel boyutu hesaplanıp ikisinde de aynen kullanılıyor.
    private static RequestBuilder<Drawable> gridImageRequest(Context ctx, String url) {
        int cellWidth = gridCellWidthPx(ctx);
        int cellHeight = gridCellHeightPx(ctx);
        RequestBuilder<Drawable> request = Glide.with(ctx.getApplicationContext()).load(url)
                .error(R.drawable.bg_splash_instant)
                .diskCacheStrategy(ThisApp.pref().getImageCache() ? DiskCacheStrategy.ALL : DiskCacheStrategy.NONE)
                .format(DecodeFormat.PREFER_RGB_565)
                .centerCrop();
        if (cellWidth > 0 && cellHeight > 0) {
            request = request.override(cellWidth, cellHeight);
        }
        return request;
    }

    // item_listing.xml'deki ızgara hücresi genişliği: ekran genişliği /
    // sütun sayısı (getGridSpanCount() ile aynı hesap, Activity gerekmez).
    private static int gridCellWidthPx(Context ctx) {
        float listingWidth = ctx.getResources().getDimension(R.dimen.listing_width);
        if (listingWidth <= 0) return 0;
        int spanCount = Math.max(1, Math.round(getScreenWidth() / listingWidth));
        return getScreenWidth() / spanCount;
    }

    // item_listing.xml'deki kart oranı "H,9:14" (genişlik:yükseklik = 9:14).
    private static int gridCellHeightPx(Context ctx) {
        int width = gridCellWidthPx(ctx);
        return width <= 0 ? 0 : Math.round(width * (14f / 9f));
    }

    public static void displayImageGrid(Context ctx, ImageView img, String url) {
        try {
            gridImageRequest(ctx, url).into(img);
        } catch (Exception e) {
            Log.e("tag", "error img => " + e.getMessage());
        }
    }

    // YENİ: Ana Sayfa'da her yeni sayfa ağdan (blogger API) geldiğinde,
    // kullanıcı henüz o hücrelere kaydırmamışken görselleri arka planda
    // indirip diskte hazır hale getirmek için kullanılır (prefetch).
    // Kullanıcı gerçekten o hücreye kaydırdığında displayImageGrid() aynı
    // önbellekten okur, ağ beklemesi yaşanmaz — Favoriler'de zaten hep
    // olan "önbellekten anında yükleme" hissi Ana Sayfa'ya da taşınmış
    // olur. into() çağrısı olmadığı için bir ImageView gerektirmez ve
    // hiçbir ekranı bloklamaz, tamamen arka planda çalışır.
    public static void preloadGridImages(Context ctx, List<String> urls) {
        if (ctx == null || urls == null) return;
        for (String url : urls) {
            if (url == null || url.isEmpty()) continue;
            try {
                gridImageRequest(ctx, url).preload();
            } catch (Exception e) {
                Log.e("tag", "error preload => " + e.getMessage());
            }
        }
    }

    public static void displayImageThumb(Context ctx, ImageView img, String url, float thumb) {
        try {
            // crossFade/blur/thumbnail kaldırıldı — resim direkt açılır
            Glide.with(ctx.getApplicationContext()).load(url)
                    .diskCacheStrategy(ThisApp.pref().getImageCache() ? DiskCacheStrategy.ALL : DiskCacheStrategy.NONE)
                    .into(img);
        } catch (Exception e) {
            Log.e("tag", "error img => " + e.getMessage());
        }
    }

    public static void changeMenuIconColor(Menu menu, @ColorInt int color) {
        for (int i = 0; i < menu.size(); i++) {
            Drawable drawable = menu.getItem(i).getIcon();
            if (drawable == null) continue;
            drawable.mutate();
            drawable.setColorFilter(color, PorterDuff.Mode.SRC_ATOP);
        }
    }

    public static void changeOverflowMenuIconColor(Toolbar toolbar, @ColorInt int color) {
        try {
            Drawable drawable = toolbar.getOverflowIcon();
            drawable.mutate();
            drawable.setColorFilter(color, PorterDuff.Mode.SRC_ATOP);
        } catch (Exception e) {
        }
    }

    public static boolean isConnect(Context context) {
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            if (activeNetworkInfo != null) {
                if (activeNetworkInfo.isConnected() || activeNetworkInfo.isConnectedOrConnecting()) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (Exception e) {
            return false;
        }
    }

    public static int getStatusBarHeight(Context context) {
        int height;
        Resources myResources = context.getResources();
        int idStatusBarHeight = myResources.getIdentifier("status_bar_height", "dimen", "android");
        if (idStatusBarHeight > 0) {
            height = context.getResources().getDimensionPixelSize(idStatusBarHeight);
        } else {
            height = 0;
        }
        return height;
    }

    public static String getFormattedDateSimple(Long dateTime) {
        SimpleDateFormat newFormat = new SimpleDateFormat("dd MMM yy hh:mm");
        return newFormat.format(new Date(dateTime));
    }

    public static void rateAction(Activity activity) {
        String general_market_android = AppConfig.general.non_playstore_market_android;
        if (TextUtils.isEmpty(general_market_android)) {
            activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID)));
        } else {
            Tools.directLinkCustomTab(activity, general_market_android);
        }
    }

    public static void checkNotification(Activity activity) {
        NotificationEntity notification = ThisApp.get().getNotification();
        if (notification == null) return;

        if (!TextUtils.isEmpty(notification.link)) {
            Tools.directLinkCustomTab(activity, notification.link);
        }

        ThisApp.get().setNotification(null);
    }

    public static String getHostName(String url) {
        try {
            URI uri = new URI(url);
            String new_url = uri.getHost();
            if (!new_url.startsWith("www.")) new_url = "www." + new_url;
            return new_url;
        } catch (URISyntaxException e) {
            e.printStackTrace();
            return url;
        }
    }

    public static int dpToPx(Context c, int dp) {
        Resources r = c.getResources();
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, r.getDisplayMetrics()));
    }

    public static int getGridSpanCount(Activity activity) {
        Display display = activity.getWindowManager().getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        display.getMetrics(displayMetrics);
        float screenWidth = displayMetrics.widthPixels;
        float cellWidth = activity.getResources().getDimension(R.dimen.listing_width);
        return Math.round(screenWidth / cellWidth);
    }

    public static void directLinkCustomTab(Activity activity, String url) {
        if (!URLUtil.isValidUrl(url)) {
            Toast.makeText(activity, "Ops, Cannot open url", Toast.LENGTH_LONG).show();
            return;
        }
        if (!AppConfig.general.open_link_in_app) {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            activity.startActivity(browserIntent);
            return;
        }
        int color = ResourcesCompat.getColor(activity.getResources(), R.color.primary, null);
        int secondaryColor = ResourcesCompat.getColor(activity.getResources(), R.color.accent, null);

        CustomTabsIntent.Builder intentBuilder = new CustomTabsIntent.Builder();
        CustomTabColorSchemeParams defaultColors = new CustomTabColorSchemeParams.Builder()
                .setToolbarColor(color)
                .setSecondaryToolbarColor(secondaryColor)
                .build();
        intentBuilder.setDefaultColorSchemeParams(defaultColors);
        intentBuilder.setShowTitle(true);
        intentBuilder.setUrlBarHidingEnabled(true);

        CustomTabsHelper.openCustomTab(activity, intentBuilder.build(), Uri.parse(url), (activity1, uri) -> {
            ActivityWebView.navigate(activity1, uri.toString());
        });
    }

    public static void hideKeyboard(Activity activity) {
        View view = activity.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    public static int getScreenWidth() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    public static void goToNotificationSettings(Activity activity) {
        Intent intent = new Intent();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            intent.setAction(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, BuildConfig.APPLICATION_ID);
        } else {
            intent.setAction("android.settings.APP_NOTIFICATION_SETTINGS");
            intent.putExtra("app_package", BuildConfig.APPLICATION_ID);
            intent.putExtra("app_uid", activity.getApplicationInfo().uid);
        }
        activity.startActivity(intent);
    }

    public static void aboutAction(Activity activity) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle(activity.getString(R.string.dialog_about_title));
        builder.setMessage(Html.fromHtml(activity.getString(R.string.about_text)));
        builder.setPositiveButton("OK", null);
        GlassDialog.show(builder.create());
    }

    public static void applyTheme(boolean dark) {
        if (dark) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }

    // YENİ: Cihazın kendi yerel saatine göre şu an "gece" mi diye bakar.
    // 07:30 - 18:30 arası gündüz, bu aralığın dışı gece kabul edilir.
    // Calendar.getInstance() cihazın o an bulunduğu saat dilimini kullandığı
    // için, uygulama hangi ülkede/saat diliminde açılırsa oranın yerel
    // saatine göre doğru sonucu verir.
    private static final int DAY_START_MINUTES = 7 * 60 + 30;    // 07:30
    private static final int NIGHT_START_MINUTES = 18 * 60 + 30; // 18:30

    public static boolean isNightTimeNow() {
        Calendar now = Calendar.getInstance();
        int nowMinutes = (now.get(Calendar.HOUR_OF_DAY) * 60) + now.get(Calendar.MINUTE);
        return (nowMinutes < DAY_START_MINUTES) || (nowMinutes >= NIGHT_START_MINUTES);
    }

    // YENİ: Otomatik mod açıksa cihazın saatine göre, kapalıysa kullanıcının
    // ayarlardan elle seçtiği tercihe göre temayı uygular. Uygulama her
    // açıldığında (ThisApp.onCreate) buradan çağrılır.
    public static void applyAutoOrManualTheme() {
        if (ThisApp.pref().isAutoTheme()) {
            applyTheme(isNightTimeNow());
        } else {
            applyTheme(ThisApp.pref().isDarkTheme());
        }
    }

    private static AppUpdateManager appUpdateManager;
    private static InstallStateUpdatedListener installStateUpdatedListener;

    public static void checkGooglePlayUpdateStopListener() {
        if (appUpdateManager != null)
            appUpdateManager.unregisterListener(installStateUpdatedListener);
    }

    public static void checkGooglePlayUpdate(Activity activity) {
        if (BuildConfig.DEBUG) return;
        installStateUpdatedListener = state -> {
            if (state.installStatus() == InstallStatus.DOWNLOADED) {
                Snackbar snackbar = Snackbar.make(activity.findViewById(android.R.id.content), R.string.update_ready, Snackbar.LENGTH_INDEFINITE);
                snackbar.setAction(R.string.install, view -> {
                    if (appUpdateManager != null) appUpdateManager.completeUpdate();
                });
                snackbar.show();
            } else if (state.installStatus() == InstallStatus.INSTALLED) {
                if (appUpdateManager != null && installStateUpdatedListener != null) {
                    appUpdateManager.unregisterListener(installStateUpdatedListener);
                }
            } else {

            }
        };

        appUpdateManager = AppUpdateManagerFactory.create(activity);
        Task<AppUpdateInfo> appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();
        appUpdateManager.registerListener(installStateUpdatedListener);
        appUpdateInfoTask.addOnSuccessListener(appUpdateInfo -> {
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE && appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)) {
                try {
                    appUpdateManager.startUpdateFlowForResult(appUpdateInfo, AppUpdateType.FLEXIBLE, activity, 200);
                } catch (IntentSender.SendIntentException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public static void showToastCenter(Context ctx, @StringRes int res_id) {
        Toast toast = Toast.makeText(ctx, ctx.getResources().getString(res_id), Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
    }

    public static void methodShare(AppCompatActivity act, File file) {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("image/jpeg");
        share.putExtra(Intent.EXTRA_TITLE, act.getString(R.string.app_name));
        share.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file));

        // FIX: BuildConfig.APPLICATION_ID yerine getPackageName() kullanıyoruz.
        // BuildConfig.APPLICATION_ID yanlış bir import nedeniyle "androidx.multidex"
        // değerini döndürüyordu, bu da manifest'teki gerçek provider authority'si
        // ile eşleşmiyordu ve FileProvider.getUriForFile() çöküyordu.
        String authority = act.getPackageName() + ".provider";
        Uri uri = FileProvider.getUriForFile(act, authority, file);

        share.setClipData(ClipData.newUri(act.getContentResolver(), act.getString(R.string.app_name), uri));
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        share.putExtra(Intent.EXTRA_TEXT, act.getString(R.string.app_name) + " : " + "http://play.google.com/store/apps/details?id=" + act.getPackageName());
        act.startActivity(Intent.createChooser(share, "Share"));
    }

    // YENİ: Detay ekranında ana resmin arkasında görünen, aynı resmin
    // bulanıklaştırılmış hâli. Resmin en-boy oranı ekranı tam doldurmadığı
    // anlarda (yüklenirken vb.) düz renk yerine bu görünür.
    public static void applyFrost(Context ctx, final ImageView image, final View colorWash, String url) {
        if (ctx == null || url == null) return;
        try {
            if (image != null) {
                Glide.with(ctx).load(url)
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .apply(RequestOptions.bitmapTransform(
                                new MultiTransformation<>(new CenterCrop(), new BlurTransformation(24, 4))))
                        .into(image);
            }
            Glide.with(ctx).asBitmap().load(url).override(48, 48).into(new CustomTarget<Bitmap>() {
                @Override
                public void onResourceReady(@NonNull Bitmap bitmap, @Nullable Transition<? super Bitmap> transition) {
                    if (colorWash == null) return;
                    int color = averageColor(bitmap);
                    int top = Color.argb(90, Color.red(color), Color.green(color), Color.blue(color));
                    int bottom = Color.argb(120,
                            Math.max(0, Color.red(color) - 40),
                            Math.max(0, Color.green(color) - 40),
                            Math.max(0, Color.blue(color) - 40));
                    android.graphics.drawable.GradientDrawable wash = new android.graphics.drawable.GradientDrawable(
                            android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                            new int[]{top, bottom});
                    colorWash.setBackground(wash);
                }

                @Override
                public void onLoadCleared(@Nullable Drawable placeholder) {}
            });
        } catch (Exception e) {
            Log.e("tag", "error frost => " + e.getMessage());
        }
    }

    private static int averageColor(Bitmap bitmap) {
        long r = 0, g = 0, b = 0, n = 0;
        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        for (int y = 0; y < h; y += 2) {
            for (int x = 0; x < w; x += 2) {
                int c = bitmap.getPixel(x, y);
                r += Color.red(c);
                g += Color.green(c);
                b += Color.blue(c);
                n++;
            }
        }
        if (n == 0) return Color.DKGRAY;
        return Color.rgb((int) (r / n), (int) (g / n), (int) (b / n));
    }

    public static void displayBlurredBackground(Context ctx, final ImageView img, String url) {
        try {
            Glide.with(ctx).load(url)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .apply(RequestOptions.bitmapTransform(
                            new MultiTransformation<>(new CenterCrop(), new BlurTransformation(20, 3))))
                    .into(img);
        } catch (Exception e) {
            Log.e("tag", "error blur bg => " + e.getMessage());
        }
    }

    // YENİ: Favori ekleme/çıkarma, indirme tamamlanma gibi anlarda kısa bir
    // dokunsal (haptic) geri bildirim verir. Cihazda titreşim yoksa sessizce geçer.
    public static void vibrate(Context context, long milliseconds) {
        try {
            Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator == null || !vibrator.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(milliseconds, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(milliseconds);
            }
        } catch (Exception ignored) {
        }
    }

    // YENİ: Otomatik Duvar Kağıdı Değiştirici — WorkManager ile günlük/haftalık planlama.
    // Kullanıcı Ayarlar'dan açtığında çağrılır; favorilerden rastgele seçip
    // ana ekrana uygulayan AutoWallpaperWorker'ı periyodik olarak tetikler.
    private static final String AUTO_WALLPAPER_WORK_TAG = "auto_wallpaper_worker";

    public static void scheduleAutoWallpaper(Context context, boolean weekly) {
        long intervalDays = weekly ? 7 : 1;
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                .build();
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(
                AutoWallpaperWorker.class, intervalDays, TimeUnit.DAYS)
                .setConstraints(constraints)
                .build();
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                AUTO_WALLPAPER_WORK_TAG, ExistingPeriodicWorkPolicy.REPLACE, request);
    }

    public static void cancelAutoWallpaper(Context context) {
        WorkManager.getInstance(context).cancelUniqueWork(AUTO_WALLPAPER_WORK_TAG);
    }

    public static void displayImageWallpaperDetails(Context ctx, final ImageView img, String url) {
        try {
            // blur/thumbnail kaldırıldı — resim direkt tam kalitede açılır
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            Glide.with(ctx).asBitmap().load(url)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(new CustomTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(@NonNull Bitmap bitmap,
                                @Nullable Transition<? super Bitmap> transition) {
                            img.setImageBitmap(bitmap);
                            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
                        }
                        @Override public void onLoadCleared(@Nullable Drawable placeholder) {}
                        @Override public void onLoadFailed(@Nullable Drawable errorDrawable) {
                            super.onLoadFailed(errorDrawable);
                        }
                    });
        } catch (Exception e) {
            Log.e("tag", "error detail img => " + e.getMessage());
        }
    }

    public static void clearImageCacheOnBackground(final Context ctx) {
        try {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Glide.get(ctx).clearDiskCache();
                }
            }).start();
        } catch (Exception e) {
        }
    }

    private static long getDirSize(File dir) {
        long size = 0;
        for (File file : dir.listFiles()) {
            if (file != null && file.isDirectory()) {
                size += getDirSize(file);
            } else if (file != null && file.isFile()) {
                size += file.length();
            }
        }
        return size;
    }

    public static String getImageCacheSize(Context context) {
        long size = getDirSize(context.getCacheDir());
        if (context.getExternalCacheDir() != null) {
            size = size + getDirSize(context.getExternalCacheDir());
        }
        if (size <= 0) {
            return "0 Bytes";
        }
        String[] units = new String[]{"Bytes", "KB", "MB", "GB", "TB"};
        int digitGroups = (int) (Math.log10((double) size) / Math.log10(1024.0d));
        StringBuilder stringBuilder = new StringBuilder();
        DecimalFormat decimalFormat = new DecimalFormat("#,##0.#");
        double d = (double) size;
        double pow = Math.pow(1024.0d, (double) digitGroups);
        Double.isNaN(d);
        stringBuilder.append(decimalFormat.format(d / pow));
        stringBuilder.append(" ");
        stringBuilder.append(units[digitGroups]);
        return stringBuilder.toString();
    }
}
