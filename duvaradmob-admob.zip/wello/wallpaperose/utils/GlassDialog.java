package com.wello.wallpaperose.utils;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import com.wello.wallpaperose.R;

/**
 * Cikis penceresi haric tum uyarilar ayni cam gorunumunu kullanir.
 * Dugme isleri ve metinler degismez.
 */
public final class GlassDialog {

    private GlassDialog() {}

    public static void apply(AlertDialog dialog) {
        if (dialog == null) return;
        try {
            Window window = dialog.getWindow();
            if (window != null) {
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(Color.parseColor("#E6141A2E"));
                bg.setCornerRadius(TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_DIP, 24,
                        dialog.getContext().getResources().getDisplayMetrics()));
                bg.setStroke((int) TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_DIP, 1,
                        dialog.getContext().getResources().getDisplayMetrics()),
                        Color.parseColor("#33FFFFFF"));
                window.setBackgroundDrawable(bg);
                int screenW = dialog.getContext().getResources().getDisplayMetrics().widthPixels;
                int targetW = (int) Math.min(screenW * 0.86f,
                        dialog.getContext().getResources().getDisplayMetrics().density * 340);
                window.setLayout(targetW, android.view.WindowManager.LayoutParams.WRAP_CONTENT);
            }
            TextView titleView = findTitle(dialog);
            TextView messageView = dialog.findViewById(android.R.id.message);
            paintTitle(titleView);
            if (window != null) {
                window.getDecorView().post(() -> paintTitle(findTitle(dialog)));
            }
            if (messageView != null) {
                messageView.setTextColor(Color.parseColor("#D6DEE8"));
                messageView.setTextSize(15f);
            }
            Button pos = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            Button neg = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
            Button neu = dialog.getButton(AlertDialog.BUTTON_NEUTRAL);
            if (pos != null) {
                pos.setTextColor(Color.parseColor("#00E5FF"));
                pos.setAllCaps(false);
            }
            if (neg != null) {
                neg.setTextColor(Color.parseColor("#FF8A80"));
                neg.setAllCaps(false);
            }
            if (neu != null) {
                neu.setTextColor(Color.WHITE);
                neu.setAllCaps(false);
            }
        } catch (Exception ignored) {
        }
    }

    private static TextView findTitle(AlertDialog dialog) {
        TextView titleView = dialog.findViewById(androidx.appcompat.R.id.alertTitle);
        if (titleView == null) {
            int titleId = dialog.getContext().getResources().getIdentifier("alertTitle", "id", "android");
            if (titleId > 0) titleView = dialog.findViewById(titleId);
        }
        return titleView;
    }

    private static void paintTitle(TextView titleView) {
        if (titleView == null) return;
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(17f);
    }

    public static void show(AlertDialog dialog) {
        if (dialog == null) return;
        dialog.show();
        apply(dialog);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog_glass);
        }
    }
}
