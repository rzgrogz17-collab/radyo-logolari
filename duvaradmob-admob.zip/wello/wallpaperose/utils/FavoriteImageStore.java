package com.wello.wallpaperose.utils;

import android.content.Context;
import android.graphics.Bitmap;

import java.io.File;
import java.io.FileOutputStream;

/**
 * Odullu indirme veya kaydetme basarili olunca resmin uygulama klasorundeki kopyasi.
 * Kalp tek basina dosya yazmaz. Favoriden cikinca kopya silinir.
 */
public final class FavoriteImageStore {

    private FavoriteImageStore() {}

    private static File dir(Context context) {
        File folder = new File(context.getApplicationContext().getFilesDir(), "favorite_wallpapers");
        if (!folder.exists()) folder.mkdirs();
        return folder;
    }

    public static File file(Context context, String id) {
        String name = String.valueOf(id == null ? "none" : id.hashCode()) + ".jpg";
        return new File(dir(context), name);
    }

    public static boolean has(Context context, String id) {
        File f = file(context, id);
        return f.exists() && f.length() > 0;
    }

    public static void save(Context context, String id, Bitmap bitmap) {
        if (context == null || id == null || bitmap == null) return;
        File dest = file(context, id);
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(dest);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out);
            out.flush();
        } catch (Exception ignored) {
        } finally {
            if (out != null) {
                try { out.close(); } catch (Exception ignored) {}
            }
        }
    }

    public static void delete(Context context, String id) {
        File f = file(context, id);
        if (f.exists()) f.delete();
    }
}
