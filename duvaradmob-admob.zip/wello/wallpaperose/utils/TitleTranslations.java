package com.wello.wallpaperose.utils;

import android.text.TextUtils;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Kart basligini cihaz dilinde gosterir. Blog istegi orijinal baslikla kalir. */
public final class TitleTranslations {

    private static final String[] LANGS = {"en","zh","hi","es","fr","ar","bn","pt","ru","ja","de","ko","tr","vi","it","id","th","pl","uk","nl"};
    private static final Map<String, String[]> MAP = new HashMap<>();

    static {
        MAP.put("BOKEH", new String[]{"Bokeh","散景","बोकेह","Bokeh","Bokeh","بوكيه","বোকেহ","Bokeh","Боке","ボケ","Bokeh","보케","Bokeh","Bokeh","Bokeh","Bokeh","โบเก้","Bokeh","Боке","Bokeh"});
        MAP.put("ABSTRACT", new String[]{"Abstract","抽象","अमूर्त","Abstracto","Abstrait","تجريدي","বিমূর্ত","Abstrato","Абстракция","抽象","Abstrakt","추상","Soyut","Trừu tượng","Astratto","Abstrak","นามธรรม","Abstrakcja","Абстракція","Abstract"});
        MAP.put("AMOLED", new String[]{"AMOLED","AMOLED","AMOLED","AMOLED","AMOLED","AMOLED","AMOLED","AMOLED","AMOLED","AMOLED","AMOLED","AMOLED","AMOLED","AMOLED","AMOLED","AMOLED","AMOLED","AMOLED","AMOLED","AMOLED"});
        MAP.put("DANGER", new String[]{"Danger","危险","खतरा","Peligro","Danger","خطر","বিপদ","Perigo","Опасность","危険","Gefahr","위험","Tehlike","Nguy hiểm","Pericolo","Bahaya","อันตราย","Niebezpieczeństwo","Небезпека","Gevaar"});
        MAP.put("SPACE", new String[]{"Space","太空","अंतरिक्ष","Espacio","Espace","فضاء","মহাকাশ","Espaço","Космос","宇宙","Weltraum","우주","Uzay","Vũ trụ","Spazio","Luar angkasa","อวกาศ","Kosmos","Космос","Ruimte"});
        MAP.put("VEHICLES", new String[]{"Vehicles","车辆","वाहन","Vehículos","Véhicules","مركبات","যানবাহন","Veículos","Транспорт","乗り物","Fahrzeuge","탈것","Taşıtlar","Phương tiện","Veicoli","Kendaraan","ยานพาหนะ","Pojazdy","Транспорт","Voertuigen"});
        MAP.put("NEON", new String[]{"Neon","霓虹","नियॉन","Neón","Néon","نيون","নিয়ন","Neon","Неон","ネオン","Neon","네온","Neon","Neon","Neon","Neon","นีออน","Neon","Неон","Neon"});
        MAP.put("MOTIVATION", new String[]{"Motivation","励志","प्रेरणा","Motivación","Motivation","تحفيز","অনুপ্রেরণা","Motivação","Мотивация","モチベーション","Motivation","동기부여","Motivasyon","Động lực","Motivazione","Motivasi","แรงบันดาลใจ","Motywacja","Мотивація","Motivatie"});
        MAP.put("AIRCRAFTS", new String[]{"Aircraft","飞机","विमान","Aviones","Avions","طائرات","বিমান","Aeronaves","Самолёты","航空機","Flugzeuge","항공기","Uçaklar","Máy bay","Aerei","Pesawat","อากาศยาน","Samoloty","Літаки","Vliegtuigen"});
        MAP.put("ANIMALS", new String[]{"Animals","动物","जानवर","Animales","Animaux","حيوانات","প্রাণী","Animais","Животные","動物","Tiere","동물","Hayvanlar","Động vật","Animali","Hewan","สัตว์","Zwierzęta","Тварини","Dieren"});
        MAP.put("FLOWERS", new String[]{"Flowers","花朵","फूल","Flores","Fleurs","زهور","ফুল","Flores","Цветы","花","Blumen","꽃","Çiçekler","Hoa","Fiori","Bunga","ดอกไม้","Kwiaty","Квіти","Bloemen"});
        MAP.put("SUNSET", new String[]{"Sunset","日落","सूर्यास्त","Atardecer","Coucher de soleil","غروب","সূর্যাস্ত","Pôr do sol","Закат","夕焼け","Sonnenuntergang","노을","Gün batımı","Hoàng hôn","Tramonto","Matahari terbenam","พระอาทิตย์ตก","Zachód słońca","Захід сонця","Zonsondergang"});
        MAP.put("FLORA", new String[]{"Flora","植物","वनस्पति","Flora","Flore","نباتات","উদ্ভিদ","Flora","Флора","植物","Flora","식물","Bitki örtüsü","Thực vật","Flora","Flora","พรรณพืช","Flora","Флора","Flora"});
        MAP.put("MASK BOYS", new String[]{"Mask Boys","面具男孩","मुखौटा लड़के","Chicos con máscara","Garçons masqués","فتيان مقنعون","মুখোশধারী ছেলেরা","Garotos de máscara","Парни в масках","マスクの少年","Maskierte Jungs","마스크 소년","Maskeli çocuklar","Cậu bé đeo mặt nạ","Ragazzi in maschera","Anak bertopeng","เด็กชายใส่หน้ากาก","Chłopcy w maskach","Хлопці в масках","Jongens met masker"});
        MAP.put("NATURE", new String[]{"Nature","自然","प्रकृति","Naturaleza","Nature","طبيعة","প্রকৃতি","Natureza","Природа","自然","Natur","자연","Doğa","Thiên nhiên","Natura","Alam","ธรรมชาติ","Natura","Природа","Natuur"});
        MAP.put("ANIME", new String[]{"Anime","动漫","एनीमे","Anime","Anime","أنمي","অ্যানিমে","Anime","Аниме","アニメ","Anime","애니","Anime","Anime","Anime","Anime","อนิเมะ","Anime","Аніме","Anime"});
        MAP.put("SEA", new String[]{"Sea","大海","समुद्र","Mar","Mer","بحر","সমুদ্র","Mar","Море","海","Meer","바다","Deniz","Biển","Mare","Laut","ทะเล","Morze","Море","Zee"});
        MAP.put("MINIMALIST", new String[]{"Minimalist","极简","न्यूनतम","Minimalista","Minimaliste","بسيط","মিনিমালিস্ট","Minimalista","Минимализм","ミニマル","Minimalistisch","미니멀","Minimalist","Tối giản","Minimalista","Minimalis","มินิมอล","Minimalizm","Мінімалізм","Minimalistisch"});
        MAP.put("AIR BALLOON", new String[]{"Air Balloon","热气球","हवा का गुब्बारा","Globo","Montgolfière","منطاد","বেলুন","Balão","Воздушный шар","気球","Heißluftballon","열기구","Uçan balon","Khinh khí cầu","Mongolfiera","Balon udara","บอลลูน","Balon","Повітряна куля","Luchtballon"});
        MAP.put("MOTORBIKE", new String[]{"Motorbike","摩托车","मोटरबाइक","Moto","Moto","دراجة نارية","মোটরবাইক","Motocicleta","Мотоцикл","バイク","Motorrad","오토바이","Motosiklet","Xe máy","Moto","Motor","มอเตอร์ไซค์","Motocykl","Мотоцикл","Motor"});
        MAP.put("OCEAN", new String[]{"Ocean","海洋","महासागर","Océano","Océan","محيط","মহাসাগর","Oceano","Океан","海洋","Ozean","바다","Okyanus","Đại dương","Oceano","Samudra","มหาสมุทร","Ocean","Океан","Oceaan"});
        MAP.put("STUFF SWEET", new String[]{"Sweet Stuff","甜食","मिठाई","Dulces","Douceurs","حلويات","মিষ্টি","Doces","Сладости","スイーツ","Süßes","디저트","Tatlılar","Đồ ngọt","Dolci","Manisan","ของหวาน","Słodycze","Солодощі","Snoep"});
        MAP.put("JOKER", new String[]{"Joker","小丑","जोकर","Joker","Joker","الجوكر","জোকার","Coringa","Джокер","ジョーカー","Joker","조커","Joker","Joker","Joker","Joker","โจ๊กเกอร์","Joker","Джокер","Joker"});
        MAP.put("BLACK", new String[]{"Black","黑色","काला","Negro","Noir","أسود","কালো","Preto","Чёрный","黒","Schwarz","검정","Siyah","Đen","Nero","Hitam","สีดำ","Czarny","Чорний","Zwart"});
        MAP.put("RAIN", new String[]{"Rain","雨","बारिश","Lluvia","Pluie","مطر","বৃষ্টি","Chuva","Дождь","雨","Regen","비","Yağmur","Mưa","Pioggia","Hujan","ฝน","Deszcz","Дощ","Regen"});
        MAP.put("CARTOON", new String[]{"Cartoon","卡通","कार्टून","Dibujos","Dessin animé","كرتون","কার্টুন","Desenho","Мультфильм","漫画","Cartoon","만화","Çizgi film","Hoạt hình","Cartone","Kartun","การ์ตูน","Kreskówka","Мультфільм","Cartoon"});
        MAP.put("ASTRONOT", new String[]{"Astronaut","宇航员","अंतरिक्ष यात्री","Astronauta","Astronaute","رائد فضاء","মহাকাশচারী","Astronauta","Космонавт","宇宙飛行士","Astronaut","우주비행사","Astronot","Phi hành gia","Astronauta","Astronot","นักบินอวกาศ","Astronauta","Космонавт","Astronaut"});
        MAP.put("Blue Arts", new String[]{"Blue Arts","蓝色艺术","नीली कला","Arte azul","Art bleu","فن أزرق","নীল শিল্প","Arte azul","Синее искусство","青いアート","Blaue Kunst","푸른 예술","Mavi sanat","Nghệ thuật xanh","Arte blu","Seni biru","ศิลปะสีน้ำเงิน","Niebieska sztuka","Синє мистецтво","Blauwe kunst"});
        MAP.put("CITY", new String[]{"City","城市","शहर","Ciudad","Ville","مدينة","শহর","Cidade","Город","街","Stadt","도시","Şehir","Thành phố","Città","Kota","เมือง","Miasto","Місто","Stad"});
        MAP.put("ARCHITECTURAL", new String[]{"Architecture","建筑","वास्तुकला","Arquitectura","Architecture","عمارة","স্থাপত্য","Arquitetura","Архитектура","建築","Architektur","건축","Mimari","Kiến trúc","Architettura","Arsitektur","สถาปัตยกรรม","Architektura","Архітектура","Architectuur"});
        MAP.put("MUSIC", new String[]{"Music","音乐","संगीत","Música","Musique","موسيقى","সঙ্গীত","Música","Музыка","音楽","Musik","음악","Müzik","Âm nhạc","Musica","Musik","ดนตรี","Muzyka","Музика","Muziek"});
        MAP.put("MOUNTAIN", new String[]{"Mountain","山","पहाड़","Montaña","Montagne","جبل","পর্বত","Montanha","Гора","山","Berg","산","Dağ","Núi","Montagna","Gunung","ภูเขา","Góra","Гора","Berg"});
        MAP.put("FOOTBALL", new String[]{"Football","足球","फुटबॉल","Fútbol","Football","كرة القدم","ফুটবল","Futebol","Футбол","サッカー","Fußball","축구","Futbol","Bóng đá","Calcio","Sepak bola","ฟุตบอล","Piłka nożna","Футбол","Voetbal"});
        MAP.put("CATS", new String[]{"Cats","猫","बिल्लियाँ","Gatos","Chats","قطط","বিড়াল","Gatos","Кошки","猫","Katzen","고양이","Kediler","Mèo","Gatti","Kucing","แมว","Koty","Коти","Katten"});
        MAP.put("Good Vibes", new String[]{"Good Vibes","好心情","अच्छे वाइब्स","Buenas vibras","Bonnes ondes","أجواء جميلة","ভালো অনুভূতি","Boas vibrações","Хорошее настроение","良い気分","Gute Stimmung","좋은 분위기","İyi hisler","Năng lượng tốt","Belle vibrazioni","Suasana baik","ความรู้สึกดี","Dobre wibracje","Гарний настрій","Goede vibe"});
        MAP.put("FIRE", new String[]{"Fire","火","आग","Fuego","Feu","نار","আগুন","Fogo","Огонь","火","Feuer","불","Ateş","Lửa","Fuoco","Api","ไฟ","Ogień","Вогонь","Vuur"});
        MAP.put("CLOUDS", new String[]{"Clouds","云","बादल","Nubes","Nuages","غيوم","মেঘ","Nuvens","Облака","雲","Wolken","구름","Bulutlar","Mây","Nuvole","Awan","เมฆ","Chmury","Хмари","Wolken"});
        MAP.put("BUTTERFLY", new String[]{"Butterfly","蝴蝶","तितली","Mariposa","Papillon","فراشة","প্রজাপতি","Borboleta","Бабочка","蝶","Schmetterling","나비","Kelebek","Bướm","Farfalla","Kupu-kupu","ผีเสื้อ","Motyl","Метелик","Vlinder"});
        MAP.put("PUBG MOBİLE", new String[]{"PUBG Mobile","PUBG Mobile","PUBG Mobile","PUBG Mobile","PUBG Mobile","PUBG Mobile","PUBG Mobile","PUBG Mobile","PUBG Mobile","PUBG Mobile","PUBG Mobile","PUBG Mobile","PUBG Mobile","PUBG Mobile","PUBG Mobile","PUBG Mobile","PUBG Mobile","PUBG Mobile","PUBG Mobile","PUBG Mobile"});
        MAP.put("RAADS", new String[]{"Roads","道路","सड़कें","Caminos","Routes","طرق","রাস্তা","Estradas","Дороги","道路","Straßen","도로","Yollar","Đường","Strade","Jalan","ถนน","Drogi","Дороги","Wegen"});
    }

    private TitleTranslations() {}

    public static String display(String original) {
        if (TextUtils.isEmpty(original)) return original;
        String[] row = MAP.get(original);
        if (row == null) return original;
        String lang = Locale.getDefault().getLanguage();
        if ("in".equals(lang)) lang = "id";
        if ("iw".equals(lang)) lang = "he";
        for (int i = 0; i < LANGS.length; i++) {
            if (LANGS[i].equals(lang)) return row[i];
        }
        return row[0];
    }
}
