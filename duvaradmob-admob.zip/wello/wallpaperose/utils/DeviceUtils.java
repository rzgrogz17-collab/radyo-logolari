package com.wello.wallpaperose.utils;

import android.content.Context;

/**
 * Reklam ağı seçimi için cihaz kontrolü.
 * Huawei, Honor ve HMS artık reklam ağı olarak kullanılmaz.
 * {@link #isHuaweiDevice(Context)} her zaman false döner; çağıran taraf AdMob kullanır.
 */
public class DeviceUtils {

    private DeviceUtils() {}

    /**
     * @return her zaman false. Huawei / Petal reklam yolu kapalıdır.
     */
    public static boolean isHuaweiDevice(Context context) {
        return false;
    }

    public static void clearCache() {
    }
}
