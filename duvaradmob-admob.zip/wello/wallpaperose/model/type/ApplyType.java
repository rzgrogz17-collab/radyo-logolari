package com.wello.wallpaperose.model.type;

import java.io.Serializable;

public enum ApplyType implements Serializable {
    HOME,
    LOCK,
    BOTH
}
