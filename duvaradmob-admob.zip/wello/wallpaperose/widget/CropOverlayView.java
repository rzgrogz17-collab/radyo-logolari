package com.wello.wallpaperose.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * YENİ: Kullanıcının bir duvar kağıdının hangi bölgesini kırpıp kullanacağını
 * seçebilmesi için basit, dışa bağımlılık gerektirmeyen bir kırpma çerçevesi.
 * <p>
 * - Çerçevenin içine dokunup sürüklemek çerçeveyi taşır.
 * - Dört köşesinden birine yakın dokunup sürüklemek o köşeden yeniden boyutlandırır.
 * - Çerçeve dışı hafifçe karartılır, üçe bölünmüş (rule of thirds) rehber
 *   çizgiler gösterilir.
 */
public class CropOverlayView extends View {

    private static final int NONE = 0;
    private static final int MOVE = 1;
    private static final int RESIZE_TL = 2;
    private static final int RESIZE_TR = 3;
    private static final int RESIZE_BL = 4;
    private static final int RESIZE_BR = 5;

    private RectF cropRect;
    private Paint dimPaint;
    private Paint borderPaint;
    private Paint handlePaint;
    private Paint gridPaint;

    private float lastTouchX, lastTouchY;
    private int dragMode = NONE;

    private float handleTouchRadius;
    private float minCropSize;
    private float handleRadius;

    public CropOverlayView(Context context) {
        super(context);
        init();
    }

    public CropOverlayView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CropOverlayView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        float density = getResources().getDisplayMetrics().density;
        handleTouchRadius = 28f * density;
        minCropSize = 80f * density;
        handleRadius = 6f * density;

        dimPaint = new Paint();
        dimPaint.setColor(0xAA000000);

        borderPaint = new Paint();
        borderPaint.setColor(Color.WHITE);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(2.5f * density);
        borderPaint.setAntiAlias(true);

        handlePaint = new Paint();
        handlePaint.setColor(Color.WHITE);
        handlePaint.setStyle(Paint.Style.FILL);
        handlePaint.setAntiAlias(true);

        gridPaint = new Paint();
        gridPaint.setColor(0x66FFFFFF);
        gridPaint.setStrokeWidth(1f * density);

        setWillNotDraw(false);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w == 0 || h == 0) return;
        // Varsayılan çerçeve: ekranın ortasında, duvar kağıdına uygun dikey bir alan
        float marginX = w * 0.08f;
        float top = h * 0.12f;
        float bottom = h * 0.88f;
        cropRect = new RectF(marginX, top, w - marginX, bottom);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (cropRect == null) return;

        canvas.drawRect(0, 0, getWidth(), cropRect.top, dimPaint);
        canvas.drawRect(0, cropRect.bottom, getWidth(), getHeight(), dimPaint);
        canvas.drawRect(0, cropRect.top, cropRect.left, cropRect.bottom, dimPaint);
        canvas.drawRect(cropRect.right, cropRect.top, getWidth(), cropRect.bottom, dimPaint);

        canvas.drawRect(cropRect, borderPaint);

        float w3 = cropRect.width() / 3f;
        float h3 = cropRect.height() / 3f;
        canvas.drawLine(cropRect.left + w3, cropRect.top, cropRect.left + w3, cropRect.bottom, gridPaint);
        canvas.drawLine(cropRect.left + 2 * w3, cropRect.top, cropRect.left + 2 * w3, cropRect.bottom, gridPaint);
        canvas.drawLine(cropRect.left, cropRect.top + h3, cropRect.right, cropRect.top + h3, gridPaint);
        canvas.drawLine(cropRect.left, cropRect.top + 2 * h3, cropRect.right, cropRect.top + 2 * h3, gridPaint);

        canvas.drawCircle(cropRect.left, cropRect.top, handleRadius, handlePaint);
        canvas.drawCircle(cropRect.right, cropRect.top, handleRadius, handlePaint);
        canvas.drawCircle(cropRect.left, cropRect.bottom, handleRadius, handlePaint);
        canvas.drawCircle(cropRect.right, cropRect.bottom, handleRadius, handlePaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (cropRect == null) return false;
        float x = event.getX();
        float y = event.getY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                dragMode = detectDragMode(x, y);
                lastTouchX = x;
                lastTouchY = y;
                return dragMode != NONE;

            case MotionEvent.ACTION_MOVE:
                if (dragMode == NONE) return false;
                float dx = x - lastTouchX;
                float dy = y - lastTouchY;
                applyDrag(dragMode, dx, dy);
                lastTouchX = x;
                lastTouchY = y;
                invalidate();
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragMode = NONE;
                return true;
        }
        return super.onTouchEvent(event);
    }

    private int detectDragMode(float x, float y) {
        if (near(x, cropRect.left) && near(y, cropRect.top)) return RESIZE_TL;
        if (near(x, cropRect.right) && near(y, cropRect.top)) return RESIZE_TR;
        if (near(x, cropRect.left) && near(y, cropRect.bottom)) return RESIZE_BL;
        if (near(x, cropRect.right) && near(y, cropRect.bottom)) return RESIZE_BR;
        if (cropRect.contains(x, y)) return MOVE;
        return NONE;
    }

    private boolean near(float a, float b) {
        return Math.abs(a - b) <= handleTouchRadius;
    }

    private void applyDrag(int mode, float dx, float dy) {
        switch (mode) {
            case MOVE:
                cropRect.offset(dx, dy);
                clampMove();
                break;
            case RESIZE_TL:
                if (cropRect.width() - dx > minCropSize) cropRect.left += dx;
                if (cropRect.height() - dy > minCropSize) cropRect.top += dy;
                clampBounds();
                break;
            case RESIZE_TR:
                if (cropRect.width() + dx > minCropSize) cropRect.right += dx;
                if (cropRect.height() - dy > minCropSize) cropRect.top += dy;
                clampBounds();
                break;
            case RESIZE_BL:
                if (cropRect.width() - dx > minCropSize) cropRect.left += dx;
                if (cropRect.height() + dy > minCropSize) cropRect.bottom += dy;
                clampBounds();
                break;
            case RESIZE_BR:
                if (cropRect.width() + dx > minCropSize) cropRect.right += dx;
                if (cropRect.height() + dy > minCropSize) cropRect.bottom += dy;
                clampBounds();
                break;
            default:
                break;
        }
    }

    private void clampMove() {
        if (cropRect.left < 0) cropRect.offset(-cropRect.left, 0);
        if (cropRect.top < 0) cropRect.offset(0, -cropRect.top);
        if (cropRect.right > getWidth()) cropRect.offset(getWidth() - cropRect.right, 0);
        if (cropRect.bottom > getHeight()) cropRect.offset(0, getHeight() - cropRect.bottom);
    }

    private void clampBounds() {
        cropRect.left = Math.max(0, cropRect.left);
        cropRect.top = Math.max(0, cropRect.top);
        cropRect.right = Math.min(getWidth(), cropRect.right);
        cropRect.bottom = Math.min(getHeight(), cropRect.bottom);
    }

    /** Bu view'ın kendi yerel koordinatlarında (px) geçerli kırpma dikdörtgeni. */
    public RectF getCropRect() {
        return cropRect;
    }
}
