package com.wello.wallpaperose.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;

import androidx.viewpager2.widget.ViewPager2;

/**
 * YENİ: Ana Sayfa <-> Favoriler arasındaki ViewPager2, varsayılan haliyle
 * hafif çapraz (dikey harekete de sahip) parmak hareketlerini bile yatay
 * sayfa geçişi sanıp yanlışlıkla sekme değiştirebiliyordu. Bunun nedeni,
 * ViewPager2'nin kendi içindeki (özel/erişilemeyen) RecyclerView'ın, bir
 * dokunuşu yatay kaydırma olarak yakalarken sadece yatay hareketin (dx)
 * dokunuş eşiğini (touch slop) geçip geçmediğine bakması, aynı anda ne
 * kadar dikey hareket (dy) olduğunu HİÇ hesaba katmamasıdır. Bu yüzden az
 * miktarda yatay bileşeni olan çapraz bir dokunuş bile sayfa değiştirebiliyordu.
 * <p>
 * ViewPager2 sınıfı "final" olduğundan alt sınıf oluşturup bu davranışı
 * doğrudan değiştirmek mümkün değil. Bunun yerine bu sınıf, ViewPager2'yi
 * bir üst seviyeden sarmalar: her dokunuşun en başında (touch slop aşılır
 * aşılmaz) hareketin yatay mı yoksa dikey/çapraz mı olduğuna KENDİSİ karar
 * verir ve ViewPager2'nin herkese açık, resmi {@link ViewPager2#setUserInputEnabled}
 * metoduyla sayfa geçişini o dokunuş süresince açar/kapatır:
 * - Yatay baskınsa (neredeyse düz bir "yatay çizgi"): sayfa geçişi açılır,
 *   ViewPager2 normal şekilde çalışır.
 * - Dikey/çapraz ise: sayfa geçişi o dokunuş boyunca kapatılır; dokunuş
 *   olduğu gibi ViewPager2'nin içinden geçip altındaki listeye (RecyclerView)
 *   ulaşır ve liste normal şekilde dikey kaydırılabilir.
 * <p>
 * Bu katmanın kendisi dokunuşu asla yakalamaz (onInterceptTouchEvent her
 * zaman false döner); sadece yukarıdaki bayrağı ayarlar ve olayın normal
 * akışına devam etmesine izin verir.
 */
public class SwipeAxisGestureLayout extends FrameLayout {

    // Bir hareketin "yatay" sayılması için yatay bileşenin (dx) dikey
    // bileşene (dy) göre en az bu kat kadar baskın olması gerekir.
    // 2.0 kabaca yataydan +-26 derece sapmaya izin verir; bunun altındaki
    // (daha çapraz/dikey) hareketler sayfa geçişini tetiklemez.
    private static final float HORIZONTAL_DOMINANCE_RATIO = 2.0f;

    private final float touchSlop;
    private float downX;
    private float downY;

    // null: bu dokunuş için henüz yön kararı verilmedi
    // TRUE: yatay kabul edildi (sayfa geçişi serbest)
    // FALSE: dikey/çapraz kabul edildi (sayfa geçişi bu dokunuş boyunca kapalı)
    private Boolean horizontalGesture = null;

    private ViewPager2 viewPager;

    public SwipeAxisGestureLayout(Context context) {
        super(context);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
    }

    public SwipeAxisGestureLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
    }

    private ViewPager2 findViewPager() {
        if (viewPager == null) {
            for (int i = 0; i < getChildCount(); i++) {
                View child = getChildAt(i);
                if (child instanceof ViewPager2) {
                    viewPager = (ViewPager2) child;
                    break;
                }
            }
        }
        return viewPager;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        ViewPager2 pager = findViewPager();
        if (pager != null) {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = ev.getX();
                    downY = ev.getY();
                    horizontalGesture = null;
                    // Yeni dokunuş: varsayılan olarak sayfa geçişi açık başlar,
                    // yön netleşince gerekirse aşağıda kapatılır.
                    pager.setUserInputEnabled(true);
                    break;

                case MotionEvent.ACTION_MOVE:
                    if (horizontalGesture == null) {
                        float dx = ev.getX() - downX;
                        float dy = ev.getY() - downY;
                        float absDx = Math.abs(dx);
                        float absDy = Math.abs(dy);

                        if (absDx > touchSlop || absDy > touchSlop) {
                            // Yön kararı hareketin en başında bir kere verilir
                            // ve bu dokunuş bitene kadar korunur.
                            horizontalGesture = absDx > absDy * HORIZONTAL_DOMINANCE_RATIO;
                            pager.setUserInputEnabled(horizontalGesture);
                        }
                    }
                    break;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    horizontalGesture = null;
                    // Bir sonraki dokunuş için sayfa geçişini tekrar açık bırak.
                    pager.setUserInputEnabled(true);
                    break;

                default:
                    break;
            }
        }
        // Bu katman dokunuşu kendisi hiç yakalamaz; olay normal şekilde
        // ViewPager2'ye (ve gerekirse altındaki listeye) akmaya devam eder.
        return false;
    }
}
