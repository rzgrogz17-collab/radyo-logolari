package com.wello.wallpaperose.widget;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/**
 * Splash ekranındaki dış halka şeridinin üzerinde gezinen, biri sağa biri
 * sola gidip gelen (salınan) iki hafif parlak ışık hüzmesini çizer.
 *
 * Bu View halkanın kendisini çizmez; sadece {@code bg_splash_ring_outer}
 * arka planlı View'in üzerine, aynı boyutta ve konumda bindirilerek
 * kullanılır (bkz. activity_splash.xml -> ring_beams).
 */
public class SplashRingBeamView extends View {

    // Her bir ışık hüzmesinin açısal genişliği (derece)
    private static final float BEAM_SWEEP = 42f;

    // Hüzmelerin salınım merkezleri ve genlikleri (derece)
    private static final float BEAM1_CENTER = -90f; // üstten başlar (12 yönü)
    private static final float BEAM1_RANGE = 85f;   // sağa-sola salınım genliği
    private static final long BEAM1_DURATION = 2600L;

    private static final float BEAM2_CENTER = 90f;  // alttan başlar (6 yönü)
    private static final float BEAM2_RANGE = 85f;
    private static final long BEAM2_DURATION = 3100L;

    // Hüzme rengi + tepe noktasındaki maksimum alfa (hafif parlak olsun diye düşük tutuldu)
    private static final int BEAM1_COLOR = Color.parseColor("#00E5FF"); // camgöbeği
    private static final int BEAM2_COLOR = Color.parseColor("#A78BFA"); // mor
    private static final int BEAM_MAX_ALPHA = 130; // 0-255 arası (~%50)

    private final Paint beamPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF ringRect = new RectF();

    private float beam1Angle = BEAM1_CENTER;
    private float beam2Angle = BEAM2_CENTER;

    private ValueAnimator beam1Animator;
    private ValueAnimator beam2Animator;

    private float strokeWidthPx;

    public SplashRingBeamView(Context context) {
        this(context, null);
    }

    public SplashRingBeamView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public SplashRingBeamView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        // Yumuşak (blurlu) hüzme görünümü için yazılım katmanı gerekiyor
        setLayerType(LAYER_TYPE_SOFTWARE, null);

        strokeWidthPx = dp(3.5f);
        beamPaint.setStyle(Paint.Style.STROKE);
        beamPaint.setStrokeWidth(strokeWidthPx);
        beamPaint.setStrokeCap(Paint.Cap.ROUND);
        beamPaint.setMaskFilter(new BlurMaskFilter(dp(3f), BlurMaskFilter.Blur.NORMAL));
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        float inset = strokeWidthPx * 1.5f;
        ringRect.set(inset, inset, w - inset, h - inset);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        startBeams();
    }

    @Override
    protected void onDetachedFromWindow() {
        stopBeams();
        super.onDetachedFromWindow();
    }

    /** İki hüzmeyi de sonsuz döngüde, ters yönlerde salınacak şekilde başlatır. */
    private void startBeams() {
        stopBeams();

        // Biri sağa gidip gelen ışık hüzmesi
        beam1Animator = ValueAnimator.ofFloat(
                BEAM1_CENTER - BEAM1_RANGE, BEAM1_CENTER + BEAM1_RANGE);
        beam1Animator.setDuration(BEAM1_DURATION);
        beam1Animator.setRepeatCount(ValueAnimator.INFINITE);
        beam1Animator.setRepeatMode(ValueAnimator.REVERSE);
        beam1Animator.setInterpolator(new DecelerateInterpolator(1.3f));
        beam1Animator.addUpdateListener(a -> {
            beam1Angle = (float) a.getAnimatedValue();
            postInvalidateOnAnimation();
        });
        beam1Animator.start();

        // Biri sola gidip gelen ışık hüzmesi (ters yön, farklı süre/faz)
        beam2Animator = ValueAnimator.ofFloat(
                BEAM2_CENTER + BEAM2_RANGE, BEAM2_CENTER - BEAM2_RANGE);
        beam2Animator.setDuration(BEAM2_DURATION);
        beam2Animator.setStartDelay(250L);
        beam2Animator.setRepeatCount(ValueAnimator.INFINITE);
        beam2Animator.setRepeatMode(ValueAnimator.REVERSE);
        beam2Animator.setInterpolator(new DecelerateInterpolator(1.3f));
        beam2Animator.addUpdateListener(a -> {
            beam2Angle = (float) a.getAnimatedValue();
            postInvalidateOnAnimation();
        });
        beam2Animator.start();
    }

    private void stopBeams() {
        if (beam1Animator != null) beam1Animator.cancel();
        if (beam2Animator != null) beam2Animator.cancel();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (ringRect.isEmpty()) return;
        drawBeam(canvas, beam1Angle, BEAM1_COLOR);
        drawBeam(canvas, beam2Angle, BEAM2_COLOR);
    }

    /**
     * Bir ışık hüzmesini, "kuyruğu" halkanın üzerinde sönerek kaybolan küçük
     * yay parçacıklarından oluşturarak çizer (kuyruklu yıldız / comet efekti).
     */
    private void drawBeam(Canvas canvas, float headAngle, int color) {
        int segments = 10;
        float segmentSweep = BEAM_SWEEP / segments;
        float startAngle = headAngle - BEAM_SWEEP / 2f;

        for (int i = 0; i < segments; i++) {
            float t = (i + 1f) / segments; // 0 → kuyruk, 1 → baş (en parlak nokta)
            int alpha = Math.round(BEAM_MAX_ALPHA * (0.12f + 0.88f * t * t));
            beamPaint.setColor((color & 0x00FFFFFF) | (alpha << 24));
            float segStart = startAngle + i * segmentSweep;
            canvas.drawArc(ringRect, segStart, segmentSweep * 1.2f, false, beamPaint);
        }
    }
}
