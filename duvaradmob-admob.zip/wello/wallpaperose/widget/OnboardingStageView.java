package com.wello.wallpaperose.widget;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * İlk açılış tanıtımının görsel sahnesi. Üç sayfa: galeri, favori, otomatik değişim.
 */
public class OnboardingStageView extends View {

    private int scene;
    private float drift;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private ValueAnimator animator;

    public OnboardingStageView(Context context) {
        this(context, null);
    }

    public OnboardingStageView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void setScene(int scene) {
        this.scene = scene;
        invalidate();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(4200);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(a -> {
            drift = (float) a.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (animator != null) animator.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;
        float bob = (float) Math.sin(drift * Math.PI * 2) * h * 0.012f;
        canvas.save();
        canvas.translate(0, bob);
        if (scene == 1) drawFavorite(canvas, w, h);
        else if (scene == 2) drawAuto(canvas, w, h);
        else drawGallery(canvas, w, h);
        canvas.restore();
    }

    private void drawGallery(Canvas canvas, float w, float h) {
        float cx = w * 0.5f;
        float cy = h * 0.52f;
        glow(canvas, cx, cy, w * 0.42f, 0x5500E5FF);
        card(canvas, cx - w * 0.22f, cy, w * 0.34f, h * 0.62f, -16f,
                0xFF2A1B4A, 0xFF6C4CFF, false);
        card(canvas, cx + w * 0.22f, cy, w * 0.34f, h * 0.62f, 14f,
                0xFF12324A, 0xFF00C2D4, false);
        card(canvas, cx, cy, w * 0.42f, h * 0.72f, 0f,
                0xFF1A2348, 0xFF3A4E86, true);
    }

    private void drawFavorite(Canvas canvas, float w, float h) {
        float cx = w * 0.5f;
        float cy = h * 0.50f;
        glow(canvas, cx, cy, w * 0.4f, 0x66FF4D8D);
        card(canvas, cx - w * 0.16f, cy + h * 0.04f, w * 0.38f, h * 0.58f, -8f,
                0xFF241428, 0xFF5A305C, false);
        card(canvas, cx + w * 0.02f, cy, w * 0.46f, h * 0.70f, 4f,
                0xFF2A1230, 0xFF8A3A62, true);
        float hx = cx + w * 0.16f;
        float hy = cy - h * 0.22f;
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFF00E5FF);
        canvas.drawCircle(hx, hy, w * 0.075f, paint);
        paint.setColor(0xFFFF4D8D);
        drawHeart(canvas, hx, hy + w * 0.01f, w * 0.045f);
    }

    private void drawAuto(Canvas canvas, float w, float h) {
        float cx = w * 0.5f;
        float cy = h * 0.52f;
        glow(canvas, cx, cy, w * 0.38f, 0x4400E5FF);
        float pw = w * 0.42f;
        float ph = h * 0.78f;
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(w * 0.012f);
        paint.setColor(0xCCF3EDE2);
        rect.set(cx - pw / 2f, cy - ph / 2f, cx + pw / 2f, cy + ph / 2f);
        canvas.drawRoundRect(rect, w * 0.08f, w * 0.08f, paint);
        float inset = w * 0.028f;
        rect.inset(inset, inset * 1.6f);
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new LinearGradient(rect.left, rect.top, rect.right, rect.bottom,
                new int[]{0xFF142038, 0xFF3A2A68, 0xFF0E3A4A},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(rect, w * 0.05f, w * 0.05f, paint);
        paint.setShader(null);
        float slide = (drift - 0.5f) * rect.width() * 0.18f;
        paint.setColor(0x55FFFFFF);
        canvas.drawCircle(rect.centerX() + slide, rect.top + rect.height() * 0.28f, w * 0.06f, paint);
        paint.setColor(0x3300E5FF);
        canvas.drawRoundRect(rect.left + rect.width() * 0.12f, rect.bottom - rect.height() * 0.22f,
                rect.right - rect.width() * 0.12f, rect.bottom - rect.height() * 0.12f,
                20f, 20f, paint);
    }

    private void card(Canvas canvas, float cx, float cy, float cw, float ch, float deg,
                      int top, int bottom, boolean front) {
        canvas.save();
        canvas.rotate(deg, cx, cy);
        rect.set(cx - cw / 2f, cy - ch / 2f, cx + cw / 2f, cy + ch / 2f);
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new LinearGradient(rect.left, rect.top, rect.right, rect.bottom,
                top, bottom, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(rect, cw * 0.12f, cw * 0.12f, paint);
        paint.setShader(null);
        if (front) {
            paint.setColor(0x33FFFFFF);
            canvas.drawCircle(rect.centerX(), rect.top + ch * 0.28f, cw * 0.16f, paint);
            paint.setColor(0x22000000);
            canvas.drawRect(rect.left, rect.centerY(), rect.right, rect.bottom, paint);
        }
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2f);
        paint.setColor(0x55FFFFFF);
        canvas.drawRoundRect(rect, cw * 0.12f, cw * 0.12f, paint);
        paint.setStyle(Paint.Style.FILL);
        canvas.restore();
    }

    private void glow(Canvas canvas, float cx, float cy, float radius, int color) {
        paint.setShader(new android.graphics.RadialGradient(cx, cy, radius,
                color, 0x00000000, Shader.TileMode.CLAMP));
        paint.setStyle(Paint.Style.FILL);
        canvas.drawCircle(cx, cy, radius, paint);
        paint.setShader(null);
    }

    private void drawHeart(Canvas canvas, float cx, float cy, float r) {
        canvas.save();
        canvas.translate(cx, cy);
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawCircle(-r * 0.5f, -r * 0.15f, r * 0.55f, paint);
        canvas.drawCircle(r * 0.5f, -r * 0.15f, r * 0.55f, paint);
        android.graphics.Path path = new android.graphics.Path();
        path.moveTo(-r, 0f);
        path.lineTo(0f, r * 1.15f);
        path.lineTo(r, 0f);
        canvas.drawPath(path, paint);
        canvas.restore();
    }
}
