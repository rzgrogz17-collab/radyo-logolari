package com.wello.wallpaperose.worker;

import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.wello.wallpaperose.data.ThisApp;
import com.wello.wallpaperose.utils.FavoriteImageStore;
import com.wello.wallpaperose.room.table.EntityListing;

import java.util.List;
import java.util.Random;

/**
 * YENİ: Otomatik Duvar Kağıdı Değiştirici.
 * <p>
 * Kullanıcı Ayarlar ekranından bu özelliği açtığında, WorkManager tarafından
 * günlük ya da haftalık periyotlarla arka planda çalıştırılır. Kullanıcının
 * favorilerinden rastgele bir duvar kağıdı seçip ana ekrana (Home Screen)
 * uygular. Favoriler boşsa hiçbir şey yapmadan başarıyla biter ve bir
 * sonraki periyotta tekrar dener.
 */
public class AutoWallpaperWorker extends Worker {

    public AutoWallpaperWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        try {
            if (!ThisApp.pref().isAutoWallpaperEnabled()) {
                return Result.success();
            }

            List<EntityListing> favorites = ThisApp.dao().getAllListingByPage(200, 0);
            if (favorites == null || favorites.isEmpty()) {
                // Favori yok — sessizce geç, bir sonraki periyotta tekrar denenir.
                return Result.success();
            }

            java.util.List<EntityListing> ready = new java.util.ArrayList<>();
            for (EntityListing item : favorites) {
                if (FavoriteImageStore.has(getApplicationContext(), item.getId())) ready.add(item);
            }
            if (ready.isEmpty()) return Result.success();

            EntityListing chosen = ready.get(new Random().nextInt(ready.size()));
            Bitmap bitmap = BitmapFactory.decodeFile(
                    FavoriteImageStore.file(getApplicationContext(), chosen.getId()).getAbsolutePath());
            if (bitmap == null) return Result.success();

            WallpaperManager wm = WallpaperManager.getInstance(getApplicationContext());
            wm.setBitmap(bitmap, null, true, WallpaperManager.FLAG_SYSTEM);

            return Result.success();
        } catch (Exception e) {
            Log.e("AutoWallpaperWorker", "Otomatik duvar kağıdı ayarlanamadı: " + e.getMessage());
            return Result.retry();
        }
    }
}
