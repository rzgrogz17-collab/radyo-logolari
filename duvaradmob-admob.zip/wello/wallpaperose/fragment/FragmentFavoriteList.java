package com.wello.wallpaperose.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;

import com.wello.wallpaperose.AppConfig;
import com.wello.wallpaperose.R;
import com.wello.wallpaperose.activity.ActivityListingDetail;
import com.wello.wallpaperose.adapter.AdapterListener;
import com.wello.wallpaperose.adapter.AdapterListing;
import com.wello.wallpaperose.data.ThisApp;
import com.wello.wallpaperose.databinding.FragmentFavoriteBinding;
import com.wello.wallpaperose.model.Wallpaper;
import com.wello.wallpaperose.room.table.EntityListing;
import com.wello.wallpaperose.utils.Tools;

import java.util.ArrayList;
import java.util.List;

/**
 * DEĞİŞTİ: Favoriler ekranı artık tek bir liste. Önceki "Yeni Eklenenler /
 * En Çok Beğenilen / En Çok İndirilen" 3 alt sekmesi kaldırıldı — bu sayılar
 * tüm kullanıcılar genelinde değil sadece cihaz bazlı tutulduğu ve kafa
 * karıştırdığı için sadeleştirildi. Burada sadece kullanıcının favoriye
 * eklediği görseller, eklenme tarihine göre (en yeni en üstte) listeleniyor.
 */
public class FragmentFavoriteList extends Fragment {

    private FragmentFavoriteBinding binding;
    private AdapterListing adapter;
    private boolean allLoaded = false;
    private int lastCount = -1;

    // Bu ekranda şu an listelenen öğeler — detay ekranında sağa/sola kaydırma için kullanılır
    private final List<Wallpaper> currentList = new ArrayList<>();

    public static FragmentFavoriteList instance() {
        return new FragmentFavoriteList();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentFavoriteBinding.inflate(inflater, container, false);
        initComponent();
        // İlk açılışta hemen yükle; onResume() içindeki lastCount kontrolü
        // sayesinde bu ilk yükleme bir daha tekrarlanmaz.
        lastCount = ThisApp.dao().getListingCount();
        requestAction(1);
        return binding.getRoot();
    }

    private void initComponent() {
        binding.recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), Tools.getGridSpanCount(getActivity())));

        adapter = new AdapterListing(getActivity(), binding.recyclerView, AppConfig.general.listing_pagination_count);
        binding.recyclerView.setAdapter(adapter);

        adapter.setListener(new AdapterListener<Object>() {
            @Override
            public void onClick(View view, String type, Object obj, int position) {
                super.onClick(view, type, obj, position);
                Wallpaper w = (Wallpaper) obj;
                Activity activity = getActivity();
                if (activity == null) return;

                // Bu listenin sırasına göre sağa/sola kaydırılabilmesi için
                // tüm listeyi global değişkene yükleyip doğru pozisyonla detay ekranını aç.
                ThisApp.itemsWallpaper = new ArrayList<>(currentList);
                int realPosition = currentList.indexOf(w);
                if (realPosition != -1) {
                    ActivityListingDetail.navigate(activity, realPosition);
                } else {
                    ActivityListingDetail.navigate(activity, w);
                }
            }

            @Override
            public void onLoadMore(int page) {
                super.onLoadMore(page);
                if (allLoaded) {
                    adapter.setLoaded();
                } else {
                    requestAction(page + 1);
                }
            }
        });

        binding.swipeRefresh.setOnRefreshListener(() -> {
            allLoaded = false;
            adapter.resetListData();
            requestAction(1);
        });
    }

    private void requestAction(final int pageNo) {
        if (pageNo == 1) {
            adapter.resetListData();
            currentList.clear();
            showNoItemView(false);
            swipeProgress(true);
        } else {
            adapter.setLoadingOrFailed(null);
        }
        new Handler(Looper.getMainLooper()).postDelayed(() -> request(pageNo), 200);
    }

    private void request(int pageNo) {
        int count = AppConfig.general.listing_pagination_count;
        int offset = (pageNo - 1) * count;

        // DEĞİŞTİ: Artık tek bir sorgu var — eklenme tarihine göre (en yeni en üstte).
        List<EntityListing> entityListings = ThisApp.dao().getAllListingByPage(count, offset);

        List<Wallpaper> items = new ArrayList<>();
        for (EntityListing e : entityListings) {
            items.add(e.original());
        }
        displayApiResultPlace(items);
        allLoaded = (adapter.getItemCount() >= ThisApp.dao().getListingCount());
    }

    private void displayApiResultPlace(final List<Wallpaper> items) {
        adapter.insertData(items);
        currentList.addAll(items);
        swipeProgress(false);
        showNoItemView(adapter.getItemCount() == 0);
    }

    private void showNoItemView(boolean show) {
        if (binding == null) return;
        ((TextView) binding.lytFailed.findViewById(R.id.failed_subtitle)).setText(getString(R.string.empty_state_no_data));
        binding.lytFailed.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    private void swipeProgress(final boolean show) {
        if (binding == null) return;
        binding.swipeRefresh.post(() -> {
            if (binding != null) binding.swipeRefresh.setRefreshing(show);
        });
        if (!show) {
            binding.recyclerView.setVisibility(View.VISIBLE);
            binding.shimmer.setVisibility(View.GONE);
            binding.shimmer.stopShimmer();
            return;
        }
        binding.recyclerView.setVisibility(View.GONE);
        binding.shimmer.setVisibility(View.VISIBLE);
        binding.shimmer.startShimmer();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (binding == null) return;
        // Kullanıcı detay ekranından favori ekleyip/çıkararak geri döndüğünde
        // liste güncel değilse (sayı değiştiyse) listeyi tazele.
        int count = ThisApp.dao().getListingCount();
        if (count != lastCount) {
            lastCount = count;
            requestAction(1);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}