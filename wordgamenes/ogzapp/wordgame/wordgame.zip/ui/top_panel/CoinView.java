package ogzapp.wordgame.ui.top_panel;

import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.math.Interpolation;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.scenes.scene2d.Group;
import com.badlogic.gdx.scenes.scene2d.actions.IntAction;
import com.badlogic.gdx.scenes.scene2d.actions.RunnableAction;
import com.badlogic.gdx.scenes.scene2d.actions.ScaleToAction;
import com.badlogic.gdx.scenes.scene2d.actions.SequenceAction;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Pools;

import ogzapp.wordgame.config.UIConfig;
import ogzapp.wordgame.graphics.AtlasRegions;
import ogzapp.wordgame.managers.HintManager;
import ogzapp.wordgame.managers.ResourceManager;
import ogzapp.wordgame.screens.BaseScreen;

public class CoinView extends Group {

    public Image coin;
    private Label label;
    private float maxWidth;
    public BaseScreen screen;
    private CoinCountIncrementer coinCountIncrementer;
    private SequenceAction sequenceAction;
    private RunnableAction runnableAction;
    public ImageButton plus;
    private Runnable coinAnimFinishedCompleted;
    private boolean cancelled;

    public CoinView(BaseScreen screen) {
        this.screen = screen;

        // Arka plan kaldırıldı, ancak boyutları aynı kalacak
        float bgWidth = AtlasRegions.coin_view_bg.getRegionWidth();
        float bgHeight = AtlasRegions.coin_view_bg.getRegionHeight();
        setSize(bgWidth, bgHeight);

        coin = new Image(AtlasRegions.coin_view_coin);
        coin.setOrigin(Align.center);
        coin.setX(getWidth() * 0.03f);
        coin.setScale(0.72f);
        coin.setY((getHeight() - coin.getHeight()) * 0.75f);
        addActor(coin);

        if (screen.wordConnectGame.shoppingProcessor != null && screen.wordConnectGame.shoppingProcessor.isIAPEnabled()) {
            plus = new ImageButton(new TextureRegionDrawable(AtlasRegions.coin_view_plus_up), new TextureRegionDrawable(AtlasRegions.coin_view_plus_down));
            plus.setX(getWidth() - plus.getWidth() * 1.18f);
            plus.setY((getHeight() - plus.getHeight()) * 0.6f);
            addActor(plus);
            maxWidth = getWidth() - plus.getWidth() - coin.getWidth();
        } else {
            maxWidth = getWidth() - coin.getWidth();
        }

        maxWidth *= 0.7f;
        String font = UIConfig.REMAINING_COINS_USE_SHADOW_FONT ? ResourceManager.fontSemiBoldShadow : ResourceManager.fontSemiBold;
        Label.LabelStyle style = new Label.LabelStyle(screen.wordConnectGame.resourceManager.get(font, BitmapFont.class), UIConfig.REMAINING_COINS_TEXT_COLOR);

        label = new Label("", style);
        label.setAlignment(Align.center);
        addActor(label);

        update(HintManager.getRemainingCoins());
    }

    public void setPlusListener(ChangeListener changeListener) {
        if (plus != null)
            plus.addListener(changeListener);
    }

    public void update(int count) {
        label.setText(count);
        GlyphLayout glyphLayout = Pools.obtain(GlyphLayout.class);
        glyphLayout.setText(label.getStyle().font, label.getText());

        if (glyphLayout.width > maxWidth) {
            label.setFontScale(maxWidth / glyphLayout.width);
        }

        if (plus == null)
            label.setX((getWidth() - label.getWidth()) * 0.6f);
        else
            label.setX((getWidth() - label.getWidth()) * 0.51f);

        label.setY((getHeight() - label.getHeight()) * 0.5f);
        Pools.free(glyphLayout);
    }

    public void incrementCoinLabelWithAnimationAndDeleteCoinImages(int startFrom, int count, Runnable callback) {
        if (coinCountIncrementer == null) {
            coinCountIncrementer = new CoinCountIncrementer();
        } else {
            coinCountIncrementer.reset();
        }

        coinCountIncrementer.setInterpolation(Interpolation.sineOut);
        coinCountIncrementer.setDuration(count * 0.05f);
        coinCountIncrementer.setStart(startFrom);
        coinCountIncrementer.setEnd(startFrom + count);

        if (callback == null) {
            label.addAction(coinCountIncrementer);
        } else {
            if (sequenceAction == null)
                sequenceAction = new SequenceAction();
            else
                sequenceAction.reset();

            if (runnableAction == null)
                runnableAction = new RunnableAction();
            else
                runnableAction.reset();

            runnableAction.setRunnable(callback);

            sequenceAction.addAction(coinCountIncrementer);
            sequenceAction.addAction(runnableAction);
            label.addAction(sequenceAction);
        }
    }

    private class CoinCountIncrementer extends IntAction {
        @Override
        protected void update(float percent) {
            super.update(percent);
            CoinView.this.update(getValue());
        }
    }

    public boolean isCancelled() {
        return cancelled;
    }

    public void cancel(boolean flag) {
        cancelled = flag;
    }

    private static final int MAX_ANIMATED_COINS = 6;
    private static final float COIN_ANIMATION_STAGGER = 0.06f;

    public void createCoinAnimation(int count, float x, float y, Runnable coinAnimFinishedCompleted) {
        createCoinAnimation(count, x, y, false, coinAnimFinishedCompleted);
    }

    // silent=true: her coin uçuşu tamamlandığında normalde çalan coin sesi
    // ÇALINMAZ. Diğer TÜM çağıranlar (combo, UFO vurma, bonus kelime ödülü
    // vb.) eski 4 parametreli metodu kullanmaya devam ediyor ve dolayısıyla
    // her zamanki gibi sesli çalışıyor - bu parametre SADECE açıkça
    // isteyen (silent=true veren) çağıranları etkiliyor.
    public void createCoinAnimation(int count, float x, float y, boolean silent, Runnable coinAnimFinishedCompleted) {
        this.coinAnimFinishedCompleted = coinAnimFinishedCompleted;

        int coinsToAnimate = MathUtils.clamp(count, 1, MAX_ANIMATED_COINS);

        for (int i = 0; i < coinsToAnimate; i++) {
            Coin newCoin = ogzapp.wordgame.pool.Pools.coinPool.obtain();
            newCoin.setPosition(x, y);
            addActor(newCoin);
            boolean last = i == coinsToAnimate - 1;
            newCoin.animateForCoinView(this, i * COIN_ANIMATION_STAGGER, last, count, silent);
        }
    }

    private ScaleToAction grow, shrink;
    private SequenceAction pulseSequence;
    private RunnableAction pulseRunnable;

    public void coinPulseAnimation(Runnable callback) {
        if (grow == null) grow = new ScaleToAction();
        else grow.reset();
        grow.setScale(1.1f);
        grow.setDuration(0.05f);

        if (shrink == null) shrink = new ScaleToAction();
        else shrink.reset();
        shrink.setScale(0.72f);
        shrink.setDuration(0.05f);

        if (pulseSequence == null) pulseSequence = new SequenceAction();
        else pulseSequence.reset();

        pulseSequence.addAction(grow);
        pulseSequence.addAction(shrink);

        if (callback != null) {
            if (pulseRunnable == null) pulseRunnable = new RunnableAction();
            else pulseRunnable.reset();
            pulseRunnable.setRunnable(callback);
            pulseSequence.addAction(pulseRunnable);
        }

        coin.addAction(pulseSequence);
    }

    public Runnable incrementCoinsWithAnimation(final int count) {
        return new Runnable() {
            @Override
            public void run() {
                int totalCoins = HintManager.getRemainingCoins() - count;
                incrementCoinLabelWithAnimationAndDeleteCoinImages(totalCoins, count, coinAnimFinishedCompleted);
            }
        };
    }
}